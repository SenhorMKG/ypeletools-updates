"""yPeléTools · identidade do programa no Windows.

Por que existe: o app é um script Python. Quando ele roda pelo `pythonw.exe`, o Windows mostra o que está gravado
dentro desse executável ("Python") no Gerenciador de Tarefas, no "Abrir com", nas propriedades do processo etc.

O que este módulo faz (sem esconder nada e sem fingir nada do sistema):
  * cria `runtime\\yPeleTools.exe`, uma cópia do `pythonw.exe` do próprio app em que os recursos de versão
    (VERSIONINFO: FileDescription, ProductName, OriginalFilename...) e o ícone são trocados pela API oficial do
    Windows (BeginUpdateResourceW / UpdateResourceW / EndUpdateResourceW). É um executável de verdade com os dados
    do yPeléTools; o processo que aparece no Gerenciador é ele mesmo, sem processo intermediário;
  * aponta os atalhos do Menu Iniciar e da Área de Trabalho para ele, com o nome "yPeléTools", e apaga os atalhos
    antigos ("YPelé Tools.lnk") que apontavam para esta instalação;
  * acerta o nome em Aplicativos instalados (DisplayName) e em instalacao.json.

É usado pelo instalador (instalação nova, atualização e reparo) e pelo próprio app na abertura (quem atualizou pelo
botão "Atualizar" da Beta 3.5 recebe só a pasta app\\; o executável e os atalhos são acertados na primeira abertura).
O pythonw.exe original continua lá, intacto: o atualizador e o desinstalador seguem usando ele.

Fora do Windows tudo aqui vira "nada a fazer".
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
from pathlib import Path

WINDOWS = sys.platform == "win32"
if WINDOWS:
    import ctypes
    from ctypes import wintypes

NOME_EXIBIDO = "yPeléTools"                 # Gerenciador de Tarefas, Menu Iniciar, atalhos, Aplicativos instalados
NOME_EXE = "yPeleTools.exe"                 # nome do arquivo (sem acento, para não quebrar ferramentas antigas)
NOME_INTERNO = "yPeleTools"
EMPRESA = "YPelé"
DESCRICAO_ATALHO = "Downloads, conversões, imagens e separação de stems"
ATALHO = NOME_EXIBIDO + ".lnk"
ATALHOS_ANTIGOS = ("YPelé Tools.lnk", "YPele Tools.lnk", "yPelé Tools.lnk")
CHAVE_REGISTRO = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\YPeleTools"
ARQ_CARIMBO = "yPeleTools.exe.json"         # ao lado do .exe: de que pythonw e de que versão ele foi feito
IDIOMA = 0x0416                             # português (Brasil)
PAGINA = 1200                               # Unicode (UTF-16)

RT_ICON, RT_GROUP_ICON, RT_VERSION = 3, 14, 16


class ErroIdentidade(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------------
# VERSIONINFO (montado em bytes, no formato documentado do Windows: VS_VERSIONINFO)
# ----------------------------------------------------------------------------------------------------------------------
def _alinhar(b: bytes) -> bytes:
    return b + b"\0" * ((4 - len(b) % 4) % 4)


def _bloco(chave: str, valor: bytes = b"", texto: bool = False, filhos: list = ()) -> bytes:
    k = (chave + "\0").encode("utf-16-le")
    corpo = _alinhar(struct.pack("<HHH", 0, 0, 0) + k)
    if valor:
        corpo = _alinhar(corpo + valor)
    for f in filhos:
        corpo = _alinhar(corpo + f)
    tam_valor = (len(valor) // 2) if texto else len(valor)
    return struct.pack("<HHH", len(corpo), tam_valor, 1 if texto else 0) + corpo[6:]


def _versao4(versao_num) -> tuple:
    v = [int(x) for x in list(versao_num)[:4]]
    return tuple(v + [0] * (4 - len(v)))


def montar_versioninfo(versao_num, versao_texto: str) -> bytes:
    a, b, c, d = _versao4(versao_num)
    ms, ls = (a << 16) | b, (c << 16) | d
    fixo = struct.pack("<13I", 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x00040004, 1, 0, 0, 0)
    textos = [("CompanyName", EMPRESA), ("FileDescription", NOME_EXIBIDO),
              ("FileVersion", "%d.%d.%d.%d" % (a, b, c, d)), ("InternalName", NOME_INTERNO),
              ("LegalCopyright", "© %s" % EMPRESA), ("OriginalFilename", NOME_EXE),
              ("ProductName", NOME_EXIBIDO), ("ProductVersion", versao_texto),
              ("Comments", "Executável do yPeléTools (Python %d.%d embutido)" % sys.version_info[:2])]
    tabela = _bloco("%04X%04X" % (IDIOMA, PAGINA),
                    filhos=[_bloco(k, (v + "\0").encode("utf-16-le"), texto=True) for k, v in textos])
    sfi = _bloco("StringFileInfo", filhos=[tabela])
    vfi = _bloco("VarFileInfo", filhos=[_bloco("Translation", struct.pack("<HH", IDIOMA, PAGINA))])
    return _bloco("VS_VERSION_INFO", fixo, filhos=[sfi, vfi])


def ler_ico(caminho: Path) -> list:
    """[(entrada de 12 bytes do GRPICONDIRENTRY sem o nID, dados da imagem)] de um arquivo .ico."""
    d = Path(caminho).read_bytes()
    reservado, tipo, n = struct.unpack_from("<HHH", d, 0)
    if reservado != 0 or tipo != 1 or not 0 < n < 64:
        raise ErroIdentidade("ícone inválido: %s" % caminho)
    imagens = []
    for i in range(n):
        w, h, cores, res, planos, bits, tam, pos = struct.unpack_from("<BBBBHHII", d, 6 + 16 * i)
        dados = d[pos:pos + tam]
        if len(dados) != tam:
            raise ErroIdentidade("ícone truncado: %s" % caminho)
        imagens.append((struct.pack("<BBBBHHI", w, h, cores, res, planos, bits, tam), dados))
    return imagens


# ----------------------------------------------------------------------------------------------------------------------
# Recursos de um .exe pela API do Windows
# ----------------------------------------------------------------------------------------------------------------------
def _k32():
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.LoadLibraryExW.restype = wintypes.HMODULE
    k.LoadLibraryExW.argtypes = [wintypes.LPCWSTR, wintypes.HANDLE, wintypes.DWORD]
    k.FreeLibrary.argtypes = [wintypes.HMODULE]
    k.BeginUpdateResourceW.restype = wintypes.HANDLE
    k.BeginUpdateResourceW.argtypes = [wintypes.LPCWSTR, wintypes.BOOL]
    k.UpdateResourceW.restype = wintypes.BOOL
    k.UpdateResourceW.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, wintypes.WORD,
                                  ctypes.c_void_p, wintypes.DWORD]
    k.EndUpdateResourceW.restype = wintypes.BOOL
    k.EndUpdateResourceW.argtypes = [wintypes.HANDLE, wintypes.BOOL]
    return k


def _recursos(exe: Path, tipos=(RT_VERSION, RT_GROUP_ICON, RT_ICON)) -> list:
    """[(tipo, nome (int ou str), idioma)] dos recursos destes tipos que o .exe já tem."""
    k = _k32()
    h = k.LoadLibraryExW(str(exe), None, 0x00000002 | 0x00000020)    # AS_DATAFILE | AS_IMAGE_RESOURCE
    if not h:
        raise ErroIdentidade("não consegui ler os recursos de %s (erro %d)" % (exe, ctypes.get_last_error()))
    achados = []
    PROC_NOME = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    PROC_LANG = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p, wintypes.WORD,
                                   ctypes.c_void_p)
    k.EnumResourceNamesW.argtypes = [wintypes.HMODULE, ctypes.c_void_p, PROC_NOME, ctypes.c_void_p]
    k.EnumResourceLanguagesW.argtypes = [wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p, PROC_LANG,
                                         ctypes.c_void_p]
    try:
        for tipo in tipos:
            nomes = []

            def ao_nome(_h, _t, nome, _p):
                v = nome or 0
                nomes.append(int(v) if v <= 0xFFFF else ctypes.wstring_at(v))
                return True
            cb_nome = PROC_NOME(ao_nome)
            k.EnumResourceNamesW(h, tipo, cb_nome, None)          # FALSE quando não há nenhum: tudo bem
            for nome in nomes:
                buf = None if isinstance(nome, int) else ctypes.create_unicode_buffer(nome)
                ref = nome if buf is None else ctypes.addressof(buf)

                def ao_idioma(_h, _t, _n, idioma, _p, nome=nome):
                    achados.append((tipo, nome, int(idioma)))
                    return True
                cb_lang = PROC_LANG(ao_idioma)
                k.EnumResourceLanguagesW(h, tipo, ref, cb_lang, None)
    finally:
        k.FreeLibrary(h)
    return achados


def trocar_recursos(exe: Path, versao: bytes, icone: list = None) -> None:
    """Apaga o VERSIONINFO (e, com `icone`, os ícones) do .exe e grava os do yPeléTools."""
    k = _k32()
    existentes = _recursos(exe)
    h = k.BeginUpdateResourceW(str(exe), False)
    if not h:
        raise ErroIdentidade("BeginUpdateResourceW falhou (erro %d)" % ctypes.get_last_error())
    guardar = []                                 # mantém os buffers vivos até o EndUpdateResourceW

    def upd(tipo, nome, idioma, dados):
        ref = nome
        if not isinstance(nome, int):
            b = ctypes.create_unicode_buffer(nome)
            guardar.append(b)
            ref = ctypes.addressof(b)
        if dados is None:
            ok = k.UpdateResourceW(h, tipo, ref, idioma, None, 0)
        else:
            b = ctypes.create_string_buffer(dados, len(dados))
            guardar.append(b)
            ok = k.UpdateResourceW(h, tipo, ref, idioma, b, len(dados))
        if not ok:
            raise ErroIdentidade("UpdateResourceW falhou (tipo %d, erro %d)" % (tipo, ctypes.get_last_error()))
    try:
        # Grava por cima de cada recurso que já existe, no MESMO nome e idioma (é a forma que funciona igual em
        # todas as versões do Windows); só o que sobrar (ícones a mais do Python) é apagado.
        versoes = [(n, i) for t, n, i in existentes if t == RT_VERSION] or [(1, IDIOMA)]
        for nome, idioma in versoes:
            upd(RT_VERSION, nome, idioma, versao)
        if icone:
            imgs = [(n, i) for t, n, i in existentes if t == RT_ICON]
            idioma_ico = imgs[0][1] if imgs else 0
            grupo = struct.pack("<HHH", 0, 1, len(icone))
            for i, (entrada, dados) in enumerate(icone, 1):
                upd(RT_ICON, i, idioma_ico, dados)
                grupo += entrada + struct.pack("<H", i)
            for nome, idioma in imgs:
                if not (isinstance(nome, int) and 1 <= nome <= len(icone) and idioma == idioma_ico):
                    upd(RT_ICON, nome, idioma, None)
            grupos = [(n, i) for t, n, i in existentes if t == RT_GROUP_ICON] or [(1, idioma_ico)]
            for nome, idioma in grupos:              # todo grupo de ícone do exe passa a ser o do yPeléTools
                upd(RT_GROUP_ICON, nome, idioma, grupo)
    except Exception:
        k.EndUpdateResourceW(h, True)            # descarta: o arquivo fica como estava
        raise
    if not k.EndUpdateResourceW(h, False):
        raise ErroIdentidade("EndUpdateResourceW falhou (erro %d)" % ctypes.get_last_error())


def ler_versao(exe: Path) -> dict:
    """Os textos do VERSIONINFO como o Windows (Explorer, Gerenciador de Tarefas) os lê. {} se não houver."""
    if not WINDOWS:
        return {}
    v = ctypes.WinDLL("version", use_last_error=True)
    v.GetFileVersionInfoSizeW.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p]
    v.GetFileVersionInfoW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p]
    v.VerQueryValueW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p),
                                 ctypes.POINTER(wintypes.UINT)]
    n = v.GetFileVersionInfoSizeW(str(exe), None)
    if not n:
        return {}
    buf = ctypes.create_string_buffer(n)
    if not v.GetFileVersionInfoW(str(exe), 0, n, buf):
        return {}
    p, tam = ctypes.c_void_p(), wintypes.UINT()
    if not v.VerQueryValueW(buf, "\\VarFileInfo\\Translation", ctypes.byref(p), ctypes.byref(tam)) or tam.value < 4:
        return {}
    idioma, pagina = struct.unpack("<HH", ctypes.string_at(p.value, 4))
    saida = {}
    for campo in ("FileDescription", "ProductName", "OriginalFilename", "CompanyName", "ProductVersion",
                  "FileVersion", "InternalName"):
        caminho = "\\StringFileInfo\\%04X%04X\\%s" % (idioma, pagina, campo)
        if v.VerQueryValueW(buf, caminho, ctypes.byref(p), ctypes.byref(tam)) and tam.value:
            saida[campo] = ctypes.wstring_at(p.value, tam.value).rstrip("\0")
    return saida


def _hash(*arquivos) -> str:
    h = hashlib.sha256()
    for a in arquivos:
        if a and Path(a).is_file():
            h.update(Path(a).read_bytes())
        h.update(b"|")
    return h.hexdigest()


def limpar_executaveis_antigos(runtime: Path) -> None:
    """Apaga os yPeleTools.antigo-*.exe que ficaram de uma troca com o app aberto (o que ainda estiver em uso fica)."""
    for p in Path(runtime).glob("yPeleTools.antigo-*.exe"):
        try:
            p.unlink()
        except OSError:
            pass


def trocar_executavel_em_uso(novo: Path, destino: Path) -> None:
    """(3.9.0) O app abre pelo próprio yPeleTools.exe (atalhos e reabertura depois de atualizar), então ele está SEMPRE
    em uso quando o app confere o executável: sobrescrever dá "acesso negado" e, até a 3.8.2, o executável nunca era
    refeito depois de uma atualização (ficava com o ícone e a versão antigos). O Windows não deixa sobrescrever um .exe
    em execução, mas deixa RENOMEÁ-LO: o atual vira yPeleTools.antigo-<pid>.exe (o processo aberto continua por ele e o
    arquivo é apagado numa próxima abertura) e o novo entra no lugar. Se algo falhar, o anterior volta."""
    antigo = destino.with_name("yPeleTools.antigo-%d.exe" % os.getpid())
    try:
        os.replace(destino, antigo)
    except OSError as e:
        raise ErroIdentidade("%s está em uso e não pôde ser trocado (%s); fica o atual" % (NOME_EXE, e))
    try:
        os.replace(novo, destino)
    except OSError as e:
        try:
            os.replace(antigo, destino)                      # devolve o anterior: o app nunca fica sem executável
        except OSError:
            pass
        raise ErroIdentidade("não consegui pôr o %s novo no lugar (%s); fica o atual" % (NOME_EXE, e))


def criar_executavel(runtime: Path, icone: Path = None, versao_num=(0, 0, 0), versao_texto: str = "",
                     forcar: bool = False) -> tuple:
    """Garante runtime\\yPeleTools.exe feito a partir do pythonw.exe desta mesma pasta. Devolve (caminho, mensagem).
    Levanta ErroIdentidade se não der (o app continua funcionando pelo pythonw.exe nesse caso)."""
    runtime = Path(runtime)
    origem, destino, carimbo = runtime / "pythonw.exe", runtime / NOME_EXE, runtime / ARQ_CARIMBO
    if not WINDOWS:
        raise ErroIdentidade("só no Windows")
    if not origem.is_file():
        raise ErroIdentidade("pythonw.exe não encontrado em %s" % runtime)
    icone = Path(icone) if icone and Path(icone).is_file() else None
    limpar_executaveis_antigos(runtime)
    marca = {"origem": _hash(origem), "icone": _hash(icone) if icone else "", "versao": versao_texto, "formato": 1}
    if not forcar and destino.is_file():
        try:
            if json.loads(carimbo.read_text(encoding="utf-8")) == marca and \
                    ler_versao(destino).get("FileDescription") == NOME_EXIBIDO:
                return destino, "já pronto"
        except (OSError, ValueError):
            pass
    novo = runtime / ("yPeleTools.novo-%d.exe" % os.getpid())
    try:
        shutil.copy2(origem, novo)
        trocar_recursos(novo, montar_versioninfo(versao_num, versao_texto), ler_ico(icone) if icone else None)
        lido = ler_versao(novo)
        if lido.get("FileDescription") != NOME_EXIBIDO or lido.get("OriginalFilename") != NOME_EXE:
            raise ErroIdentidade("o Windows não leu o nome novo no executável (%r)" % lido)
        # o executável novo precisa abrir o Python do app de verdade antes de entrar no lugar do antigo
        r = subprocess.run([str(novo), "-I", "-c", "import sys, tkinter, os; sys.exit(37 if os.path.isfile("
                            "os.path.join(sys.prefix, 'Lib', 'os.py')) else 1)"], cwd=str(runtime), timeout=60,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=0x08000000)
        if r.returncode != 37:
            raise ErroIdentidade("o executável novo não abriu o Python do app (código %s)" % r.returncode)
        try:
            os.replace(novo, destino)
        except PermissionError:
            if not destino.is_file():
                raise
            trocar_executavel_em_uso(novo, destino)
        tmp = carimbo.with_suffix(".tmp")
        tmp.write_text(json.dumps(marca), encoding="utf-8")
        os.replace(tmp, carimbo)
        return destino, "criado"
    except (OSError, subprocess.SubprocessError) as e:
        raise ErroIdentidade("não consegui criar %s: %s" % (NOME_EXE, e))
    finally:
        try:
            if novo.exists():
                novo.unlink()
        except OSError:
            pass


# ----------------------------------------------------------------------------------------------------------------------
# Atalhos (.lnk) pela interface IShellLinkW do Windows
# ----------------------------------------------------------------------------------------------------------------------
if WINDOWS:
    class GUID(ctypes.Structure):
        _fields_ = [("d1", ctypes.c_ulong), ("d2", ctypes.c_ushort), ("d3", ctypes.c_ushort), ("d4", ctypes.c_ubyte * 8)]

        def __init__(self, texto: str):
            super().__init__()
            t = texto.strip("{}").replace("-", "")
            self.d1, self.d2, self.d3 = int(t[0:8], 16), int(t[8:12], 16), int(t[12:16], 16)
            for i in range(8):
                self.d4[i] = int(t[16 + 2 * i:18 + 2 * i], 16)

    class _PropVariant(ctypes.Structure):
        _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort),
                    ("r3", ctypes.c_ushort), ("pwsz", ctypes.c_wchar_p), ("extra", ctypes.c_ulonglong)]

    class _PropKey(ctypes.Structure):
        _fields_ = [("fmtid", GUID), ("pid", ctypes.c_ulong)]


def _com(obj, indice: int, argtypes: list, *args):
    vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
    fn = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, *argtypes)(vtbl[indice])
    return fn(obj, *args)


def _shell_link():
    ole32 = ctypes.OleDLL("ole32")
    try:
        ole32.CoInitialize(None)
    except OSError:
        pass
    link = ctypes.c_void_p()
    ole32.CoCreateInstance(ctypes.byref(GUID("{00021401-0000-0000-C000-000000000046}")), None, 1,
                           ctypes.byref(GUID("{000214F9-0000-0000-C000-000000000046}")), ctypes.byref(link))
    return link


def _persist(link):
    arquivo = ctypes.c_void_p()
    _com(link, 0, [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
         ctypes.byref(GUID("{0000010B-0000-0000-C000-000000000046}")), ctypes.byref(arquivo))
    return arquivo


def criar_atalho(lnk: Path, alvo: Path, argumentos: str, pasta_trabalho: Path, icone: Path, descricao: str,
                 aumid: str = "") -> None:
    link = _shell_link()
    try:
        W = ctypes.c_wchar_p
        _com(link, 20, [W], str(alvo))
        _com(link, 11, [W], argumentos)
        _com(link, 9, [W], str(pasta_trabalho))
        _com(link, 7, [W], descricao)
        _com(link, 15, [ctypes.c_int], 1)       # SetShowCmd(SW_SHOWNORMAL) (3.8.2): "Executar: Janela normal", sempre
        if icone:
            _com(link, 17, [W, ctypes.c_int], str(icone), 0)
        if aumid:
            loja = ctypes.c_void_p()
            try:
                _com(link, 0, [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
                     ctypes.byref(GUID("{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}")), ctypes.byref(loja))
                chave = _PropKey(GUID("{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}"), 5)
                valor = _PropVariant(31, 0, 0, 0, aumid, 0)
                _com(loja, 6, [ctypes.POINTER(_PropKey), ctypes.POINTER(_PropVariant)],
                     ctypes.byref(chave), ctypes.byref(valor))
                _com(loja, 7, [])
            except OSError:
                pass
            finally:
                if loja:
                    _com(loja, 2, [])
        arquivo = _persist(link)
        try:
            lnk.parent.mkdir(parents=True, exist_ok=True)
            tmp = lnk.with_name(lnk.stem + ".novo.lnk")
            _com(arquivo, 6, [W, ctypes.c_int], str(tmp), 1)               # IPersistFile::Save
            os.replace(tmp, lnk)
        finally:
            _com(arquivo, 2, [])
    finally:
        _com(link, 2, [])


def ler_atalho(lnk: Path) -> dict:
    link = _shell_link()
    try:
        arquivo = _persist(link)
        try:
            _com(arquivo, 5, [ctypes.c_wchar_p, ctypes.c_uint32], str(lnk), 0)
        finally:
            _com(arquivo, 2, [])
        buf = ctypes.create_unicode_buffer(1024)
        _com(link, 3, [ctypes.c_wchar_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32], buf, 1024, None, 0)
        args = ctypes.create_unicode_buffer(2048)
        _com(link, 10, [ctypes.c_wchar_p, ctypes.c_int], args, 2048)
        r = {"alvo": buf.value, "argumentos": args.value}
        try:                                    # (3.8.2) o resto, para só regravar o atalho quando algo mudou
            pasta = ctypes.create_unicode_buffer(1024)
            _com(link, 8, [ctypes.c_wchar_p, ctypes.c_int], pasta, 1024)
            mostrar = ctypes.c_int(0)
            _com(link, 14, [ctypes.POINTER(ctypes.c_int)], ctypes.byref(mostrar))
            ico = ctypes.create_unicode_buffer(1024)
            idx = ctypes.c_int(0)
            _com(link, 16, [ctypes.c_wchar_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)], ico, 1024, ctypes.byref(idx))
            r.update(pasta=pasta.value, mostrar=mostrar.value, icone=ico.value, aumid=_aumid_do_link(link))
        except OSError:
            pass
        return r
    finally:
        _com(link, 2, [])


def _aumid_do_link(link) -> str:
    loja = ctypes.c_void_p()
    try:
        _com(link, 0, [ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)],
             ctypes.byref(GUID("{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}")), ctypes.byref(loja))
        chave = _PropKey(GUID("{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}"), 5)
        valor = _PropVariant()
        _com(loja, 5, [ctypes.POINTER(_PropKey), ctypes.POINTER(_PropVariant)], ctypes.byref(chave),
             ctypes.byref(valor))                                                  # IPropertyStore::GetValue
        texto = valor.pwsz if valor.vt == 31 else ""
        ctypes.oledll.ole32.PropVariantClear(ctypes.byref(valor))
        return texto or ""
    except OSError:
        return ""
    finally:
        if loja:
            _com(loja, 2, [])


def atalho_igual(lido: dict, alvo, argumentos: str, pasta_trabalho, icone, aumid: str) -> bool:
    """O atalho já está exatamente como deveria (então não é regravado a cada abertura do app)."""
    def norm(c):
        return os.path.normcase(os.path.normpath(str(c))) if c else ""
    return (norm(lido.get("alvo")) == norm(alvo) and (lido.get("argumentos") or "") == (argumentos or "")
            and norm(lido.get("pasta")) == norm(pasta_trabalho) and lido.get("mostrar") == 1
            and norm(lido.get("icone")) == norm(icone or "") and (lido.get("aumid") or "") == (aumid or ""))


def _pasta_conhecida(folderid: str, reserva: Path) -> Path:
    try:
        ptr = ctypes.c_wchar_p()
        sh = ctypes.windll.shell32
        sh.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), ctypes.c_uint32, ctypes.c_void_p,
                                            ctypes.POINTER(ctypes.c_wchar_p)]
        if sh.SHGetKnownFolderPath(ctypes.byref(GUID(folderid)), 0, None, ctypes.byref(ptr)) == 0:
            valor = ptr.value
            ctypes.windll.ole32.CoTaskMemFree(ptr)
            if valor:
                return Path(valor)
    except Exception:
        pass
    return reserva


def pasta_menu_iniciar() -> Path:
    return _pasta_conhecida("{A77F5D77-2E2B-44C3-A6A2-ABA601054A51}", Path(os.environ.get("APPDATA", str(
        Path.home()))) / "Microsoft" / "Windows" / "Start Menu" / "Programs")


def pasta_area_trabalho() -> Path:
    return _pasta_conhecida("{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}", Path.home() / "Desktop")


def _dentro(caminho: str, raiz: Path) -> bool:
    try:
        return Path(caminho).resolve().is_relative_to(Path(raiz).resolve())
    except (OSError, ValueError):
        return False


def acertar_atalhos(raiz: Path, exe: Path, argumentos: str, icone: Path, aumid: str, registrados=()) -> list:
    """Atalhos desta instalação com o nome yPeléTools e apontando para o executável próprio. Um atalho antigo só é
    trocado/apagado se apontar para dentro desta instalação (atalhos de outros programas nunca são tocados).
    Devolve a lista final de atalhos (para instalacao.json)."""
    raiz = Path(raiz)
    finais = []
    for pasta in (pasta_menu_iniciar(), pasta_area_trabalho()):
        candidatos = [pasta / n for n in (ATALHO,) + ATALHOS_ANTIGOS]
        candidatos += [Path(r) for r in registrados if Path(r).parent == pasta]
        existiam = []
        for c in dict.fromkeys(candidatos):
            try:
                if c.is_file() and _dentro(ler_atalho(c)["alvo"], raiz):
                    existiam.append(c)
            except OSError:
                pass
        if not existiam:
            continue                               # a pessoa não quis atalho aqui (ou apagou): não recria
        novo = pasta / ATALHO
        trabalho = Path(exe).parent.parent / "app"
        try:
            pronto = novo in existiam and atalho_igual(ler_atalho(novo), exe, argumentos, trabalho, icone, aumid)
        except OSError:
            pronto = False
        if not pronto:                             # (3.8.2) só regrava quando algo mudou (antes: toda abertura)
            criar_atalho(novo, exe, argumentos, trabalho, icone, DESCRICAO_ATALHO, aumid)
        for c in existiam:
            if c != novo:
                try:
                    c.unlink()
                except OSError:
                    pass
        finais.append(str(novo))
    return finais


def acertar_registro(raiz: Path) -> bool:
    """DisplayName em Aplicativos instalados. Só mexe na entrada que é desta pasta."""
    if not WINDOWS:
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, CHAVE_REGISTRO, 0, winreg.KEY_READ | winreg.KEY_WRITE) as k:
            local, _t = winreg.QueryValueEx(k, "InstallLocation")
            if Path(local).resolve() != Path(raiz).resolve():
                return False
            try:
                atual, _t = winreg.QueryValueEx(k, "DisplayName")
            except OSError:
                atual = ""
            if atual == NOME_EXIBIDO:
                return False
            winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, NOME_EXIBIDO)
            return True
    except OSError:
        return False


def acertar_instalacao(raiz: Path, arquivo_app: str, versao_num, versao_texto: str, aumid: str, log=None) -> dict:
    """Tudo o que o app faz na abertura (instalação feita pelo instalador). Nunca levanta exceção.
    Devolve {"exe": caminho ou None, "mensagens": [...]}."""
    raiz = Path(raiz)
    msgs, exe = [], None
    if not WINDOWS:
        return {"exe": None, "mensagens": msgs}
    icone = raiz / "app" / "ypeletools.ico"                  # 3.9.0: ícone novo (o ypele.ico antigo fica só de reserva)
    if not icone.is_file():
        icone = raiz / "app" / "ypele.ico"
    try:
        exe, como = criar_executavel(raiz / "runtime", icone, versao_num, versao_texto)
        if como != "já pronto":
            msgs.append("Executável próprio %s: %s." % (como, exe))
    except ErroIdentidade as e:
        msgs.append("Executável próprio: %s." % e)
        if (raiz / "runtime" / NOME_EXE).is_file():
            exe = raiz / "runtime" / NOME_EXE        # o anterior continua valendo
    estado_arq = raiz / "instalacao.json"
    try:
        est = json.loads(estado_arq.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        est = {}
    if exe is not None:
        try:
            args = '-I "%s"' % (raiz / "app" / arquivo_app)
            antes = list(est.get("atalhos") or [])
            depois = acertar_atalhos(raiz, exe, args, icone if icone.is_file() else None, aumid, antes)
            if depois and (sorted(depois) != sorted(antes) or est.get("executavel") != str(exe)):
                msgs.append("Atalhos acertados: %s." % ", ".join(depois))
            if depois:
                est["atalhos"] = depois
            est["executavel"] = str(exe)
        except Exception as e:
            msgs.append("Atalhos: %s." % e)
    if acertar_registro(raiz):
        msgs.append("Nome em Aplicativos instalados: %s." % NOME_EXIBIDO)
    if est and est.get("app") != NOME_EXIBIDO:
        est["app"] = NOME_EXIBIDO
    if est and isinstance(est.get("componentes"), dict) and str(est["componentes"].get("app", "")).startswith(
            ("YPelé Tools", "YPele Tools")):
        est["componentes"]["app"] = "%s %s" % (NOME_EXIBIDO, versao_texto)
    if est:
        try:
            atual = estado_arq.read_text(encoding="utf-8")
            novo = json.dumps(est, ensure_ascii=False, indent=2)
            if json.loads(atual) != est:
                tmp = estado_arq.with_name(estado_arq.name + ".tmp")
                tmp.write_text(novo, encoding="utf-8")
                os.replace(tmp, estado_arq)
        except (OSError, ValueError):
            pass
    if log:
        for m in msgs:
            log(m)
    return {"exe": exe, "mensagens": msgs}
