#!/usr/bin/env python3
"""
Atualizador do yPeléTools (Alpha 3.3 em diante; Beta 3.5.0: só o nome mostrado da versão mudou).

Um arquivo só, sem dependências fora da biblioteca padrão do Python. Ele tem três papéis:

  1. Biblioteca usada pelo app (ypele_tools.py importa este arquivo, que fica ao lado dele):
       - consulta as Releases do repositório oficial no GitHub (SenhorMKG/ypeletools-updates);
       - baixa e confere o manifesto assinado (ypeletools-update.json + .sig) e o pacote;
       - compara versões semânticas.
  2. Programa independente (quando executado): espera o app fechar, confere tudo de novo, faz backup, troca os
     arquivos, atualiza as dependências se o requirements.txt mudou, restaura a versão anterior se algo falhar e
     reabre o app.
  3. Biblioteca da ferramenta de publicação (instalador/publicar_atualizacao.py): assina os pacotes.

Segurança:
  - O que vale é o MANIFESTO ASSINADO com Ed25519. A chave pública fica neste arquivo (CHAVES_CONFIAVEIS); a privada
    fica só com quem publica e nunca entra no código, no repositório nem nos pacotes.
  - O manifesto traz o SHA-256 do pacote e de CADA arquivo dele. Como o manifesto é assinado, trocar o pacote ou o hash
    na Release não passa na verificação.
  - O pacote só pode ter arquivos em app\\ e desinstalar\\, com extensões de uma lista fechada, sem caminhos absolutos,
    sem "..", sem links simbólicos e com limites de tamanho. Nada do pacote é executado durante a verificação.
  - Downloads só de https://github.com/SenhorMKG/ypeletools-updates/releases/download/... (e dos servidores de arquivos
    do próprio GitHub para onde ele redireciona).
  - Nunca instala versão igual ou mais antiga que a instalada.
"""

import base64
import ctypes
import datetime
import hashlib
import http.client
import io
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

WINDOWS = sys.platform == "win32"

# ----------------------------------------------------------------------------------------------------------------------
# Configuração oficial (não há outro repositório padrão)
# ----------------------------------------------------------------------------------------------------------------------
REPOSITORIO = "SenhorMKG/ypeletools-updates"
URL_REPOSITORIO = "https://github.com/SenhorMKG/ypeletools-updates"
API_ULTIMA = "https://api.github.com/repos/SenhorMKG/ypeletools-updates/releases/latest"
API_LISTA = "https://api.github.com/repos/SenhorMKG/ypeletools-updates/releases"
URL_RELEASES = "https://github.com/SenhorMKG/ypeletools-updates/releases"
PREFIXO_DOWNLOAD = "/SenhorMKG/ypeletools-updates/releases/download/"
HOSTS_DOWNLOAD = {"github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com",
                  "github-releases.githubusercontent.com"}
ARQ_MANIFESTO = "ypeletools-update.json"
ARQ_ASSINATURA = "ypeletools-update.json.sig"
PRODUTO = "yPeleTools"
FORMATO_MANIFESTO = 1
DISTRIBUICAO_INSTALADOR = "windows-instalador"

# Chaves públicas Ed25519 aceitas (id -> 32 bytes em hex). Para trocar de chave: publique uma versão assinada com a
# chave ANTIGA que já traga a nova aqui; depois disso as versões podem ser assinadas com a nova.
CHAVES_CONFIAVEIS = {
    "ypele-2026-1": "21458d0fb37a5075d4b2581a3dbea82cc59c5c57f2b697b7c68558d7235f4775",
}

# O que um pacote de atualização pode conter
PREFIXOS_PERMITIDOS = ("app/", "desinstalar/")
EXTENSOES_PERMITIDAS = {".py", ".pyw", ".txt", ".ico", ".json", ".md", ".png"}
OBRIGATORIOS = ("app/ypele_tools.py", "app/ypele_atualizador.py")
LIMITE_ARQUIVOS = 300
LIMITE_DESCOMPACTADO = 150 * 1024 * 1024
LIMITE_PACOTE = 150 * 1024 * 1024
LIMITE_MANIFESTO = 512 * 1024
LIMITE_TAXA = 200               # compactação maior que 200:1 = suspeito (zip bomb)

UA = "yPeleTools-Atualizador/1 (+%s)" % URL_REPOSITORIO
PIP_IGNORAR = {"imageio-ffmpeg"}       # mesmo critério do instalador
MUTEX_ATUALIZADOR = "Local\\YPeleToolsAtualizador"
MUTEX_INSTALADOR = "Local\\YPeleToolsInstalador"


def modo_teste() -> dict:
    """Só para testes automatizados: um servidor LOCAL no lugar da API do GitHub e uma chave de teste. As variáveis só
    valem quando a API aponta para 127.0.0.1/localhost; no uso normal elas são ignoradas."""
    api = os.environ.get("YPELE_ATUALIZACAO_API_TESTE", "").strip()
    if not api:
        return {}
    u = urllib.parse.urlsplit(api)
    if u.scheme != "http" or u.hostname not in ("127.0.0.1", "localhost"):
        return {}
    chaves = {}
    ch = os.environ.get("YPELE_ATUALIZACAO_CHAVE_TESTE", "")
    if ":" in ch:
        kid, pub = ch.split(":", 1)
        if re.fullmatch(r"[0-9a-fA-F]{64}", pub.strip()):
            chaves[kid.strip()] = pub.strip().lower()
    return {"api": api, "host": u.netloc, "chaves": chaves}


def chaves_aceitas() -> dict:
    ch = {k: v for k, v in CHAVES_CONFIAVEIS.items() if re.fullmatch(r"[0-9a-f]{64}", v)}
    ch.update(modo_teste().get("chaves", {}))
    return ch


# ----------------------------------------------------------------------------------------------------------------------
# Ed25519 (RFC 8032), em Python puro: verificar (app e atualizador) e assinar (só a ferramenta de publicação)
# ----------------------------------------------------------------------------------------------------------------------
_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_RAIZ_M1 = pow(2, (_P - 1) // 4, _P)


def _inv(x: int) -> int:
    return pow(x, _P - 2, _P)


def _recuperar_x(y: int, sinal: int):
    if y >= _P:
        return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1) % _P
    if x2 == 0:
        return None if sinal else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P:
        x = x * _RAIZ_M1 % _P
    if (x * x - x2) % _P:
        return None
    if (x & 1) != sinal:
        x = _P - x
    return x


_GY = 4 * _inv(5) % _P
_GX = _recuperar_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)
_NEUTRO = (0, 1, 1, 0)


def _somar(a, b):
    A = (a[1] - a[0]) * (b[1] - b[0]) % _P
    B = (a[1] + a[0]) * (b[1] + b[0]) % _P
    C = 2 * a[3] * b[3] * _D % _P
    D = 2 * a[2] * b[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _P, G * H % _P, F * G % _P, E * H % _P)


def _multiplicar(s: int, ponto):
    q = _NEUTRO
    while s > 0:
        if s & 1:
            q = _somar(q, ponto)
        ponto = _somar(ponto, ponto)
        s >>= 1
    return q


def _iguais(a, b) -> bool:
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _comprimir(ponto) -> bytes:
    zi = _inv(ponto[2])
    x, y = ponto[0] * zi % _P, ponto[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _descomprimir(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sinal = y >> 255
    y &= (1 << 255) - 1
    x = _recuperar_x(y, sinal)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


def _h(dados: bytes) -> int:
    return int.from_bytes(hashlib.sha512(dados).digest(), "little") % _L


def _expandir(segredo: bytes):
    if len(segredo) != 32:
        raise ValueError("a chave privada Ed25519 tem 32 bytes")
    h = hashlib.sha512(segredo).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def ed25519_publica(segredo: bytes) -> bytes:
    a, _ = _expandir(segredo)
    return _comprimir(_multiplicar(a, _G))


def ed25519_assinar(segredo: bytes, mensagem: bytes) -> bytes:
    a, prefixo = _expandir(segredo)
    pub = _comprimir(_multiplicar(a, _G))
    r = _h(prefixo + mensagem)
    R = _comprimir(_multiplicar(r, _G))
    s = (r + _h(R + pub + mensagem) * a) % _L
    return R + int.to_bytes(s, 32, "little")


def ed25519_verificar(publica: bytes, mensagem: bytes, assinatura: bytes) -> bool:
    if len(publica) != 32 or len(assinatura) != 64:
        return False
    A = _descomprimir(publica)
    R = _descomprimir(assinatura[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(assinatura[32:], "little")
    if s >= _L:
        return False
    h = _h(assinatura[:32] + publica + mensagem)
    return _iguais(_multiplicar(s, _G), _somar(R, _multiplicar(h, A)))


# ----------------------------------------------------------------------------------------------------------------------
# Versões semânticas
# ----------------------------------------------------------------------------------------------------------------------
_SEMVER = re.compile(r"^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$")


def ler_versao(texto: str):
    """'v3.3.1' -> (3, 3, 1, ()) ; '1.0.0-beta.2' -> (1, 0, 0, ('beta', 2)). None se não for semver."""
    m = _SEMVER.match(str(texto or "").strip())
    if not m:
        return None
    pre = ()
    if m.group(4):
        pre = tuple(int(p) if p.isdigit() else p for p in m.group(4).split("."))
    return int(m.group(1)), int(m.group(2)), int(m.group(3)), pre


def comparar_versoes(a: str, b: str) -> int:
    """-1, 0 ou 1. Pré-lançamento vem antes da versão final (1.0.0-beta < 1.0.0). Versão inválida levanta ValueError."""
    va, vb = ler_versao(a), ler_versao(b)
    if va is None or vb is None:
        raise ValueError("versão inválida: %r / %r" % (a, b))
    if va[:3] != vb[:3]:
        return -1 if va[:3] < vb[:3] else 1
    pa, pb = va[3], vb[3]
    if pa == pb:
        return 0
    if not pa:
        return 1
    if not pb:
        return -1
    for x, y in zip(pa, pb):
        if x == y:
            continue
        if isinstance(x, int) and isinstance(y, int):
            return -1 if x < y else 1
        if isinstance(x, int):
            return -1
        if isinstance(y, int):
            return 1
        return -1 if x < y else 1
    return -1 if len(pa) < len(pb) else 1


def e_estavel(versao: str) -> bool:
    v = ler_versao(versao)
    return v is not None and not v[3]


def nome_versao(semver: str, canal: str = "Alpha") -> str:
    """O nome que aparece no app: '3.3.0' -> 'Alpha 3.3'; '3.3.1' -> 'Alpha 3.3.1'. Da Beta em diante, sempre com os
    três números: ('3.5.0', 'Beta') -> 'Beta 3.5.0'. Só o nome muda; a comparação de versões é sempre pelo semver."""
    v = ler_versao(semver)
    if not v:
        return semver
    canal = str(canal or "Alpha")
    if canal != "Alpha":
        return "%s %d.%d.%d" % (canal, v[0], v[1], v[2])
    return "%s %d.%d" % (canal, v[0], v[1]) + (".%d" % v[2] if v[2] else "")


def versao_do_app(conteudo: bytes) -> str:
    """O VERSAO_SEMVER escrito no ypele_tools.py (sem executar o arquivo)."""
    m = re.search(rb'^VERSAO_SEMVER\s*=\s*"([^"]+)"', conteudo, re.M)
    return m.group(1).decode("ascii", "replace") if m else ""


# ----------------------------------------------------------------------------------------------------------------------
# Manifesto assinado e pacote
# ----------------------------------------------------------------------------------------------------------------------
class ErroAtualizacao(Exception):
    """Mensagem pronta para o usuário (str(e)) e detalhe técnico opcional."""

    def __init__(self, mensagem: str, detalhe: str = ""):
        super().__init__(mensagem)
        self.detalhe = detalhe


def caminho_seguro(caminho: str) -> bool:
    """Caminho relativo dentro de app/ ou desinstalar/, sem '..', sem raiz, sem letra de unidade e com extensão aceita."""
    if not isinstance(caminho, str) or not caminho or len(caminho) > 200:
        return False
    if "\\" in caminho or caminho.startswith("/") or ":" in caminho or "\x00" in caminho:
        return False
    partes = caminho.split("/")
    if any(p in ("", ".", "..") or p != p.strip() or p.endswith(".") for p in partes):
        return False
    if not caminho.startswith(PREFIXOS_PERMITIDOS) or len(partes) < 2:
        return False
    if not re.fullmatch(r"[A-Za-z0-9_. ()\-]+", partes[-1]):
        return False
    return Path(partes[-1]).suffix.lower() in EXTENSOES_PERMITIDAS


def verificar_manifesto(dados: bytes, assinatura_txt, chaves: dict = None) -> dict:
    """Confere a assinatura Ed25519 e a estrutura do manifesto. Devolve o manifesto (dict) ou levanta ErroAtualizacao."""
    if not isinstance(dados, (bytes, bytearray)) or not dados or len(dados) > LIMITE_MANIFESTO:
        raise ErroAtualizacao("O manifesto da atualização é inválido.", "tamanho")
    try:
        bruto = assinatura_txt.decode("ascii") if isinstance(assinatura_txt, (bytes, bytearray)) else str(assinatura_txt)
        sig = base64.b64decode(bruto.strip(), validate=True)
    except (ValueError, UnicodeDecodeError):
        raise ErroAtualizacao("A assinatura da atualização é inválida.", "base64")
    try:
        man = json.loads(bytes(dados).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ErroAtualizacao("O manifesto da atualização é inválido.", "json")
    if not isinstance(man, dict):
        raise ErroAtualizacao("O manifesto da atualização é inválido.", "não é objeto")
    chaves = chaves if chaves is not None else chaves_aceitas()
    pub = chaves.get(str(man.get("chave", "")))
    if not pub:
        raise ErroAtualizacao("A atualização foi assinada com uma chave que este app não conhece.",
                              "chave %r" % man.get("chave"))
    if not ed25519_verificar(bytes.fromhex(pub), bytes(dados), sig):
        raise ErroAtualizacao("A assinatura da atualização não confere: o pacote não foi publicado pelo yPeléTools "
                              "ou foi alterado.", "assinatura inválida")
    if man.get("formato") != FORMATO_MANIFESTO or man.get("produto") != PRODUTO:
        raise ErroAtualizacao("O manifesto da atualização é de outro formato ou produto.", repr(man.get("formato")))
    if man.get("repositorio") != REPOSITORIO:
        raise ErroAtualizacao("O manifesto da atualização é de outro repositório.", repr(man.get("repositorio")))
    versao = man.get("versao")
    if not ler_versao(versao) or man.get("tag") != "v" + str(versao):
        raise ErroAtualizacao("A versão do manifesto é inválida.", "%r / %r" % (versao, man.get("tag")))
    pacotes = man.get("pacotes")
    if not isinstance(pacotes, list) or not pacotes:
        raise ErroAtualizacao("O manifesto não tem pacotes.")
    for pc in pacotes:
        _validar_pacote_manifesto(pc)
    return man


def _validar_pacote_manifesto(pc) -> None:
    if not isinstance(pc, dict):
        raise ErroAtualizacao("Pacote inválido no manifesto.")
    if not re.fullmatch(r"[A-Za-z0-9_.\-]+\.zip", str(pc.get("arquivo", ""))):
        raise ErroAtualizacao("Nome de pacote inválido no manifesto.", repr(pc.get("arquivo")))
    if not re.fullmatch(r"[0-9a-f]{64}", str(pc.get("sha256", ""))):
        raise ErroAtualizacao("SHA-256 inválido no manifesto.")
    if not isinstance(pc.get("tamanho"), int) or not 0 < pc["tamanho"] <= LIMITE_PACOTE:
        raise ErroAtualizacao("Tamanho de pacote inválido no manifesto.")
    arqs = pc.get("arquivos")
    if not isinstance(arqs, list) or not arqs or len(arqs) > LIMITE_ARQUIVOS:
        raise ErroAtualizacao("Lista de arquivos inválida no manifesto.")
    vistos = set()
    for a in arqs:
        if not isinstance(a, dict) or not caminho_seguro(a.get("caminho")):
            raise ErroAtualizacao("Caminho não permitido no manifesto.", repr(a))
        if a["caminho"].lower() in vistos:
            raise ErroAtualizacao("Arquivo repetido no manifesto.", a["caminho"])
        vistos.add(a["caminho"].lower())
        if not re.fullmatch(r"[0-9a-f]{64}", str(a.get("sha256", ""))) or not isinstance(a.get("tamanho"), int) \
                or a["tamanho"] < 0:
            raise ErroAtualizacao("Hash ou tamanho inválido no manifesto.", a["caminho"])
    if pc.get("distribuicao") == DISTRIBUICAO_INSTALADOR:
        for ob in OBRIGATORIOS:
            if ob not in vistos:
                raise ErroAtualizacao("O pacote não traz %s." % ob)


def escolher_pacote(man: dict, distribuicao: str):
    for pc in man.get("pacotes", []):
        if pc.get("distribuicao") == distribuicao:
            return pc
    return None


def validar_zip(dados: bytes, pacote: dict, versao: str) -> dict:
    """Confere o pacote baixado contra o manifesto (já verificado): SHA-256 do arquivo, só os arquivos listados, cada um
    com o hash certo, nada fora das pastas permitidas, sem links e sem compactação exagerada. Devolve {caminho: bytes}."""
    if len(dados) != pacote["tamanho"] or hashlib.sha256(dados).hexdigest() != pacote["sha256"]:
        raise ErroAtualizacao("O pacote baixado não confere com o manifesto (SHA-256 ou tamanho diferente). Ele foi "
                              "apagado; tente de novo.", "sha/tamanho")
    try:
        z = zipfile.ZipFile(io.BytesIO(dados))
    except zipfile.BadZipFile:
        raise ErroAtualizacao("O pacote da atualização está corrompido.", "zip inválido")
    esperados = {a["caminho"]: a for a in pacote["arquivos"]}
    infos = z.infolist()
    if len(infos) > LIMITE_ARQUIVOS:
        raise ErroAtualizacao("O pacote da atualização tem arquivos demais.")
    total, saida = 0, {}
    for info in infos:
        nome = info.filename
        if info.is_dir():
            continue
        if not caminho_seguro(nome) or nome not in esperados:
            raise ErroAtualizacao("O pacote tem um arquivo não permitido: %s" % nome[:120], "fora da lista")
        tipo = (info.external_attr >> 16) & 0o170000
        if tipo == 0o120000:
            raise ErroAtualizacao("O pacote tem um link simbólico (%s)." % nome, "symlink")
        if info.flag_bits & 0x1:
            raise ErroAtualizacao("O pacote tem um arquivo criptografado.", nome)
        total += info.file_size
        if total > LIMITE_DESCOMPACTADO or (info.compress_size and info.file_size / info.compress_size > LIMITE_TAXA):
            raise ErroAtualizacao("O pacote da atualização tem tamanho suspeito.", nome)
        conteudo = z.read(info)
        esp = esperados[nome]
        if len(conteudo) != esp["tamanho"] or hashlib.sha256(conteudo).hexdigest() != esp["sha256"]:
            raise ErroAtualizacao("Um arquivo do pacote não confere com o manifesto: %s" % nome, "hash do arquivo")
        if nome in saida:
            raise ErroAtualizacao("Arquivo repetido no pacote: %s" % nome)
        saida[nome] = conteudo
    faltam = set(esperados) - set(saida)
    if faltam:
        raise ErroAtualizacao("O pacote não tem todos os arquivos do manifesto.", ", ".join(sorted(faltam))[:300])
    app = saida.get("app/ypele_tools.py")
    if app is not None and versao_do_app(app) != versao:
        raise ErroAtualizacao("A versão dentro do pacote (%s) não é a anunciada (%s)." % (versao_do_app(app), versao))
    return saida


# ----------------------------------------------------------------------------------------------------------------------
# GitHub: Releases, manifesto e download (sem token: a API pública basta para um repositório público)
# ----------------------------------------------------------------------------------------------------------------------
class _SoRedirecionamentosConfiaveis(urllib.request.HTTPRedirectHandler):
    def __init__(self, hosts: set):
        super().__init__()
        self.hosts = hosts

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u = urllib.parse.urlsplit(newurl)
        teste = modo_teste()
        ok = (u.scheme == "https" and u.hostname in self.hosts) or (teste and u.netloc == teste["host"])
        if not ok:
            raise ErroAtualizacao("O download foi redirecionado para um endereço que não é do GitHub.", newurl[:200])
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _abrir(url: str, cabecalhos: dict = None, timeout: int = 20, hosts: set = None, inicio: int = 0):
    req = urllib.request.Request(url, headers={"User-Agent": UA, **(cabecalhos or {})})
    if inicio:
        req.add_header("Range", "bytes=%d-" % inicio)
    abridor = urllib.request.build_opener(_SoRedirecionamentosConfiaveis(hosts or {"api.github.com"}))
    return abridor.open(req, timeout=timeout)


def url_de_download_valida(url: str) -> bool:
    u = urllib.parse.urlsplit(str(url or ""))
    teste = modo_teste()
    if teste and u.scheme == "http" and u.netloc == teste["host"]:
        return u.path.startswith(PREFIXO_DOWNLOAD)
    return u.scheme == "https" and u.hostname == "github.com" and u.path.startswith(PREFIXO_DOWNLOAD)


def _erro_http(e: Exception) -> ErroAtualizacao:
    if isinstance(e, urllib.error.HTTPError):
        if e.code in (403, 429):
            reset = e.headers.get("X-RateLimit-Reset") if e.headers else None
            restante = e.headers.get("X-RateLimit-Remaining") if e.headers else None
            if restante == "0" or e.code == 429:
                quando = ""
                if reset and reset.isdigit():
                    quando = " (de novo depois das %s)" % datetime.datetime.fromtimestamp(int(reset)).strftime("%H:%M")
                err = ErroAtualizacao("O GitHub limitou as consultas por agora%s." % quando, "HTTP %d" % e.code)
                err.reset = int(reset) if reset and reset.isdigit() else int(time.time()) + 3600
                return err
            return ErroAtualizacao("O GitHub recusou a consulta (HTTP %d)." % e.code, "HTTP %d" % e.code)
        return ErroAtualizacao("O GitHub respondeu com erro (HTTP %d)." % e.code, "HTTP %d" % e.code)
    texto = str(getattr(e, "reason", "") or e)
    if "CERTIFICATE" in texto.upper():
        return ErroAtualizacao("A conexão segura com o GitHub não pôde ser verificada (certificado).", texto)
    return ErroAtualizacao("Sem conexão com o GitHub agora.", texto)


def _ler_json(resp, limite: int = 2 * 1024 * 1024):
    dados = resp.read(limite + 1)
    if len(dados) > limite:
        raise ErroAtualizacao("Resposta grande demais do GitHub.")
    try:
        return json.loads(dados.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ErroAtualizacao("O GitHub respondeu algo que não é JSON.")


def consultar_ultima_release(etag: str = "") -> dict:
    """GET /releases/latest. Devolve {"status": 200|304|404, "release": dict|None, "etag": str}. A API já ignora
    rascunhos e pré-lançamentos neste endpoint; mesmo assim eles são recusados aqui."""
    teste = modo_teste()
    url = teste.get("api") or API_ULTIMA
    cab = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if etag:
        cab["If-None-Match"] = etag
    try:
        with _abrir(url, cab, timeout=15) as r:
            rel = _ler_json(r)
            novo_etag = r.headers.get("ETag", "")
    except urllib.error.HTTPError as e:
        if e.code == 304:
            return {"status": 304, "release": None, "etag": etag}
        if e.code == 404:
            return {"status": 404, "release": None, "etag": ""}
        raise _erro_http(e)
    except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, http.client.HTTPException,
            OSError) as e:
        raise _erro_http(e)
    if not isinstance(rel, dict) or not isinstance(rel.get("tag_name"), str):
        raise ErroAtualizacao("A resposta do GitHub não tem a versão (tag).")
    return {"status": 200, "release": resumo_release(rel), "etag": novo_etag}


def consultar_lista_releases(limite: int = 30) -> list:
    """GET /releases (as mais recentes). Beta 3.7: o app não depende só da Release marcada como "latest" no GitHub
    (ela pode apontar para uma versão menor se uma correção antiga for publicada depois, ou se a marcação for esquecida):
    a maior versão ESTÁVEL publicada vale. Qualquer falha aqui devolve [] (a consulta principal continua valendo)."""
    teste = modo_teste()
    if teste:
        base = teste["api"]
        url = base[:-len("/latest")] if base.endswith("/latest") else base
    else:
        url = API_LISTA
    url += ("&" if "?" in url else "?") + "per_page=%d" % max(1, min(100, int(limite)))
    cab = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    try:
        with _abrir(url, cab, timeout=15) as r:
            lst = _ler_json(r)
    except Exception:
        return []
    if not isinstance(lst, list):
        return []
    return [resumo_release(x) for x in lst if isinstance(x, dict) and isinstance(x.get("tag_name"), str)]


def maior_release_estavel(releases: list, versao_instalada: str):
    """A Release estável (não rascunho, não pré-lançamento, tag vX.Y.Z sem sufixo) de MAIOR versão, se ela for mais nova
    que a instalada e tiver o manifesto assinado anexado. Nunca devolve uma versão igual ou menor (sem rebaixar)."""
    melhor = None
    for rel in releases:
        if not isinstance(rel, dict) or rel.get("rascunho") or rel.get("pre"):
            continue
        tag = str(rel.get("tag") or "")
        if not ler_versao(tag) or not e_estavel(tag):
            continue
        v = tag.lstrip("v")
        try:
            if comparar_versoes(v, versao_instalada) <= 0:
                continue
        except ValueError:
            continue
        nomes = {a.get("nome") for a in rel.get("ativos") or []}
        if ARQ_MANIFESTO not in nomes or ARQ_ASSINATURA not in nomes:
            continue
        if melhor is None or comparar_versoes(v, melhor["tag"].lstrip("v")) > 0:
            melhor = rel
    return melhor


def resumo_release(rel: dict) -> dict:
    """Só o que o app usa da Release (o resto da resposta da API é descartado)."""
    ativos = []
    for a in rel.get("assets") or []:
        if isinstance(a, dict) and isinstance(a.get("name"), str):
            ativos.append({"nome": a["name"], "url": str(a.get("browser_download_url", "")),
                           "tamanho": int(a.get("size") or 0), "estado": str(a.get("state", "uploaded"))})
    return {"tag": rel.get("tag_name", ""), "nome": str(rel.get("name") or rel.get("tag_name") or ""),
            "rascunho": bool(rel.get("draft")), "pre": bool(rel.get("prerelease")),
            "notas": str(rel.get("body") or "")[:20000], "pagina": str(rel.get("html_url") or URL_RELEASES),
            "publicada": str(rel.get("published_at") or ""), "ativos": ativos}


def baixar_pequeno(url: str, limite: int = LIMITE_MANIFESTO) -> bytes:
    if not url_de_download_valida(url):
        raise ErroAtualizacao("Endereço de download fora do repositório oficial.", url[:200])
    try:
        with _abrir(url, timeout=20, hosts=HOSTS_DOWNLOAD) as r:
            dados = r.read(limite + 1)
    except urllib.error.HTTPError as e:
        raise _erro_http(e)
    except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, http.client.HTTPException,
            OSError) as e:
        raise _erro_http(e)
    if len(dados) > limite:
        raise ErroAtualizacao("Arquivo grande demais para um manifesto.")
    return dados


def baixar_pacote(url: str, destino: Path, tamanho: int, sha256: str, progresso=None, cancelado=None) -> bytes:
    """Baixa com retomada (Range) e confere tamanho e SHA-256. Devolve os bytes do pacote (já conferidos)."""
    if not url_de_download_valida(url):
        raise ErroAtualizacao("Endereço do pacote fora do repositório oficial.", url[:200])
    destino.parent.mkdir(parents=True, exist_ok=True)
    if destino.exists():
        dados = destino.read_bytes()
        if len(dados) == tamanho and hashlib.sha256(dados).hexdigest() == sha256:
            if progresso:
                progresso(tamanho, tamanho)
            return dados
        destino.unlink()
    parcial = destino.with_name(destino.name + ".parcial")
    tentativas = 0
    while True:
        if cancelado and cancelado():
            raise ErroAtualizacao("Download cancelado.", "cancelado")
        inicio = parcial.stat().st_size if parcial.exists() else 0
        if inicio > tamanho:
            parcial.unlink()
            inicio = 0
        if inicio == tamanho and tamanho:
            break
        try:
            with _abrir(url, timeout=30, hosts=HOSTS_DOWNLOAD, inicio=inicio) as r:
                if inicio and r.status != 206:
                    inicio = 0
                feito = inicio
                with open(parcial, "ab" if inicio else "wb") as f:
                    while True:
                        if cancelado and cancelado():
                            raise ErroAtualizacao("Download cancelado.", "cancelado")
                        bloco = r.read(128 * 1024)
                        if not bloco:
                            break
                        feito += len(bloco)
                        if feito > tamanho:
                            raise ErroAtualizacao("O pacote baixado é maior que o anunciado.", "tamanho")
                        f.write(bloco)
                        if progresso:
                            progresso(feito, tamanho)
            if parcial.stat().st_size < tamanho:
                raise ConnectionError("download interrompido")
            break
        except ErroAtualizacao:
            raise
        except urllib.error.HTTPError as e:
            if e.code == 416 and inicio:
                break
            tentativas += 1
            if e.code in (404, 410) or tentativas >= 4:
                raise _erro_http(e)
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, http.client.HTTPException,
                OSError) as e:
            tentativas += 1
            if tentativas >= 4:
                raise ErroAtualizacao("O download do pacote foi interrompido. Ele continua de onde parou na próxima "
                                      "tentativa.", str(e))
        for _ in range(int(2 * tentativas / 0.1)):
            if cancelado and cancelado():
                raise ErroAtualizacao("Download cancelado.", "cancelado")
            time.sleep(0.1)
    dados = parcial.read_bytes()
    if len(dados) != tamanho or hashlib.sha256(dados).hexdigest() != sha256:
        parcial.unlink()
        raise ErroAtualizacao("O pacote baixado veio corrompido (SHA-256 diferente). Ele foi apagado; tente de novo.",
                              "sha256")
    os.replace(parcial, destino)
    return dados


def procurar_atualizacao(versao_instalada: str, distribuicao: str, etag: str = "") -> dict:
    """Consulta o GitHub e, se houver versão nova, baixa e confere o manifesto assinado.
    Devolve {"estado": "disponivel"|"atualizado"|"sem_release"|"sem_mudanca", ...}. Erros saem como ErroAtualizacao."""
    r = consultar_ultima_release(etag)
    if r["status"] == 304:
        return {"estado": "sem_mudanca", "etag": etag}
    if r["status"] == 404:
        return {"estado": "sem_release", "etag": ""}
    rel = r["release"]
    # Beta 3.7: a maior versão estável entre a "latest" e as Releases recentes (atualização direta de qualquer versão
    # antiga para a mais nova; nunca uma menor por erro de marcação no GitHub)
    escolhida = maior_release_estavel([rel] + consultar_lista_releases(), versao_instalada)
    if escolhida is None:
        if rel["rascunho"] or rel["pre"]:
            return {"estado": "atualizado", "etag": r["etag"], "release": rel, "motivo": "pré-lançamento ignorado"}
        if not ler_versao(rel["tag"]) or not e_estavel(rel["tag"]):
            return {"estado": "atualizado", "etag": r["etag"], "release": rel, "motivo": "tag sem versão estável"}
        remota = rel["tag"].lstrip("v")
        if comparar_versoes(remota, versao_instalada) > 0:
            raise ErroAtualizacao("A versão %s foi publicada sem o manifesto do atualizador." % remota, "sem manifesto")
        return {"estado": "atualizado", "etag": r["etag"], "release": rel}
    rel = escolhida
    remota = rel["tag"].lstrip("v")
    ativos = {a["nome"]: a for a in rel["ativos"]}
    if ARQ_MANIFESTO not in ativos or ARQ_ASSINATURA not in ativos:
        raise ErroAtualizacao("A versão %s foi publicada sem o manifesto do atualizador." % remota, "sem manifesto")
    man_bytes = baixar_pequeno(ativos[ARQ_MANIFESTO]["url"])
    sig = baixar_pequeno(ativos[ARQ_ASSINATURA]["url"], 4096)
    man = verificar_manifesto(man_bytes, sig)
    if man["versao"] != remota:
        raise ErroAtualizacao("O manifesto (%s) não é da versão da Release (%s)." % (man["versao"], remota))
    pacote = escolher_pacote(man, distribuicao)
    url_pacote = ""
    if pacote is not None:
        ativo = ativos.get(pacote["arquivo"])
        if ativo is None:
            raise ErroAtualizacao("A Release não tem o pacote %s." % pacote["arquivo"])
        url_pacote = ativo["url"]
    return {"estado": "disponivel", "etag": r["etag"], "release": rel, "manifesto": man,
            "manifesto_b64": base64.b64encode(man_bytes).decode("ascii"),
            "assinatura": sig.decode("ascii", "replace").strip(), "pacote": pacote, "url_pacote": url_pacote}


def revalidar_cache(dados: dict, versao_instalada: str, distribuicao: str) -> dict:
    """Um resultado 'disponivel' guardado em disco só vale se o manifesto ainda passar na assinatura."""
    if not dados or dados.get("estado") != "disponivel":
        return dados or {}
    man = verificar_manifesto(base64.b64decode(dados["manifesto_b64"]), dados["assinatura"])
    if comparar_versoes(man["versao"], versao_instalada) <= 0:
        return {"estado": "atualizado", "release": dados.get("release")}
    pacote = escolher_pacote(man, distribuicao)
    if (pacote or {}).get("sha256") != (dados.get("pacote") or {}).get("sha256"):
        raise ErroAtualizacao("cache inconsistente")
    if dados.get("url_pacote") and not url_de_download_valida(dados["url_pacote"]):
        raise ErroAtualizacao("cache com endereço inválido")
    dados["manifesto"] = man
    return dados


# ----------------------------------------------------------------------------------------------------------------------
# Instalação (roda no processo do atualizador, com o app FECHADO)
# ----------------------------------------------------------------------------------------------------------------------
def pasta_gravavel(p: Path) -> bool:
    try:
        p.mkdir(parents=True, exist_ok=True)
        teste = p / (".ypele_teste_%d_%d" % (os.getpid(), threading.get_ident()))
        teste.write_bytes(b"ok")
        teste.unlink()
        return True
    except OSError:
        return False


def versao_instalada(raiz: Path) -> str:
    try:
        est = json.loads((raiz / "instalacao.json").read_text(encoding="utf-8"))
        if ler_versao(est.get("versao_semver", "")):
            return est["versao_semver"]
    except (OSError, ValueError, AttributeError):
        pass
    try:
        v = versao_do_app((raiz / "app" / "ypele_tools.py").read_bytes())
        if ler_versao(v):
            return v
    except OSError:
        pass
    return "0.0.0"


# ----------------------------------------------------------------------------------------------------------------------
# Troca de arquivos (Beta 3.9.0)
#
# Na atualização 3.8.0 -> 3.8.2 o os.replace do app\ypele.ico deu "[WinError 5] Acesso negado" e a restauração falhou do
# mesmo jeito, no mesmo instante. No Windows, isso acontece quando OUTRO processo está com o arquivo de destino aberto
# sem permitir exclusão (FILE_SHARE_DELETE) - o Explorer faz isso ao ler ícones - ou quando o arquivo é somente
# leitura (testado num Windows 11 de verdade). O arquivo nem precisava ser trocado: era idêntico. Por isso:
#   - arquivo já idêntico ao do pacote não é regravado;
#   - antes de mexer em qualquer coisa, cada destino é conferido (abrir com permissão de exclusão); se outro processo
#     estiver com ele, espera um pouco e anota no log QUEM é (Restart Manager do Windows); se continuar preso, para
#     ANTES de trocar qualquer arquivo;
#   - os arquivos novos são gravados e conferidos ao lado (.novo-ypele) antes da troca; a troca em si tenta de novo
#     algumas vezes, com espera crescente (nunca para sempre), e tira o "somente leitura";
#   - um diário (atualizacao\transacao.json) diz o que já foi trocado; a restauração confere cada arquivo pelo SHA-256 e,
#     se não conseguir terminar, o diário e os backups ficam para a recuperação continuar depois (--recuperar).
# ----------------------------------------------------------------------------------------------------------------------
SUFIXO_NOVO = ".novo-ypele"
ESPERAS_TROCA = (0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 1.6, 2.0, 2.5)        # ~9 s no total, por arquivo
ESPERA_PREVIA = 15.0                                                # tempo máximo esperando um destino ser liberado
ERROS_DE_TRAVA = {5, 32, 33}            # acesso negado, compartilhamento, bloqueio (Windows)
ARQ_DIARIO = "transacao.json"


class ErroTroca(OSError):
    """Um arquivo não pôde ser trocado (preso por outro programa, sem permissão...)."""


def _sha(dados: bytes) -> str:
    return hashlib.sha256(dados).hexdigest()


def sha_do_arquivo(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def _erro_de_trava(e: OSError) -> bool:
    if isinstance(e, PermissionError):
        return True
    return getattr(e, "winerror", None) in ERROS_DE_TRAVA


def quem_usa(caminhos) -> list:
    """Windows: nomes dos programas que estão com estes arquivos abertos (Restart Manager). Só para o log."""
    if not WINDOWS:
        return []
    try:
        import ctypes.wintypes as wt
        rm = ctypes.WinDLL("rstrtmgr")

        class _Unico(ctypes.Structure):
            _fields_ = [("pid", wt.DWORD), ("inicio", wt.FILETIME)]

        class _Info(ctypes.Structure):
            _fields_ = [("processo", _Unico), ("nome", wt.WCHAR * 256), ("servico", wt.WCHAR * 64),
                        ("tipo", ctypes.c_int), ("estado", wt.ULONG), ("sessao", wt.DWORD), ("reiniciavel", wt.BOOL)]
        sessao = wt.DWORD()
        chave = ctypes.create_unicode_buffer(64)
        if rm.RmStartSession(ctypes.byref(sessao), 0, chave):
            return []
        try:
            lista = [str(c) for c in caminhos]
            arr = (ctypes.c_wchar_p * len(lista))(*lista)
            if rm.RmRegisterResources(sessao, len(lista), arr, 0, None, 0, None):
                return []
            precisa, n, motivo = wt.UINT(0), wt.UINT(0), wt.DWORD()
            rm.RmGetList(sessao, ctypes.byref(precisa), ctypes.byref(n), None, ctypes.byref(motivo))
            if not precisa.value:
                return []
            n = wt.UINT(precisa.value)
            info = (_Info * n.value)()
            if rm.RmGetList(sessao, ctypes.byref(precisa), ctypes.byref(n), info, ctypes.byref(motivo)):
                return []
            return ["%s (pid %d)" % (info[i].nome or "?", info[i].processo.pid) for i in range(n.value)]
        finally:
            rm.RmEndSession(sessao)
    except Exception:
        return []


def _tirar_somente_leitura(p: Path) -> None:
    try:
        if p.exists() and not os.access(p, os.W_OK):
            os.chmod(p, 0o666)
    except OSError:
        pass


def pode_substituir(p: Path) -> bool:
    """O arquivo pode ser trocado agora? (Windows: abrir com permissão de EXCLUSÃO falha se outro processo estiver com
    ele aberto sem permitir isso, que é exatamente o que derruba o os.replace.)"""
    if not WINDOWS or not p.exists():
        return True
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateFileW.restype = ctypes.c_void_p
    k32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32,
                                ctypes.c_uint32, ctypes.c_void_p]
    h = k32.CreateFileW(str(p), 0x00010000, 0x7, None, 3, 0x02000000, None)   # DELETE; compartilha tudo
    if h in (None, ctypes.c_void_p(-1).value):
        return False
    k32.CloseHandle(ctypes.c_void_p(h))
    return True


def _substituir(tmp: Path, destino: Path, log=None, rotulo: str = "") -> int:
    """os.replace com tentativas limitadas. Devolve quantas tentativas foram precisas. Levanta ErroTroca no fim."""
    ultimo = None
    for i, espera in enumerate((0.0,) + ESPERAS_TROCA, 1):
        if espera:
            time.sleep(espera)
        _tirar_somente_leitura(destino)
        try:
            os.replace(tmp, destino)
            if i > 1 and log:
                log("  %s: trocado na tentativa %d." % (rotulo or destino.name, i))
            return i
        except OSError as e:
            ultimo = e
            if not _erro_de_trava(e):
                break
            if log and i in (1, 4, len(ESPERAS_TROCA) + 1):
                quem = quem_usa([destino])
                log("  %s: tentativa %d falhou (%s)%s" % (rotulo or destino.name, i, e,
                                                          ("; em uso por: " + ", ".join(quem)) if quem else ""))
    quem = quem_usa([destino])
    raise ErroTroca("%s não pôde ser trocado: %s%s" % (rotulo or destino.name, ultimo,
                                                      (" (em uso por: %s)" % ", ".join(quem)) if quem else ""))


def gravar_conferido(destino: Path, dados: bytes) -> Path:
    """Grava `dados` ao lado de `destino` (.novo-ypele), força para o disco e confere o SHA-256. Devolve o temporário."""
    destino.parent.mkdir(parents=True, exist_ok=True)
    tmp = destino.with_name(destino.name + SUFIXO_NOVO)
    _tirar_somente_leitura(tmp)
    with open(tmp, "wb") as f:
        f.write(dados)
        f.flush()
        os.fsync(f.fileno())
    if sha_do_arquivo(tmp) != _sha(dados):
        raise ErroTroca("A cópia de %s não ficou igual ao conferido." % destino.name)
    return tmp


def _gravar_atomico(destino: Path, dados: bytes, log=None, rotulo: str = "") -> None:
    tmp = gravar_conferido(destino, dados)
    try:
        _substituir(tmp, destino, log, rotulo)
    except OSError:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def limpar_sobras(raiz: Path) -> list:
    """Apaga os .novo-ypele que uma atualização interrompida deixou (só ao lado de um arquivo de verdade)."""
    apagados = []
    for pasta in (Path(raiz) / "app", Path(raiz) / "desinstalar"):
        try:
            for p in pasta.glob("*" + SUFIXO_NOVO):
                try:
                    p.unlink()
                    apagados.append(str(p))
                except OSError:
                    pass
        except OSError:
            pass
    return apagados


def _sem_janela() -> dict:
    if not WINDOWS:
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return {"creationflags": 0x08000000, "startupinfo": si}


def _ambiente_python() -> dict:
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("PYTHON")}
    env.update(PYTHONNOUSERSITE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PIP_NO_INPUT="1",
               PIP_DISABLE_PIP_VERSION_CHECK="1")
    return env


class Instalacao:
    """Aplica um pacote verificado sobre a instalação, com backup, diário e restauração conferida."""

    def __init__(self, raiz: Path, log=None, etapa=None):
        self.raiz = Path(raiz)
        self.log = log or (lambda *_: None)
        self.etapa = etapa or (lambda *_: None)
        self.pasta = self.raiz / "atualizacao"
        self.backup = None
        self.novos: list = []
        self.trocados: list = []
        self.iguais: list = []
        self.diario: dict = {}

    # -- diário
    @property
    def arq_diario(self) -> Path:
        return self.pasta / ARQ_DIARIO

    def _gravar_diario(self) -> None:
        self.pasta.mkdir(parents=True, exist_ok=True)
        _gravar_atomico(self.arq_diario, json.dumps(self.diario, ensure_ascii=False, indent=1).encode("utf-8"))

    @staticmethod
    def diario_pendente(raiz: Path) -> dict:
        """O diário de uma atualização que não terminou (o app chama isto ao abrir). {} se não houver."""
        try:
            d = json.loads((Path(raiz) / "atualizacao" / ARQ_DIARIO).read_text(encoding="utf-8"))
            return d if isinstance(d, dict) and d.get("estado") in ("aplicando", "restauracao_pendente") else {}
        except (OSError, ValueError):
            return {}

    # -- backup / restauração
    def _preparar_backup(self, versao_antiga: str) -> Path:
        dest = self.pasta / "backups" / ("%s_%s" % (versao_antiga, datetime.datetime.now().strftime("%Y%m%d-%H%M%S")))
        dest.mkdir(parents=True, exist_ok=True)
        return dest

    def _restaurar(self) -> list:
        """Desfaz o que o diário marca como feito, do último para o primeiro, conferindo cada arquivo pelo SHA-256.
        Devolve a lista de problemas (vazia = tudo voltou exatamente como era)."""
        problemas = []
        itens = self.diario.get("arquivos", [])
        backup = Path(self.diario.get("backup") or self.backup or "")
        for it in reversed(itens):
            if not it.get("mexido"):
                continue
            rel = it["rel"]
            alvo = self.raiz / rel
            try:
                if it["acao"] == "novo":
                    if alvo.exists():
                        for espera in (0.0,) + ESPERAS_TROCA:
                            time.sleep(espera)
                            try:
                                alvo.unlink()
                                break
                            except OSError as e:
                                if not _erro_de_trava(e):
                                    raise
                        if alvo.exists():
                            raise ErroTroca("%s não pôde ser apagado" % rel)
                else:
                    copia = backup / rel
                    dados = copia.read_bytes()
                    if _sha(dados) != it["sha_antigo"]:
                        raise ErroTroca("o backup de %s não confere" % rel)
                    if not (alvo.exists() and sha_do_arquivo(alvo) == it["sha_antigo"]):
                        _gravar_atomico(alvo, dados, self.log, rel)
                    if sha_do_arquivo(alvo) != it["sha_antigo"]:
                        raise ErroTroca("%s restaurado não confere com o backup" % rel)
                it["mexido"] = False
                self._gravar_diario()
            except OSError as e:
                problemas.append("%s: %s" % (rel, e))
        est = backup / "instalacao.json"
        if est.exists() and self.diario.get("instalacao_trocada"):
            try:
                _gravar_atomico(self.raiz / "instalacao.json", est.read_bytes(), self.log, "instalacao.json")
                self.diario["instalacao_trocada"] = False
            except OSError as e:
                problemas.append("instalacao.json: %s" % e)
        if problemas:
            self.diario["estado"] = "restauracao_pendente"
            self.diario["problemas"] = problemas
            try:
                self._gravar_diario()
            except OSError:
                pass
        else:
            self._encerrar_diario("restaurada")
        return problemas

    def _encerrar_diario(self, como: str) -> None:
        try:
            self.arq_diario.unlink()
        except OSError:
            pass
        self.log("Diário da atualização encerrado (%s)." % como)

    def recuperar(self) -> list:
        """Retoma a restauração de uma atualização que não terminou (diário em atualizacao\\transacao.json)."""
        d = self.diario_pendente(self.raiz)
        if not d:
            return []
        self.diario = d
        self.backup = Path(d.get("backup") or "")
        self.log("Recuperando a atualização %s -> %s que não terminou (estado: %s)..."
                 % (d.get("de"), d.get("para"), d.get("estado")))
        problemas = self._restaurar()
        if problemas:
            self.log("Recuperação ainda com problemas: " + "; ".join(problemas))
        else:
            self.log("Recuperação concluída: a versão %s voltou, arquivo por arquivo conferido." % d.get("de"))
            limpar_sobras(self.raiz)
        return problemas

    def _limpar_backups_antigos(self, manter: int = 2) -> None:
        pasta = self.pasta / "backups"
        try:
            antigos = sorted((p for p in pasta.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
        except OSError:
            return
        for p in antigos[manter:]:
            shutil.rmtree(p, ignore_errors=True)

    # -- dependências
    def _pip(self, requisitos: Path) -> None:
        py = self.raiz / "runtime" / ("python.exe" if WINDOWS else "bin/python3")
        if not py.exists():
            raise ErroAtualizacao("O Python do app não foi encontrado para atualizar as dependências.", str(py))
        # o instalador não instala o imageio-ffmpeg (o FFmpeg completo já vem com ele): aqui também não
        linhas = []
        for linha in Path(requisitos).read_text(encoding="utf-8").splitlines():
            nome = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)", linha.split("#", 1)[0])
            if nome and re.sub(r"[-_.]+", "-", nome.group(1)).lower() in PIP_IGNORAR:
                continue
            linhas.append(linha)
        filtrado = self.pasta / "requirements-atualizacao.txt"
        filtrado.parent.mkdir(parents=True, exist_ok=True)
        filtrado.write_text("\n".join(linhas) + "\n", encoding="utf-8")
        cmd = [str(py), "-I", "-m", "pip", "install", "--only-binary", ":all:", "--upgrade-strategy", "only-if-needed",
               "--no-warn-script-location", "-r", str(filtrado)]
        indice = os.environ.get("YPELE_SETUP_INDICE") if modo_teste() else None
        if indice:
            cmd[cmd.index("install") + 1:cmd.index("install") + 1] = ["--index-url", indice]
        self.log("pip: " + " ".join(cmd[1:]))
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800,
                           env=_ambiente_python(), cwd=str(self.raiz), **_sem_janela())
        for linha in (r.stdout + r.stderr).splitlines()[-40:]:
            self.log("  " + linha)
        if r.returncode != 0:
            erros = [l for l in (r.stdout + r.stderr).splitlines() if l.startswith("ERROR:")]
            raise ErroAtualizacao("As dependências novas não puderam ser instaladas (%s)."
                                  % (erros[-1][6:].strip()[:160] if erros else "veja o log"), "pip %d" % r.returncode)

    def _conferir_app(self) -> None:
        py = self.raiz / "runtime" / ("python.exe" if WINDOWS else "bin/python3")
        if not py.exists():
            py = Path(sys.executable)
        codigo = ("import sys, ast; [ast.parse(open(p, encoding='utf-8').read()) for p in sys.argv[1:]]; "
                  "print('@@ok')")
        alvos = [str(self.raiz / "app" / "ypele_tools.py"), str(self.raiz / "app" / "ypele_atualizador.py")]
        r = subprocess.run([str(py), "-I", "-c", codigo, *alvos], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=180, env=_ambiente_python(), **_sem_janela())
        if "@@ok" not in r.stdout:
            raise ErroAtualizacao("Os arquivos novos não passaram na conferência final.", (r.stdout + r.stderr)[-500:])

    def _conferir_instalados(self, arquivos: dict) -> None:
        """Cada arquivo do pacote, já no lugar, tem de ser exatamente o conferido (SHA-256)."""
        errados = []
        for rel, dados in arquivos.items():
            alvo = self.raiz / rel
            try:
                if sha_do_arquivo(alvo) != _sha(dados):
                    errados.append(rel)
            except OSError:
                errados.append(rel)
        if errados:
            raise ErroAtualizacao("Arquivos instalados diferentes do pacote conferido: %s." % ", ".join(errados[:5]))

    def _registro(self, versao_nome: str) -> None:
        if not WINDOWS:
            return
        try:
            import winreg
            chave = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\YPeleTools"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, chave, 0, winreg.KEY_READ | winreg.KEY_WRITE) as k:
                local, _t = winreg.QueryValueEx(k, "InstallLocation")
                if Path(local).resolve() == self.raiz.resolve():
                    winreg.SetValueEx(k, "DisplayVersion", 0, winreg.REG_SZ, versao_nome)
        except OSError:
            pass

    def _esperar_liberados(self, alvos: list) -> None:
        """Antes de mexer em qualquer coisa: cada destino precisa poder ser trocado. Espera um pouco por um que esteja
        aberto em outro programa; se continuar preso, a atualização para aqui, sem nada trocado."""
        presos = [a for a in alvos if not pode_substituir(a)]
        if not presos:
            return
        self.log("Arquivos em uso por outro programa: %s%s" % (
            ", ".join(str(a.relative_to(self.raiz)) for a in presos),
            (" (" + ", ".join(quem_usa(presos)) + ")") if quem_usa(presos) else ""))
        self.etapa("copiando", "Esperando outro programa liberar arquivos do yPeléTools...")
        fim = time.time() + ESPERA_PREVIA
        while presos and time.time() < fim:
            time.sleep(0.5)
            presos = [a for a in presos if not pode_substituir(a)]
        if presos:
            quem = quem_usa(presos)
            nomes = ", ".join(str(a.relative_to(self.raiz)) for a in presos)
            raise ErroAtualizacao("Outro programa está usando %s%s. Feche-o (ou aguarde um pouco) e tente de novo; "
                                  "nada foi trocado." % (nomes, (" (" + ", ".join(quem) + ")") if quem else ""),
                                  "presos: %s" % nomes)
        self.log("Arquivos liberados; seguindo.")

    # -- principal
    def aplicar(self, man: dict, arquivos: dict, falhar_em: str = "") -> dict:
        """Instala `arquivos` ({caminho: bytes}, já conferidos). Em qualquer falha, restaura o que foi trocado."""
        antiga = versao_instalada(self.raiz)
        nova = man["versao"]
        if comparar_versoes(nova, antiga) <= 0:
            raise ErroAtualizacao("A versão %s não é mais nova que a instalada (%s)." % (nova, antiga))
        minimo = man.get("minimo_para_atualizar")             # Beta 3.7: opcional; só se uma versão exigir o instalador
        if minimo and ler_versao(minimo) and comparar_versoes(antiga, minimo) < 0:
            raise ErroAtualizacao("A versão %s precisa de uma mudança que o atualizador da %s não faz (mínimo: %s). Use o "
                                  "instalador da versão nova (ele mantém configurações e downloads)." % (nova, antiga,
                                                                                                         minimo))
        pendente = self.diario_pendente(self.raiz)
        if pendente:
            raise ErroAtualizacao("Uma atualização anterior (%s -> %s) não terminou de ser desfeita. Abra o yPeléTools: "
                                  "ele conclui a recuperação antes de atualizar." % (pendente.get("de"),
                                                                                      pendente.get("para")))
        if not pasta_gravavel(self.raiz / "app"):
            raise ErroAtualizacao("Sem permissão para gravar na pasta do yPeléTools.", str(self.raiz))
        limpar_sobras(self.raiz)
        for rel in arquivos:
            if not (self.raiz / rel).resolve().is_relative_to(self.raiz.resolve()):
                raise ErroAtualizacao("Caminho fora da instalação: %s" % rel)
        # 1. plano: o que muda de verdade (o que já é idêntico não é regravado)
        plano = []
        for rel, dados in sorted(arquivos.items()):
            alvo = self.raiz / rel
            sha_novo = _sha(dados)
            if alvo.exists():
                sha_antigo = sha_do_arquivo(alvo)
                if sha_antigo == sha_novo:
                    self.iguais.append(rel)
                    continue
                plano.append({"rel": rel, "acao": "trocar", "sha_antigo": sha_antigo, "sha_novo": sha_novo,
                              "mexido": False})
            else:
                plano.append({"rel": rel, "acao": "novo", "sha_antigo": "", "sha_novo": sha_novo, "mexido": False})
        self.log("Atualizando de %s para %s em %s" % (antiga, nova, self.raiz))
        self.log("  %d arquivo(s) a trocar, %d novo(s), %d já idêntico(s) (não regravados%s)." % (
            sum(1 for p in plano if p["acao"] == "trocar"), sum(1 for p in plano if p["acao"] == "novo"),
            len(self.iguais), (": " + ", ".join(self.iguais)) if len(self.iguais) <= 6 else ""))
        # 2. backup conferido de tudo o que vai mudar
        self.backup = self._preparar_backup(antiga)
        est_arq = self.raiz / "instalacao.json"
        if est_arq.exists():
            shutil.copyfile(est_arq, self.backup / "instalacao.json")
        for it in plano:
            if it["acao"] == "trocar":
                copia = self.backup / it["rel"]
                copia.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(self.raiz / it["rel"], copia)
                if sha_do_arquivo(copia) != it["sha_antigo"]:
                    raise ErroAtualizacao("O backup de %s não ficou igual ao original; nada foi trocado." % it["rel"])
        req_antigo = self.raiz / "app" / "requirements.txt"
        hash_req_antigo = sha_do_arquivo(req_antigo) if req_antigo.exists() else ""
        # 3. destinos liberados? (se não, para aqui: nada foi trocado ainda)
        self.etapa("copiando", "Copiando os arquivos novos...")
        self._esperar_liberados([self.raiz / it["rel"] for it in plano if it["acao"] == "trocar"])
        # 4. arquivos novos gravados e conferidos AO LADO dos atuais (os atuais continuam intactos)
        temporarios = {}
        try:
            for it in plano:
                temporarios[it["rel"]] = gravar_conferido(self.raiz / it["rel"], arquivos[it["rel"]])
        except OSError as e:
            for t in temporarios.values():
                try:
                    t.unlink()
                except OSError:
                    pass
            raise ErroAtualizacao("Não consegui preparar os arquivos novos (%s); nada foi trocado." % e)
        self.diario = {"estado": "aplicando", "de": antiga, "para": nova, "backup": str(self.backup),
                       "inicio": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "arquivos": plano,
                       "instalacao_trocada": False}
        self._gravar_diario()
        try:
            # 5. a troca: só renomeações rápidas, uma por arquivo, anotadas no diário
            for i, it in enumerate(plano, 1):
                rel = it["rel"]
                if it["acao"] == "novo":
                    self.novos.append(rel)
                it["mexido"] = True                 # anotado ANTES: se o processo cair no meio, a recuperação confere
                self._gravar_diario()
                self.trocados.append(rel)
                _substituir(temporarios[rel], self.raiz / rel, self.log, rel)
                self.etapa("progresso", (i, len(plano)))
                if falhar_em == "copia" and i == max(1, len(plano) // 2):
                    raise ErroAtualizacao("Falha simulada no meio da cópia (teste).")
            novo_req = arquivos.get("app/requirements.txt")
            if novo_req is not None and _sha(novo_req) != hash_req_antigo:
                self.etapa("dependencias", "Atualizando as dependências...")
                self._pip(self.raiz / "app" / "requirements.txt")
            self.etapa("conferindo", "Conferindo a instalação...")
            self._conferir_instalados(arquivos)
            self._conferir_app()
            if falhar_em == "conferencia":
                raise ErroAtualizacao("Falha simulada na conferência final (teste).")
            est = {}
            try:
                est = json.loads(est_arq.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
            v = ler_versao(nova)
            est.update(versao=nome_versao(nova, man.get("canal", "Alpha")), versao_semver=nova,
                       versao_num=[v[0], v[1], v[2]], atualizado_em=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                       atualizado_por="atualizador")
            if isinstance(est.get("componentes"), dict) and "app" in est["componentes"]:
                est["componentes"]["app"] = "yPeléTools %s" % nome_versao(nova, man.get("canal", "Alpha"))
            self.diario["instalacao_trocada"] = True
            self._gravar_diario()
            _gravar_atomico(est_arq, json.dumps(est, ensure_ascii=False, indent=2).encode("utf-8"), self.log,
                            "instalacao.json")
            self._registro(nome_versao(nova, man.get("canal", "Alpha")))
        except BaseException as e:
            self.log("FALHA: %s\n%s" % (e, traceback.format_exc()))
            for t in temporarios.values():
                try:
                    if t.exists():
                        t.unlink()
                except OSError:
                    pass
            self.etapa("restaurando", "Restaurando a versão anterior...")
            problemas = self._restaurar()
            if problemas:
                self.log("Restauração com problemas: " + "; ".join(problemas))
                self.log("Os backups ficam em %s e o diário em %s; ao abrir, o yPeléTools tenta concluir a "
                         "recuperação." % (self.backup, self.arq_diario))
            else:
                self.log("Restauração concluída: cada arquivo conferido com o backup.")
            if isinstance(e, ErroAtualizacao):
                e.restaurado = not problemas
                raise
            err = ErroAtualizacao("Erro durante a instalação: %s" % e, traceback.format_exc())
            err.restaurado = not problemas
            raise err
        self._encerrar_diario("concluída")
        self._limpar_backups_antigos()
        return {"de": antiga, "para": nova, "iguais": list(self.iguais), "trocados": list(self.trocados)}


def gravar_resultado(raiz: Path, dados: dict) -> None:
    try:
        pasta = Path(raiz) / "atualizacao"
        pasta.mkdir(parents=True, exist_ok=True)
        dados = dict(dados, quando=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), mostrado=False)
        _gravar_atomico(pasta / "resultado.json", json.dumps(dados, ensure_ascii=False, indent=2).encode("utf-8"))
    except OSError:
        pass


# ----------------------------------------------------------------------------------------------------------------------
# Processos (Windows)
# ----------------------------------------------------------------------------------------------------------------------
def esperar_pid(pid: int, segundos: float) -> bool:
    """Espera o processo `pid` terminar. True se terminou (ou já não existia)."""
    if not pid:
        return True
    if not WINDOWS:
        fim = time.time() + segundos
        while time.time() < fim:
            try:
                os.kill(pid, 0)
            except OSError:
                return True
            time.sleep(0.2)
        return False
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = ctypes.c_void_p
    h = k32.OpenProcess(0x00100000, False, int(pid))            # SYNCHRONIZE
    if not h:
        return True
    try:
        return k32.WaitForSingleObject(ctypes.c_void_p(h), int(segundos * 1000)) == 0
    finally:
        k32.CloseHandle(ctypes.c_void_p(h))


def processos_do_runtime(raiz: Path) -> list:
    """PIDs (fora este) que rodam a partir de <raiz>\\runtime: o app aberto (ou outro atualizador)."""
    if not WINDOWS:
        return []
    import ctypes.wintypes as wt
    psapi, k32 = ctypes.windll.psapi, ctypes.windll.kernel32
    ids = (wt.DWORD * 4096)()
    usado = wt.DWORD()
    if not psapi.EnumProcesses(ctypes.byref(ids), ctypes.sizeof(ids), ctypes.byref(usado)):
        return []
    alvo = str(Path(raiz) / "runtime").lower()
    k32.OpenProcess.restype = ctypes.c_void_p
    achados = []
    for pid in ids[:usado.value // ctypes.sizeof(wt.DWORD)]:
        if not pid or pid == os.getpid():
            continue
        h = k32.OpenProcess(0x1000, False, pid)
        if not h:
            continue
        try:
            buf = ctypes.create_unicode_buffer(1024)
            tam = wt.DWORD(1024)
            if k32.QueryFullProcessImageNameW(ctypes.c_void_p(h), 0, buf, ctypes.byref(tam)):
                if buf.value.lower().startswith(alvo):
                    achados.append(int(pid))
        finally:
            k32.CloseHandle(ctypes.c_void_p(h))
    return achados


def mutex_existe(nome: str) -> bool:
    if not WINDOWS:
        return False
    k32 = ctypes.windll.kernel32
    k32.OpenMutexW.restype = ctypes.c_void_p
    h = k32.OpenMutexW(0x00100000, False, nome)
    if h:
        k32.CloseHandle(ctypes.c_void_p(h))
        return True
    return False


_MUTEX = None


def segurar_mutex(nome: str) -> bool:
    global _MUTEX
    if not WINDOWS:
        return True
    k32 = ctypes.windll.kernel32
    k32.CreateMutexW.restype = ctypes.c_void_p
    _MUTEX = k32.CreateMutexW(None, False, nome)
    return k32.GetLastError() != 183


def rodando_como_admin() -> bool:
    if not WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def iniciar_atualizador(raiz: Path, pacote: Path, manifesto: Path, assinatura: Path, pid: int) -> str:
    """Abre ESTE arquivo como processo independente (com o Python do app). Se a pasta da instalação não permite
    gravação, pede autorização do Windows (UAC). Devolve '' se abriu, senão o motivo."""
    raiz = Path(raiz)
    pythonw = raiz / "runtime" / ("pythonw.exe" if WINDOWS else "bin/python3")
    script = raiz / "app" / "ypele_atualizador.py"
    if not pythonw.exists() or not script.exists():
        return "O atualizador não foi encontrado na pasta do yPeléTools."
    args = ["-I", str(script), "--raiz", str(raiz), "--pacote", str(pacote), "--manifesto", str(manifesto),
            "--assinatura", str(assinatura), "--pid", str(int(pid)), "--reabrir"]
    if pasta_gravavel(raiz / "app"):
        try:
            subprocess.Popen([str(pythonw), *args], cwd=str(raiz), close_fds=True, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             creationflags=(0x00000008 | 0x00000200) if WINDOWS else 0)
            return ""
        except OSError as e:
            return "Não consegui abrir o atualizador: %s" % e
    if not WINDOWS:
        return "Sem permissão para gravar na pasta do yPeléTools."
    # pasta protegida (ex.: Arquivos de Programas): o Windows pede autorização ao usuário
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", str(pythonw), subprocess.list2cmdline(args), str(raiz), 1)
    if int(ret) > 32:
        return ""
    if int(ret) == 5 or ctypes.windll.kernel32.GetLastError() == 1223:
        return "O Windows não autorizou a atualização (a pasta do yPeléTools exige permissão de administrador)."
    return "Não consegui abrir o atualizador (código %d)." % int(ret)


def iniciar_recuperacao(raiz: Path, pid: int) -> str:
    """O app encontrou uma atualização que não terminou: abre o atualizador em modo recuperação (processo separado)."""
    raiz = Path(raiz)
    pythonw = raiz / "runtime" / ("pythonw.exe" if WINDOWS else "bin/python3")
    script = raiz / "app" / "ypele_atualizador.py"
    if not pythonw.exists() or not script.exists():
        return "O atualizador não foi encontrado na pasta do yPeléTools."
    args = ["-I", str(script), "--raiz", str(raiz), "--recuperar", "--pid", str(int(pid)), "--reabrir"]
    try:
        subprocess.Popen([str(pythonw), *args], cwd=str(raiz), close_fds=True, stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=(0x00000008 | 0x00000200) if WINDOWS else 0)
        return ""
    except OSError as e:
        return "Não consegui abrir a recuperação: %s" % e


def reabrir_app(raiz: Path) -> None:
    """Reabre o yPeléTools. Se este atualizador está como administrador, o app NÃO herda isso: ele é aberto pelo
    Explorer (como o usuário normal), pelo atalho do Menu Iniciar."""
    raiz = Path(raiz)
    pythonw = raiz / "runtime" / ("pythonw.exe" if WINDOWS else "bin/python3")
    if WINDOWS and (raiz / "runtime" / "yPeleTools.exe").is_file():
        pythonw = raiz / "runtime" / "yPeleTools.exe"      # Beta 3.6: executável próprio (nome certo no Windows)
    app = raiz / "app" / "ypele_tools.py"
    if WINDOWS and rodando_como_admin():
        try:
            est = json.loads((raiz / "instalacao.json").read_text(encoding="utf-8"))
            for lnk in est.get("atalhos", []):
                if Path(lnk).exists():
                    subprocess.Popen(["explorer.exe", str(lnk)], close_fds=True)
                    return
        except (OSError, ValueError):
            pass
        return                                  # sem atalho: melhor não abrir do que abrir como administrador
    try:
        subprocess.Popen([str(pythonw), "-I", str(app)], cwd=str(app.parent), close_fds=True, stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=(0x00000008 | 0x00000200) if WINDOWS else 0)
    except OSError:
        pass


# ----------------------------------------------------------------------------------------------------------------------
# Registro de falhas do próprio atualizador (crash-logs) e log
# ----------------------------------------------------------------------------------------------------------------------
_SENSIVEL = [
    (re.compile(r"(?i)\b((?:proxy-)?authorization\s*[:=]\s*)[^\r\n]+"), r"\1***"),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=\-]+"), "Bearer ***"),
    (re.compile(r"(https?://)[^/\s:@]+:[^/\s@]+@"), r"\1***:***@"),
    (re.compile(r"(?i)\b(authorization|cookie|set-cookie|token|access_token|refresh_token|client_secret|secret|senha|"
                r"password|passwd|api[_-]?key|apikey|sessionid|sapisid)\b(\s*[=:]\s*)(\"[^\"]*\"|'[^']*'|[^\s,;&]+)"),
     r"\1\2***"),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._\-]+"), "Bearer ***"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"), "gh*_***"),
]


def limpar_sensivel(texto: str) -> str:
    texto = str(texto)
    for rx, sub in _SENSIVEL:
        texto = rx.sub(sub, texto)
    return texto


def pasta_crash_logs(raiz: Path = None) -> Path:
    candidatos = []
    if raiz:
        candidatos.append(Path(raiz) / "crash-logs")
    base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local" if WINDOWS else
                                               Path.home() / ".local" / "share")
    candidatos.append(Path(base) / "yPeléTools" / "crash-logs")
    candidatos.append(Path(tempfile.gettempdir()) / "yPeleTools-crash-logs")
    for c in candidatos:
        if pasta_gravavel(c):
            return c
    return candidatos[-1]


def registrar_falha(raiz: Path, contexto: str) -> Path:
    """crash_AAAA-MM-DD_HH-MM-SS.log na pasta crash-logs (mesmo formato do app). Chamar dentro de um `except`."""
    try:
        pasta = pasta_crash_logs(raiz)
        agora = datetime.datetime.now()
        base = "crash_%s" % agora.strftime("%Y-%m-%d_%H-%M-%S")
        arq, n = pasta / (base + ".log"), 2
        while arq.exists():
            arq, n = pasta / ("%s_%d.log" % (base, n)), n + 1
        tipo, valor, _tb = sys.exc_info()
        try:
            import platform
            sistema = "%s · %s" % (platform.platform(), platform.machine())
        except Exception:
            sistema = sys.platform
        texto = ("yPeléTools — registro de falha do ATUALIZADOR (a instalação anterior é restaurada quando possível)\n"
                 "Data e hora: %s\nVersão instalada: %s\nAtualizador: %s\nPython: %s (%d bits) · %s\nSistema: %s\n"
                 "Thread: %s\nOperação: %s\nExceção: %s: %s\n\nTraceback completo:\n%s"
                 % (agora.astimezone().isoformat(" ", "seconds"), versao_instalada(Path(raiz)) if raiz else "?",
                    Path(__file__).resolve(), sys.version.split()[0], 64 if sys.maxsize > 2 ** 32 else 32,
                    sys.executable, sistema, threading.current_thread().name, contexto,
                    getattr(tipo, "__name__", tipo), valor, traceback.format_exc()))
        arq.write_text(limpar_sensivel(texto), encoding="utf-8")
        return arq
    except Exception:
        return None


class Log:
    def __init__(self, arquivo: Path = None):
        self.arquivo = arquivo
        self.linhas: list = []

    def __call__(self, texto: str) -> None:
        for l in str(texto).splitlines() or [""]:
            linha = "%s  %s" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), limpar_sensivel(l))
            self.linhas.append(linha)
            if self.arquivo:
                try:
                    with open(self.arquivo, "a", encoding="utf-8") as f:
                        f.write(linha + "\n")
                except OSError:
                    pass


# ----------------------------------------------------------------------------------------------------------------------
# Programa: janela simples do atualizador (mesmas cores do app)
# ----------------------------------------------------------------------------------------------------------------------
BG, PANEL, LINE, FG, MUTED, DIM = "#09090B", "#121215", "#28282D", "#EDEDED", "#8E8E95", "#5C5C63"
AMARELO, VERDE, VERMELHO = "#FFD60A", "#3DDC84", "#F26D78"
ETAPAS = [("aguardando", "Esperar o yPeléTools fechar"), ("verificando", "Conferir assinatura e arquivos"),
          ("copiando", "Copiar os arquivos novos"), ("dependencias", "Atualizar as dependências (se mudaram)"),
          ("conferindo", "Conferir a instalação"), ("concluido", "Reabrir o yPeléTools")]


def _executar(args, eventos) -> None:
    """Todo o trabalho (sem interface): manda eventos ("etapa", chave, texto) / ("fim", ok, msg)."""
    raiz = Path(args["raiz"]).resolve()
    log = Log(raiz / "logs" / "atualizacao.log" if pasta_gravavel(raiz / "logs") else None)
    etapa = lambda chave, texto="": eventos(("etapa", chave, texto))
    resultado = {"ok": False, "de": versao_instalada(raiz), "para": "", "mensagem": ""}
    try:
        log("==== atualizador iniciado (pid %d, admin=%s) ====" % (os.getpid(), rodando_como_admin()))
        if mutex_existe(MUTEX_INSTALADOR):
            raise ErroAtualizacao("O instalador do yPeléTools está aberto. Feche-o e tente atualizar de novo.")
        etapa("aguardando", "Esperando o yPeléTools fechar...")
        if not esperar_pid(int(args.get("pid") or 0), 90):
            raise ErroAtualizacao("O yPeléTools não fechou. Feche-o e tente atualizar de novo.")
        fim = time.time() + 60
        while processos_do_runtime(raiz) and time.time() < fim:
            etapa("aguardando", "Outra janela do yPeléTools ainda está aberta: feche-a para continuar...")
            time.sleep(1)
        if processos_do_runtime(raiz):
            raise ErroAtualizacao("Outra janela do yPeléTools continua aberta. Feche-a e tente de novo.")
        etapa("verificando", "Conferindo a assinatura e os arquivos...")
        # tudo lido para a memória ANTES de conferir: o que foi conferido é exatamente o que será instalado
        man_bytes = Path(args["manifesto"]).read_bytes()
        sig = Path(args["assinatura"]).read_bytes()
        man = verificar_manifesto(man_bytes, sig)
        resultado["para"] = man["versao"]
        pacote = escolher_pacote(man, DISTRIBUICAO_INSTALADOR)
        if pacote is None:
            raise ErroAtualizacao("Esta versão não tem pacote para a instalação do Windows.")
        dados = Path(args["pacote"]).read_bytes()
        arquivos = validar_zip(dados, pacote, man["versao"])
        log("Pacote conferido: %s (%d arquivos, SHA-256 %s...)" % (pacote["arquivo"], len(arquivos),
                                                                    pacote["sha256"][:16]))
        inst = Instalacao(raiz, log=log, etapa=etapa)
        falhar = os.environ.get("YPELE_ATUALIZADOR_FALHA_TESTE", "") if modo_teste() else ""
        r = inst.aplicar(man, arquivos, falhar_em=falhar)
        resultado.update(ok=True, de=r["de"], para=r["para"],
                         mensagem="yPeléTools atualizado para %s." % nome_versao(r["para"], man.get("canal", "Alpha")))
        log("Concluído: %s -> %s" % (r["de"], r["para"]))
        for p in (Path(args["pacote"]), Path(args["manifesto"]), Path(args["assinatura"])):
            try:
                p.unlink()
            except OSError:
                pass
    except ErroAtualizacao as e:
        restaurado = getattr(e, "restaurado", True)
        resultado["mensagem"] = str(e) + ("" if not resultado.get("para") else
                                          (" A versão anterior continua instalada." if restaurado else
                                           " A recuperação não terminou: feche os programas que possam estar usando "
                                           "a pasta do yPeléTools e abra o app de novo (ele conclui a recuperação com "
                                           "os backups). Se continuar, reinstale pelo instalador: configurações e "
                                           "downloads são mantidos."))
        resultado["recuperacao_pendente"] = not restaurado
        log("ERRO: %s %s" % (e, e.detalhe))
    except Exception as e:
        caminho = registrar_falha(raiz, "atualizador")
        resultado["mensagem"] = "Erro inesperado no atualizador: %s.%s" % (
            e, (" Detalhes em %s." % caminho) if caminho else "")
        log("ERRO inesperado:\n" + traceback.format_exc())
    gravar_resultado(raiz, resultado)
    eventos(("fim", resultado["ok"], resultado["mensagem"]))


def _recuperar(args, eventos) -> None:
    """--recuperar: conclui a restauração de uma atualização que não terminou (diário + backups)."""
    raiz = Path(args["raiz"]).resolve()
    log = Log(raiz / "logs" / "atualizacao.log" if pasta_gravavel(raiz / "logs") else None)
    etapa = lambda chave, texto="": eventos(("etapa", chave, texto))
    pend = Instalacao.diario_pendente(raiz)
    resultado = {"ok": False, "de": pend.get("para", ""), "para": pend.get("de", ""), "mensagem": "", "recuperacao": True}
    try:
        log("==== recuperação iniciada (pid %d) ====" % os.getpid())
        etapa("aguardando", "Esperando o yPeléTools fechar...")
        if not esperar_pid(int(args.get("pid") or 0), 90):
            raise ErroAtualizacao("O yPeléTools não fechou. Feche-o e tente de novo.")
        etapa("copiando", "Restaurando os arquivos da versão anterior...")
        problemas = Instalacao(raiz, log=log, etapa=etapa).recuperar()
        if problemas:
            raise ErroAtualizacao("Ainda não deu para restaurar: %s. Feche os programas que possam estar usando a "
                                  "pasta do yPeléTools e tente de novo, ou reinstale pelo instalador (configurações e "
                                  "downloads são mantidos)." % "; ".join(problemas[:3]))
        resultado.update(ok=True, mensagem="A atualização que não terminou foi desfeita: o yPeléTools %s voltou, com "
                                             "cada arquivo conferido." % pend.get("de", ""))
    except ErroAtualizacao as e:
        resultado["mensagem"] = str(e)
        resultado["recuperacao_pendente"] = True
        log("ERRO: %s" % e)
    except Exception as e:
        resultado["mensagem"] = "Erro inesperado na recuperação: %s." % e
        resultado["recuperacao_pendente"] = True
        log("ERRO inesperado:\n" + traceback.format_exc())
    gravar_resultado(raiz, resultado)
    eventos(("fim", resultado["ok"], resultado["mensagem"]))


def _ler_args(argv: list) -> dict:
    out = {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("--") and i + 1 < len(argv) and not argv[i + 1].startswith("--"):
            out[a[2:]] = argv[i + 1]
            i += 2
        else:
            out[a.lstrip("-")] = True
            i += 1
    return out


def main(argv: list) -> int:
    args = _ler_args(argv)
    for k in (("raiz",) if args.get("recuperar") else ("raiz", "pacote", "manifesto", "assinatura")):
        if not args.get(k):
            print("uso: ypele_atualizador.py --raiz PASTA --pacote ZIP --manifesto JSON --assinatura SIG --pid N")
            return 2
    raiz = Path(args["raiz"])
    if WINDOWS:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p("YPele.Tools.Atualizador"))
        except Exception:
            pass
    if not segurar_mutex(MUTEX_ATUALIZADOR):
        return 1
    import queue
    eventos = queue.Queue()
    try:
        import tkinter as tk
        janela = tk.Tk()
    except Exception:                                   # sem interface: faz o trabalho assim mesmo
        (_recuperar if args.get("recuperar") else _executar)(args, eventos.put)
        if args.get("reabrir"):
            reabrir_app(raiz)
        return 0
    janela.title("Recuperando o yPeléTools" if args.get("recuperar") else "Atualizando o yPeléTools")
    janela.configure(bg=BG)
    janela.resizable(False, False)
    ico = raiz / "app" / "ypeletools.ico"
    if not ico.exists():
        ico = raiz / "app" / "ypele.ico"
    if ico.exists():
        try:
            janela.iconbitmap(default=str(ico))
        except tk.TclError:
            pass
    esc = max(1.0, janela.winfo_fpixels("1i") / 96.0)
    px = lambda v: int(round(v * esc))
    larg, alt = px(520), px(360)
    janela.geometry("%dx%d+%d+%d" % (larg, alt, (janela.winfo_screenwidth() - larg) // 2,
                                      (janela.winfo_screenheight() - alt) // 3))
    try:
        if WINDOWS:
            janela.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(janela.winfo_id())
            v = ctypes.c_int(1)
            for attr in (20, 19):
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(v), ctypes.sizeof(v))
    except Exception:
        pass
    tk.Frame(janela, bg=AMARELO, height=max(2, px(3))).pack(fill="x")
    corpo = tk.Frame(janela, bg=BG)
    corpo.pack(fill="both", expand=True, padx=px(24), pady=px(18))
    tk.Label(corpo, text="Recuperando o yPeléTools" if args.get("recuperar") else "Atualizando o yPeléTools", bg=BG, fg=FG, font=("Segoe UI Semibold", 15), anchor="w"
             ).pack(fill="x")
    lbl = tk.Label(corpo, text="Preparando...", bg=BG, fg=MUTED, font=("Segoe UI", 10), anchor="w", justify="left",
                   wraplength=larg - px(48))
    lbl.pack(fill="x", pady=(px(4), px(12)))
    barra = tk.Canvas(corpo, height=px(8), bg=BG, highlightthickness=0, bd=0)
    barra.pack(fill="x")
    linhas = {}
    lista = tk.Frame(corpo, bg=BG)
    lista.pack(fill="x", pady=(px(14), 0))
    for chave, texto in ETAPAS:
        l = tk.Label(lista, text="○  " + texto, bg=BG, fg=DIM, font=("Segoe UI", 10), anchor="w")
        l.pack(fill="x", pady=1)
        linhas[chave] = l
    rodape = tk.Frame(corpo, bg=BG)
    rodape.pack(fill="x", side="bottom")
    btn = tk.Button(rodape, text="Fechar", state="disabled", bg=PANEL, fg=FG, activebackground=LINE,
                    activeforeground=FG, relief="flat", font=("Segoe UI", 10), padx=px(16), pady=px(4),
                    command=janela.destroy)
    btn.pack(side="right")
    estado = {"fase": 0.0, "frac": None, "atual": None, "fim": None}

    def desenhar():
        barra.delete("all")
        w = barra.winfo_width() or larg - px(48)
        h = px(8)
        barra.create_rectangle(0, 0, w, h, fill="#1D1D21", outline="")
        if estado["frac"] is None and estado["fim"] is None:
            estado["fase"] = (estado["fase"] + 0.02) % 1.0
            seg = w * 0.3
            x0 = -seg + estado["fase"] * (w + seg)
            barra.create_rectangle(max(0, x0), 0, min(w, x0 + seg), h, fill=AMARELO, outline="")
        else:
            cor = AMARELO if estado["fim"] in (None, True) else VERMELHO
            frac = 1.0 if estado["fim"] is not None else (estado["frac"] or 0)
            barra.create_rectangle(0, 0, w * frac, h, fill=cor, outline="")
        if estado["fim"] is None:
            janela.after(40, desenhar)

    def marcar(chave):
        ordem = [c for c, _ in ETAPAS]
        if chave not in ordem:
            return
        for c, t in ETAPAS:
            if ordem.index(c) < ordem.index(chave):
                linhas[c].config(text="✓  " + t, fg=VERDE)
        linhas[chave].config(text="●  " + dict(ETAPAS)[chave], fg=AMARELO)
        estado["atual"] = chave

    def ler():
        try:
            while True:
                ev = eventos.get_nowait()
                if ev[0] == "etapa":
                    _t, chave, texto = ev
                    if chave == "progresso":
                        i, n = texto
                        estado["frac"] = i / max(1, n)
                        continue
                    if chave == "restaurando":
                        lbl.config(text=texto, fg=VERMELHO)
                        continue
                    estado["frac"] = None
                    marcar(chave)
                    if texto:
                        lbl.config(text=texto, fg=MUTED)
                elif ev[0] == "fim":
                    _t, ok, msg = ev
                    estado["fim"] = ok
                    if ok:
                        marcar("concluido")
                        linhas["concluido"].config(text="✓  " + dict(ETAPAS)["concluido"], fg=VERDE)
                        lbl.config(text=msg + " Abrindo o app...", fg=VERDE)
                        if args.get("reabrir"):
                            reabrir_app(raiz)
                        janela.after(2500, janela.destroy)
                    else:
                        if estado["atual"]:
                            linhas[estado["atual"]].config(fg=VERMELHO)
                        lbl.config(text=msg, fg=VERMELHO)
                        if args.get("reabrir"):
                            reabrir_app(raiz)          # o app reabre na versão que ficou e mostra o motivo
                        btn.config(state="normal")
                    desenhar()
                    return
        except queue.Empty:
            pass
        janela.after(80, ler)

    threading.Thread(target=_recuperar if args.get("recuperar") else _executar, args=(args, eventos.put),
                     daemon=True).start()
    janela.protocol("WM_DELETE_WINDOW", lambda: janela.destroy() if estado["fim"] is not None else None)
    janela.after(60, desenhar)
    janela.after(80, ler)
    janela.mainloop()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except BaseException:
        a = _ler_args(sys.argv[1:])
        registrar_falha(Path(a["raiz"]) if a.get("raiz") else None, "atualizador (principal)")
        sys.exit(3)
