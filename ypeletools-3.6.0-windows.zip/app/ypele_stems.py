#!/usr/bin/env python3
"""
Separação de stems do yPeléTools (aba Vocal Remover), Beta 3.6.

Roda num PROCESSO SEPARADO, aberto pelo app com o Python da instalação:
    python -I ypele_stems.py --tarefa tarefa.json      separa e escreve o progresso em linhas JSON no stdout
    python -I ypele_stems.py --detectar [--dml PASTA]  diz que GPUs existem e se o ONNX Runtime consegue usá-las

Por que um processo separado: a separação usa vários GB de RAM (ou de VRAM) por alguns minutos. Num processo à parte a
interface nunca trava, o cancelamento é imediato (o processo é encerrado) e toda a memória, inclusive a da GPU, é
devolvida ao sistema quando ele termina. O app continua com o ONNX Runtime de CPU que ele já usa; a GPU (DirectML)
fica num pacote à parte, numa pasta do usuário, que só este processo carrega.

Modelos: MDX-Net em ONNX (os mesmos do Ultimate Vocal Remover), executados com numpy + ONNX Runtime, sem PyTorch.
  - Kim_Vocal_2 ............... vocal x instrumental (o modelo de vocal mais preciso dessa família em ONNX)
  - UVR_MDXNET_KARA_2 ......... separa a voz principal das vozes de apoio (aplicado sobre o vocal extraído)
  - kuielab_a_drums / _bass ... bateria e baixo (MDX-Net do desafio MDX 2021)
Guitarra, synth e piano NÃO têm modelo nessa família: ficam dentro de "Outros instrumentos" (ver CATEGORIAS).

O processamento é igual ao do UVR para modelos MDX-Net: STFT (janela de Hann periódica, center=True com reflexão,
hop 1024), as 3 primeiras faixas de frequência zeradas, o modelo prevê o espectro do stem, ISTFT, blocos com
sobreposição e janela de Hann. "Qualidade" usa sobreposição de 50% e a "redução de ruído" do UVR (a média de
modelo(x) e -modelo(-x)); "Rápido" usa blocos sem sobreposição e uma passada só.
"""

import hashlib
import json
import os
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path

URL_MODELOS = "https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/"

# Parâmetros oficiais de cada modelo (model_data.json do UVR, conferidos pelo hash do arquivo) e o SHA-256 do arquivo
# baixado do repositório de modelos do UVR (GitHub Releases).
MODELOS = {
    "Kim_Vocal_2": dict(arquivo="Kim_Vocal_2.onnx", tamanho=66759214,
                        sha256="ce74ef3b6a6024ce44211a07be9cf8bc6d87728cc852a68ab34eb8e58cde9c8b",
                        n_fft=7680, dim_f=3072, dim_t=256, compensa=1.009, primario="vocal"),
    "UVR_MDXNET_KARA_2": dict(arquivo="UVR_MDXNET_KARA_2.onnx", tamanho=52786726,
                              sha256="bf32e15105a09c0f7dddd2b67346146334d6f3ecb399ed7638eba2ab07cbf5f4",
                              n_fft=5120, dim_f=2048, dim_t=256, compensa=1.065, primario="sem_voz_principal"),
    "kuielab_a_drums": dict(arquivo="kuielab_a_drums.onnx", tamanho=29703204,
                            sha256="40f586b7091934dd6f5563f0cba8f14bad57ce88440da1098bf388ea716c2901",
                            n_fft=4096, dim_f=2048, dim_t=512, compensa=1.035, primario="bateria"),
    "kuielab_a_bass": dict(arquivo="kuielab_a_bass.onnx", tamanho=29703204,
                           sha256="0c3e77b9963185b1ea6bb46a4b8924137d9370fc1ccdefec7b1b416ef550dcaa",
                           n_fft=16384, dim_f=2048, dim_t=512, compensa=1.035, primario="baixo"),
}
HOP = 1024
TAXA = 44100

# O que a interface oferece. "modelo": None = não existe modelo que separe isso (fica em "Outros instrumentos").
CATEGORIAS = [
    ("vocal", "Vocal", "Voz principal", ["Kim_Vocal_2"]),
    ("backing", "Backing Vocals", "Vozes de apoio", ["Kim_Vocal_2", "UVR_MDXNET_KARA_2"]),
    ("bateria", "Bateria", "Bateria e percussão", ["kuielab_a_drums"]),
    ("baixo", "Baixo", "Linha de baixo", ["kuielab_a_bass"]),
    ("guitarra", "Guitarra", "Guitarras", None),
    ("synth", "Synth", "Sintetizadores", None),
    ("outros", "Outros instrumentos", "O que sobrar", []),
]
INDISPONIVEL = {
    "guitarra": "Nenhum modelo MDX-Net em ONNX separa guitarra. Ela fica em \"Outros instrumentos\".",
    "synth": "Nenhum modelo MDX-Net em ONNX separa sintetizadores. Eles ficam em \"Outros instrumentos\".",
}
PERFIS = {
    "rapido": dict(sobreposicao=0.0, reduzir_ruido=False),
    "qualidade": dict(sobreposicao=0.5, reduzir_ruido=True),
}


class ErroStems(Exception):
    """Erro com mensagem para o usuário. `tipo`: audio, modelo, gpu, vram, memoria, cancelado, outro."""

    def __init__(self, msg, tipo="outro"):
        super().__init__(msg)
        self.tipo = tipo


# ----------------------------------------------------------------------------------------------------------------------
# Planejamento: o que rodar para a seleção pedida (sem processamento desnecessário)
# ----------------------------------------------------------------------------------------------------------------------
def planejar(selecionadas) -> dict:
    """Recebe as categorias marcadas e devolve {"modelos": [...], "stems": [(chave, nome)], "avisos": [...]}.
    Os stems devolvidos SEMPRE somam a música original: o que sobra vira "Instrumental" (quando só a voz foi tirada),
    "Outros instrumentos" (quando bateria/baixo também foram) ou "Sem <x>"."""
    sel = [c for c in selecionadas if c in {k for k, *_r in CATEGORIAS}]
    avisos = [INDISPONIVEL[c] for c in sel if c in INDISPONIVEL]
    sel = [c for c in sel if c not in INDISPONIVEL]
    voz = "vocal" in sel or "backing" in sel
    inst = [c for c in ("bateria", "baixo") if c in sel]
    modelos, stems = [], []
    if voz:
        modelos.append("Kim_Vocal_2")
        if "backing" in sel:
            modelos.append("UVR_MDXNET_KARA_2")
            stems += [("vocal", "Vocal"), ("backing", "Backing Vocals")]
        else:
            stems.append(("vocal", "Vocal"))
            if "vocal" in sel:
                avisos.append("Sem \"Backing Vocals\" marcado, as vozes de apoio ficam junto com o vocal.")
    for c in inst:
        modelos.append({"bateria": "kuielab_a_drums", "baixo": "kuielab_a_bass"}[c])
        stems.append((c, {"bateria": "Bateria", "baixo": "Baixo"}[c]))
    if voz and not inst:
        stems.append(("instrumental", "Instrumental"))
    elif inst:
        stems.append(("outros", "Outros instrumentos" if voz or len(inst) == 2 else
                      "Outros instrumentos (com vocal)"))
    elif "outros" in sel:
        avisos.append("\"Outros instrumentos\" sozinho é a música inteira: marque também o que deve sair dela.")
    return {"modelos": modelos, "stems": stems, "avisos": avisos}


# ----------------------------------------------------------------------------------------------------------------------
# STFT igual ao torch.stft / torch.istft (center=True, reflexão, Hann periódica), em numpy
# ----------------------------------------------------------------------------------------------------------------------
class STFT:
    def __init__(self, np, n_fft: int, hop: int, dim_f: int):
        self.np, self.n_fft, self.hop, self.dim_f = np, n_fft, hop, dim_f
        n = np.arange(n_fft, dtype=np.float64)
        self.janela = (0.5 - 0.5 * np.cos(2 * np.pi * n / n_fft)).astype(np.float32)

    def frente(self, x):
        """x: [B, 2, N] (N = hop*(dim_t-1)) -> [B, 4, dim_f, dim_t] (L real, L imag, R real, R imag)."""
        np = self.np
        b, c, n = x.shape
        p = self.n_fft // 2
        xp = np.pad(x.reshape(b * c, n), ((0, 0), (p, p)), mode="reflect")
        quadros = 1 + n // self.hop
        idx = np.arange(self.n_fft)[None, :] + self.hop * np.arange(quadros)[:, None]
        fr = xp[:, idx] * self.janela                         # [b*c, T, n_fft]
        esp = np.fft.rfft(fr, axis=-1)[:, :, :self.dim_f]     # [b*c, T, F]
        esp = esp.transpose(0, 2, 1)                          # [b*c, F, T]
        out = np.stack([esp.real, esp.imag], axis=1)          # [b*c, 2, F, T]
        return out.reshape(b, c * 2, self.dim_f, quadros).astype(np.float32)

    def inversa(self, s, n: int):
        """s: [B, 4, dim_f, T] -> [B, 2, n]."""
        np = self.np
        b, _c4, f, t = s.shape
        nb = self.n_fft // 2 + 1
        s = s.reshape(b * 2, 2, f, t)
        comp = np.zeros((b * 2, nb, t), dtype=np.complex64)
        comp[:, :f, :] = s[:, 0] + 1j * s[:, 1]
        fr = np.fft.irfft(comp.transpose(0, 2, 1), n=self.n_fft, axis=-1).astype(np.float32)   # [b*2, T, n_fft]
        fr *= self.janela
        total = self.n_fft + self.hop * (t - 1)
        y = np.zeros((b * 2, total), dtype=np.float32)
        env = np.zeros(total, dtype=np.float32)
        w2 = self.janela ** 2
        for i in range(t):
            a = i * self.hop
            y[:, a:a + self.n_fft] += fr[:, i]
            env[a:a + self.n_fft] += w2
        p = self.n_fft // 2
        y = y[:, p:p + n]
        env = env[p:p + n]
        y /= np.maximum(env, 1e-8)
        return y.reshape(b, 2, n)


# ----------------------------------------------------------------------------------------------------------------------
# ONNX Runtime: CPU ou GPU (DirectML), uma sessão por modelo
# ----------------------------------------------------------------------------------------------------------------------
def importar_ort(pasta_dml: str = ""):
    if pasta_dml and Path(pasta_dml).is_dir() and pasta_dml not in sys.path:
        sys.path.insert(0, pasta_dml)
    import onnxruntime as ort
    try:
        ort.disable_telemetry_events()                 # nada sai do computador (nem a telemetria do ONNX Runtime)
    except Exception:
        pass
    return ort


def criar_sessao(ort, caminho: Path, dispositivo: str, threads: int):
    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.log_severity_level = 3
    if dispositivo == "gpu":
        if "DmlExecutionProvider" not in ort.get_available_providers():
            raise ErroStems("O ONNX Runtime com DirectML não está disponível neste computador.", "gpu")
        so.enable_mem_pattern = False                      # exigências do DirectML
        so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        try:
            s = ort.InferenceSession(str(caminho), so, providers=[("DmlExecutionProvider", {"device_id": 0}),
                                                                   "CPUExecutionProvider"])
        except Exception as e:
            raise ErroStems("A GPU não conseguiu carregar o modelo: %s" % _curto(e), _tipo_erro(e, "gpu"))
        if s.get_providers()[0] != "DmlExecutionProvider":
            raise ErroStems("O ONNX Runtime abriu o modelo só na CPU (a GPU recusou).", "gpu")
        return s
    so.enable_cpu_mem_arena = False                    # devolve a memória entre blocos (menos pico de RAM)
    so.intra_op_num_threads = max(1, int(threads))
    so.inter_op_num_threads = 1
    try:
        return ort.InferenceSession(str(caminho), so, providers=["CPUExecutionProvider"])
    except Exception as e:
        raise ErroStems("Não consegui carregar o modelo %s: %s. Apague o arquivo para baixá-lo de novo."
                        % (caminho.name, _curto(e)), "modelo")


def _curto(e, n=220) -> str:
    t = str(e).strip().replace("\n", " ")
    return t if len(t) <= n else t[:n] + "…"


def _tipo_erro(e, padrao="outro") -> str:
    t = str(e).lower()
    if isinstance(e, MemoryError):
        return "memoria"
    if any(k in t for k in ("out of memory", "outofmemory", "e_outofmemory", "8007000e", "887a0005",
                            "device removed", "not enough memory", "failed to allocate", "bad_alloc")):
        return "vram" if padrao == "gpu" else "memoria"
    return padrao


# ----------------------------------------------------------------------------------------------------------------------
# Um modelo MDX-Net aplicado a uma música inteira, em blocos
# ----------------------------------------------------------------------------------------------------------------------
class MDX:
    def __init__(self, np, sessao, p: dict):
        self.np, self.s, self.p = np, sessao, p
        self.nome_in = sessao.get_inputs()[0].name
        self.stft = STFT(np, p["n_fft"], HOP, p["dim_f"])
        self.bloco = HOP * (p["dim_t"] - 1)
        self.trim = p["n_fft"] // 2

    def _rodar(self, partes, reduzir_ruido: bool):
        np = self.np
        esp = self.stft.frente(partes)
        esp[:, :, :3, :] = 0
        saida = self.s.run(None, {self.nome_in: esp})[0]
        if reduzir_ruido:
            saida = 0.5 * saida - 0.5 * self.s.run(None, {self.nome_in: -esp})[0]
        return self.stft.inversa(np.asarray(saida, dtype=np.float32), partes.shape[-1])

    def separar(self, mix, sobreposicao: float, reduzir_ruido: bool, progresso=None, cancelado=None):
        """mix: [2, N] float32 -> o stem primário do modelo [2, N] (já com o ganho de compensação)."""
        np = self.np
        n = mix.shape[1]
        passo = max(1024, int(self.bloco * (1.0 - sobreposicao)))
        ini = self.trim
        total = ini + n + self.bloco + self.trim
        mx = np.zeros((2, total), dtype=np.float32)
        mx[:, ini:ini + n] = mix
        res = np.zeros((2, total), dtype=np.float32)
        div = np.zeros(total, dtype=np.float32)
        if sobreposicao > 0:
            jan = np.hanning(self.bloco + 2)[1:-1].astype(np.float32)
        else:
            jan = np.ones(self.bloco, dtype=np.float32)
        # só o miolo de cada bloco vale (as pontas do STFT de cada bloco têm efeito de borda)
        miolo = np.zeros(self.bloco, dtype=np.float32)
        miolo[self.trim:self.bloco - self.trim] = 1.0
        peso = jan * miolo if sobreposicao <= 0 else jan * np.maximum(miolo, 1e-3)
        if sobreposicao <= 0:
            passo = self.bloco - 2 * self.trim
        inicios = list(range(0, ini + n, passo))
        for k, a in enumerate(inicios):
            if cancelado is not None and cancelado():
                raise ErroStems("Cancelado.", "cancelado")
            parte = mx[None, :, a:a + self.bloco]
            if parte.shape[-1] < self.bloco:
                parte = np.pad(parte, ((0, 0), (0, 0), (0, self.bloco - parte.shape[-1])))
            y = self._rodar(parte, reduzir_ruido)[0]
            fim = min(a + self.bloco, total)
            res[:, a:fim] += (y * peso)[:, :fim - a]
            div[a:fim] += peso[:fim - a]
            if progresso is not None:
                progresso((k + 1) / len(inicios))
        out = res[:, ini:ini + n] / np.maximum(div[ini:ini + n], 1e-8)
        return out * np.float32(self.p["compensa"])


# ----------------------------------------------------------------------------------------------------------------------
# Áudio: leitura pelo FFmpeg (qualquer formato) e WAV float de 32 bits
# ----------------------------------------------------------------------------------------------------------------------
def ler_audio(np, ffmpeg: str, arquivo: str, cancelado=None):
    """Decodifica para float32 estéreo 44,1 kHz [2, N] sem mexer no original (o FFmpeg só lê)."""
    cmd = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-i", arquivo, "-vn", "-ac", "2",
           "-ar", str(TAXA), "-f", "f32le", "-acodec", "pcm_f32le", "-"]
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **_sem_janela())
    except OSError as e:
        raise ErroStems("Não consegui abrir o FFmpeg: %s" % e, "audio")
    partes = []
    err = []
    t = threading.Thread(target=lambda: err.append(p.stderr.read()), daemon=True)
    t.start()
    while True:
        b = p.stdout.read(1 << 22)
        if not b:
            break
        partes.append(b)
        if cancelado is not None and cancelado():
            p.kill()
            raise ErroStems("Cancelado.", "cancelado")
    p.wait()
    t.join(5)
    bruto = b"".join(partes)
    if p.returncode != 0 or len(bruto) < 8 * TAXA // 10:
        msg = (err[0] if err else b"").decode("utf-8", "replace").strip().splitlines()
        raise ErroStems("O arquivo não pôde ser lido como áudio%s." % (": " + msg[-1][:160] if msg else ""), "audio")
    a = np.frombuffer(bruto[:len(bruto) // 8 * 8], dtype=np.float32).reshape(-1, 2).T
    return np.ascontiguousarray(a)


def gravar_wav_float(np, caminho: Path, audio) -> None:
    """WAV IEEE float 32 bits estéreo (sem perda e sem corte em picos acima de 0 dBFS)."""
    dados = np.ascontiguousarray(audio.T.astype(np.float32)).tobytes()
    cab = b"RIFF" + struct.pack("<I", 4 + 26 + 12 + 8 + len(dados)) + b"WAVE"
    cab += b"fmt " + struct.pack("<IHHIIHHH", 18, 3, 2, TAXA, TAXA * 8, 8, 32, 0)
    cab += b"fact" + struct.pack("<II", 4, audio.shape[1])
    cab += b"data" + struct.pack("<I", len(dados))
    tmp = Path(str(caminho) + ".tmp")
    with open(tmp, "wb") as f:
        f.write(cab)
        f.write(dados)
    os.replace(tmp, caminho)


def abrir_wav_float(np, caminho: Path):
    """[N, 2] float32 mapeado do disco (np.memmap): a interface lê só os trechos que toca ou desenha."""
    with open(caminho, "rb") as f:
        cab = f.read(4096)
    if cab[:4] != b"RIFF" or cab[8:12] != b"WAVE":
        raise ErroStems("Arquivo de stem inválido: %s" % caminho, "audio")
    i = 12
    fmt = None
    while i + 8 <= len(cab):
        cid, tam = cab[i:i + 4], struct.unpack("<I", cab[i + 4:i + 8])[0]
        if cid == b"fmt ":
            fmt = struct.unpack("<HHIIHH", cab[i + 8:i + 24])
        if cid == b"data":
            if not fmt or fmt[0] != 3 or fmt[1] != 2 or fmt[5] != 32:
                raise ErroStems("Formato de stem inesperado: %s" % caminho, "audio")
            n = tam // 8
            return np.memmap(caminho, dtype=np.float32, mode="r", offset=i + 8, shape=(n, 2))
        i += 8 + tam + (tam & 1)
    raise ErroStems("Arquivo de stem sem dados: %s" % caminho, "audio")


# ----------------------------------------------------------------------------------------------------------------------
# Modelos: download (com progresso, retomada e SHA-256) e conferência
# ----------------------------------------------------------------------------------------------------------------------
def sha256_arquivo(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def modelo_pronto(pasta: Path, nome: str) -> bool:
    """Arquivo presente, do tamanho certo e já conferido (o .ok guarda o SHA-256 conferido)."""
    m = MODELOS[nome]
    arq, ok = Path(pasta) / m["arquivo"], Path(pasta) / (m["arquivo"] + ".ok")
    try:
        return arq.stat().st_size == m["tamanho"] and ok.read_text().strip() == m["sha256"]
    except OSError:
        return False


def baixar_modelo(pasta: Path, nome: str, progresso=None, cancelado=None, url_base: str = "") -> Path:
    import urllib.request
    m = MODELOS[nome]
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    arq = pasta / m["arquivo"]
    if modelo_pronto(pasta, nome):
        return arq
    if arq.exists() and arq.stat().st_size == m["tamanho"] and sha256_arquivo(arq) == m["sha256"]:
        (pasta / (m["arquivo"] + ".ok")).write_text(m["sha256"])
        return arq
    parcial = pasta / (m["arquivo"] + ".parcial")
    url = (url_base or os.environ.get("YPELE_STEMS_URL") or URL_MODELOS).rstrip("/") + "/" + m["arquivo"]
    tentativas = 0
    while True:
        inicio = parcial.stat().st_size if parcial.exists() else 0
        if inicio > m["tamanho"]:
            parcial.unlink()
            inicio = 0
        req = urllib.request.Request(url, headers={"User-Agent": "yPeleTools"})
        if inicio:
            req.add_header("Range", "bytes=%d-" % inicio)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                if inicio and r.status != 206:
                    inicio = 0
                with open(parcial, "ab" if inicio else "wb") as f:
                    feito = inicio
                    while True:
                        if cancelado is not None and cancelado():
                            raise ErroStems("Cancelado.", "cancelado")
                        b = r.read(1 << 18)
                        if not b:
                            break
                        f.write(b)
                        feito += len(b)
                        if progresso is not None:
                            progresso(feito, m["tamanho"])
            if parcial.stat().st_size >= m["tamanho"]:
                break
            raise OSError("download interrompido")
        except ErroStems:
            raise
        except Exception as e:
            tentativas += 1
            if tentativas >= 4:
                raise ErroStems("Não consegui baixar o modelo %s (%s). O que já foi baixado fica guardado e o "
                                "download continua de onde parou na próxima vez." % (nome, _curto(e, 120)), "modelo")
            time.sleep(2 * tentativas)
    if parcial.stat().st_size != m["tamanho"] or sha256_arquivo(parcial) != m["sha256"]:
        parcial.unlink()
        raise ErroStems("O modelo %s veio corrompido (SHA-256 diferente) e foi apagado. Tente de novo." % nome,
                        "modelo")
    os.replace(parcial, arq)
    (pasta / (m["arquivo"] + ".ok")).write_text(m["sha256"])
    return arq


# ----------------------------------------------------------------------------------------------------------------------
# Detecção de GPU (Windows: DXGI) e do ONNX Runtime com DirectML
# ----------------------------------------------------------------------------------------------------------------------
def gpus_windows() -> list:
    """[{nome, vram_mb, fabricante}] das placas de vídeo de verdade (DXGI), sem o adaptador de software."""
    if sys.platform != "win32":
        return []
    import ctypes

    class GUID(ctypes.Structure):
        _fields_ = [("a", ctypes.c_ulong), ("b", ctypes.c_ushort), ("c", ctypes.c_ushort), ("d", ctypes.c_ubyte * 8)]

    class DESC1(ctypes.Structure):
        _fields_ = [("Description", ctypes.c_wchar * 128), ("VendorId", ctypes.c_uint), ("DeviceId", ctypes.c_uint),
                    ("SubSysId", ctypes.c_uint), ("Revision", ctypes.c_uint),
                    ("DedicatedVideoMemory", ctypes.c_size_t), ("DedicatedSystemMemory", ctypes.c_size_t),
                    ("SharedSystemMemory", ctypes.c_size_t), ("Luid", ctypes.c_longlong), ("Flags", ctypes.c_uint)]
    iid = GUID(0x770aae78, 0xf26f, 0x4dba, (ctypes.c_ubyte * 8)(0xa8, 0x29, 0x25, 0x3c, 0x83, 0xd1, 0xb3, 0x87))
    fab = ctypes.c_void_p()
    try:
        dxgi = ctypes.WinDLL("dxgi")
        if dxgi.CreateDXGIFactory1(ctypes.byref(iid), ctypes.byref(fab)) != 0 or not fab:
            return []
    except OSError:
        return []

    def metodo(obj, indice, *tipos):
        vt = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *tipos)(vt[indice])
    lista = []
    i = 0
    while i < 16:
        ad = ctypes.c_void_p()
        # IDXGIFactory1::EnumAdapters1 = índice 12 da vtable
        if metodo(fab, 12, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p))(fab, i, ctypes.byref(ad)) != 0:
            break
        d = DESC1()
        # IDXGIAdapter1::GetDesc1 = índice 10
        if metodo(ad, 10, ctypes.POINTER(DESC1))(ad, ctypes.byref(d)) == 0 and not (d.Flags & 2):
            fabricante = {0x10DE: "NVIDIA", 0x1002: "AMD", 0x8086: "Intel"}.get(d.VendorId, "")
            lista.append({"nome": d.Description, "vram_mb": int(d.DedicatedVideoMemory // (1024 * 1024)),
                          "fabricante": fabricante})
        metodo(ad, 2)(ad)                                  # Release
        i += 1
    metodo(fab, 2)(fab)
    return lista


def detectar(pasta_dml: str = "") -> dict:
    r = {"gpus": [], "dml_instalado": False, "dml_ok": False, "provedores": [], "motivo": "", "ort": ""}
    try:
        r["gpus"] = gpus_windows()
    except Exception as e:                               # detecção nunca derruba nada
        r["motivo"] = "Não consegui listar as placas de vídeo: %s" % _curto(e, 120)
    r["dml_instalado"] = bool(pasta_dml) and (Path(pasta_dml) / "onnxruntime").is_dir()
    try:
        ort = importar_ort(pasta_dml if r["dml_instalado"] else "")
        r["ort"] = ort.__version__
        r["provedores"] = list(ort.get_available_providers())
    except Exception as e:
        r["motivo"] = "O ONNX Runtime não abriu: %s" % _curto(e, 160)
        return r
    if sys.platform != "win32":
        r["motivo"] = r["motivo"] or "A GPU (DirectML) só existe no Windows."
    elif not r["gpus"]:
        r["motivo"] = r["motivo"] or "Nenhuma placa de vídeo compatível com DirectX 12 foi encontrada."
    elif "DmlExecutionProvider" not in r["provedores"]:
        r["motivo"] = ("O pacote de GPU (ONNX Runtime DirectML) ainda não está instalado." if not r["dml_instalado"]
                       else "O ONNX Runtime DirectML foi instalado, mas não oferece a GPU.")
    else:
        r["dml_ok"] = True
    return r


# ----------------------------------------------------------------------------------------------------------------------
# A tarefa completa (processo separado): ler, separar, gravar, avisar o progresso
# ----------------------------------------------------------------------------------------------------------------------
def _sem_janela() -> dict:
    if sys.platform == "win32":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return {"startupinfo": si, "creationflags": 0x08000000}
    return {}


class Saida:
    """Linhas JSON no stdout (o app lê uma por vez)."""

    def __init__(self, fluxo=None):
        self.f = fluxo or sys.stdout
        self.trava = threading.Lock()

    def __call__(self, **kw):
        with self.trava:
            self.f.write(json.dumps(kw) + "\n")
            self.f.flush()


def executar(t: dict, avisar, cancelado=lambda: False) -> dict:
    """t: {arquivo, ffmpeg, pasta_saida, pasta_modelos, selecionadas, perfil, dispositivo, threads, pasta_dml}.
    Grava cada stem em pasta_saida como WAV float e devolve {"stems": [{chave, nome, arquivo}], ...}."""
    import numpy as np
    plano = planejar(t["selecionadas"])
    if not plano["modelos"]:
        raise ErroStems("Nada para separar: marque pelo menos Vocal, Backing Vocals, Bateria ou Baixo.", "outro")
    perfil = PERFIS.get(t.get("perfil"), PERFIS["qualidade"])
    disp = t.get("dispositivo", "cpu")
    saida = Path(t["pasta_saida"])
    saida.mkdir(parents=True, exist_ok=True)
    for a in plano["avisos"]:
        avisar(t="aviso", msg=a)

    # pesos das etapas para o progresso total (download conta pouco; a separação é o grosso)
    custo = {"Kim_Vocal_2": 3.0, "UVR_MDXNET_KARA_2": 2.0, "kuielab_a_drums": 1.6, "kuielab_a_bass": 1.6}
    total_custo = 0.4 + sum(custo[m] for m in plano["modelos"]) + 0.4
    feito = [0.0]
    t0 = time.monotonic()
    estado = {"ultimo": 0.0}

    def prog(parcial: float, peso: float, etapa: str):
        f = min(1.0, (feito[0] + parcial * peso) / total_custo)
        agora = time.monotonic()
        if agora - estado["ultimo"] < 0.25 and parcial < 1:
            return
        estado["ultimo"] = agora
        dec = agora - t0
        eta = (dec / f - dec) if f > 0.05 else None
        avisar(t="progresso", f=round(f, 4), etapa=etapa, eta=None if eta is None else round(eta))

    # 1. modelos
    faltam = [m for m in plano["modelos"] if not modelo_pronto(Path(t["pasta_modelos"]), m)]
    for i, m in enumerate(faltam):
        arq = Path(t["pasta_modelos"]) / MODELOS[m]["arquivo"]
        if arq.is_file() and arq.stat().st_size == MODELOS[m]["tamanho"]:
            etapa = "Conferindo o modelo %s" % m             # já baixado: só confere o SHA-256 (uma vez)
        else:
            etapa = "Baixando o modelo %s (%d MB, uma vez só)" % (m, MODELOS[m]["tamanho"] // 1048576)
        avisar(t="etapa", msg=etapa + "...")
        baixar_modelo(Path(t["pasta_modelos"]), m, cancelado=cancelado,
                      progresso=lambda a, b, i=i, etapa=etapa: prog((i + a / max(1, b)) / len(faltam), 0.4,
                                                                    "%s: %d de %d MB" % (etapa, a // 1048576,
                                                                                          b // 1048576)))
    feito[0] += 0.4
    ort = importar_ort(t.get("pasta_dml", "") if disp == "gpu" else "")

    # 2. áudio
    avisar(t="etapa", msg="Lendo o áudio...")
    mix = ler_audio(np, t["ffmpeg"], t["arquivo"], cancelado)
    dur = mix.shape[1] / TAXA
    avisar(t="audio", duracao=round(dur, 2))
    sob, rr = perfil["sobreposicao"], perfil["reduzir_ruido"]

    def rodar(nome_modelo, entrada, etapa):
        avisar(t="etapa", msg=etapa)
        sess = criar_sessao(ort, Path(t["pasta_modelos"]) / MODELOS[nome_modelo]["arquivo"], disp,
                            int(t.get("threads") or 2))
        if disp == "gpu":
            avisar(t="dispositivo", usado=sess.get_providers()[0])
        try:
            mdx = MDX(np, sess, MODELOS[nome_modelo])
            y = mdx.separar(entrada, sob, rr, lambda f: prog(f, custo[nome_modelo], etapa), cancelado)
        except ErroStems:
            raise
        except MemoryError:
            raise ErroStems("Faltou memória RAM para separar esta música.", "memoria")
        except Exception as e:
            tipo = _tipo_erro(e, "gpu" if disp == "gpu" else "outro")
            if tipo == "vram":
                raise ErroStems("A GPU ficou sem memória de vídeo (VRAM) durante a separação.", "vram")
            raise ErroStems("Falha ao rodar o modelo %s: %s" % (nome_modelo, _curto(e)), tipo)
        finally:
            del sess
        feito[0] += custo[nome_modelo]
        return y

    plano_m = plano["modelos"]
    nomes = dict(plano["stems"])
    stems = []

    def gravar(chave, audio):
        """Grava um stem assim que ele fica pronto (e a memória dele pode ser liberada)."""
        if chave not in nomes:
            return
        arq = saida / ("%s.wav" % chave)
        gravar_wav_float(np, arq, audio)
        stems.append({"chave": chave, "nome": nomes[chave], "arquivo": str(arq)})
        avisar(t="stem", chave=chave, nome=nomes[chave], arquivo=str(arq))

    gravar_wav_float(np, saida / "original.wav", mix)   # a música original decodificada (ouvir e comparar)
    base = mix
    if "Kim_Vocal_2" in plano_m:
        voz = rodar("Kim_Vocal_2", mix, "Separando a voz...")
        base = mix - voz
        if "UVR_MDXNET_KARA_2" in plano_m:
            apoio = rodar("UVR_MDXNET_KARA_2", voz, "Separando a voz principal das vozes de apoio...")
            gravar("vocal", voz - apoio)
            gravar("backing", apoio)
            del apoio
        else:
            gravar("vocal", voz)
        del voz
        gravar("instrumental", base)
    del mix
    resto = base
    if "kuielab_a_drums" in plano_m:
        y = rodar("kuielab_a_drums", base, "Separando a bateria...")
        gravar("bateria", y)
        resto = resto - y
        del y
    if "kuielab_a_bass" in plano_m:
        y = rodar("kuielab_a_bass", base, "Separando o baixo...")
        gravar("baixo", y)
        resto = resto - y
        del y
    gravar("outros", resto)
    ordem = [k for k, _n in plano["stems"]]
    stems.sort(key=lambda s: ordem.index(s["chave"]))
    feito[0] = total_custo
    prog(1.0, 0, "Pronto")
    return {"stems": stems, "duracao": dur, "segundos": round(time.monotonic() - t0, 1),
            "avisos": plano["avisos"], "original": str(saida / "original.wav")}


def main(argv) -> int:
    saida = Saida()
    if "--detectar" in argv:
        dml = argv[argv.index("--dml") + 1] if "--dml" in argv else ""
        saida(t="deteccao", **detectar(dml))
        return 0
    if "--tarefa" not in argv:
        print("uso: ypele_stems.py --tarefa tarefa.json | --detectar [--dml PASTA]")
        return 2
    t = json.loads(Path(argv[argv.index("--tarefa") + 1]).read_text(encoding="utf-8"))
    if sys.platform == "win32":                        # prioridade abaixo do normal: a interface continua fluida
        try:
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
        except Exception:
            pass
    try:
        r = executar(t, saida)
        saida(t="fim", **r)
        return 0
    except ErroStems as e:
        saida(t="erro", tipo=e.tipo, msg=str(e))
        return 3
    except MemoryError:
        saida(t="erro", tipo="memoria", msg="Faltou memória RAM para separar esta música.")
        return 3
    except Exception as e:
        import traceback
        saida(t="erro", tipo="outro", msg="Erro inesperado na separação: %s" % _curto(e),
              detalhe=traceback.format_exc()[-3000:])
        return 4


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
