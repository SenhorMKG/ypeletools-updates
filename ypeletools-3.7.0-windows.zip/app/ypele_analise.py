#!/usr/bin/env python3
"""
Áudio Tools (Beta 3.7): BPM Analyzer e Key Detector do yPeléTools, SEM interface.

Tudo aqui é cálculo de verdade sobre o áudio (ou um dado de catálogo de verdade): nada é estimado pelo título, pela
capa ou por valores fixos. Usa só o NumPy (que o app já tem) e o FFmpeg do app para decodificar qualquer formato.

  BPM (andamento) ...... envelope de ataques (fluxo espectral em 40 bandas log), autocorrelação com harmônicos
                         (tempograma) e uma preferência suave em torno de 120 BPM para escolher a oitava; depois o
                         rastreamento das batidas por programação dinâmica (Ellis, 2007) e uma regressão linear dos
                         tempos das batidas dá o valor com uma casa decimal. A confiança combina a força do pico e a
                         regularidade das batidas. Quando o dobro/a metade também é plausível, o resultado diz.
  Tonalidade ........... afinação estimada pelos picos do espectro (a música pode estar alguns cents fora do Lá 440),
                         perfil de classes de altura (cromagrama) dos picos entre 55 Hz e 2 kHz, com o baixo pesando mais,
                         correlação com os perfis de Krumhansl-Kessler e de Temperley (24 tonalidades). A confiança vem
                         da distância entre a melhor e a segunda melhor tonalidade.
  Catálogo (link) ...... BPM publicado pelo catálogo público do Deezer (api.deezer.com, sem login), só quando título,
                         artista e duração conferem. Marcado como "dado de catálogo", nunca como cálculo.

Limitações honestas: músicas com mudança de andamento, sem percussão, com métrica irregular ou com modulação de
tonalidade dão resultados menos confiáveis (a confiança cai e o app avisa); a escolha entre o dobro e a metade do
andamento (ex.: 87 x 174 BPM) depende do estilo; tonalidades relativas (Dó maior x Lá menor) às vezes se confundem.
"""

import json
import re
import subprocess
import sys
import unicodedata
import urllib.parse
import urllib.request

TAXA = 22050
ANALISE_MAX_SEG = 8 * 60                 # o andamento e a tonalidade não precisam de mais que isso

NOTAS = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]
NOTAS_PT = ["Dó", "Dó#", "Ré", "Mi♭", "Mi", "Fá", "Fá#", "Sol", "Lá♭", "Lá", "Si♭", "Si"]
# Roda de Camelot: tônica (classe de altura) -> código. Maior = B, menor = A.
CAMELOT_MAIOR = {0: "8B", 7: "9B", 2: "10B", 9: "11B", 4: "12B", 11: "1B", 6: "2B", 1: "3B", 8: "4B", 3: "5B",
                 10: "6B", 5: "7B"}
CAMELOT_MENOR = {9: "8A", 4: "9A", 11: "10A", 6: "11A", 1: "12A", 8: "1A", 3: "2A", 10: "3A", 5: "4A", 0: "5A",
                 7: "6A", 2: "7A"}
PERFIS = {
    "kk": ([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88],
           [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]),
    "temperley": ([5.0, 2.0, 3.5, 2.0, 4.5, 4.0, 2.0, 4.5, 2.0, 3.5, 1.5, 4.0],
                  [5.0, 2.0, 3.5, 4.5, 2.0, 4.0, 2.0, 4.5, 3.5, 2.0, 1.5, 4.0]),
}


class ErroAnalise(Exception):
    pass


def _np():
    import numpy as np
    return np


def nome_tom(tonica: int, modo: str) -> dict:
    """{'nome': 'F menor', 'nome_en': 'F Minor', 'nome_pt': 'Fá menor', 'camelot': '4A', 'nota': 'F', 'modo': 'menor'}"""
    maior = modo == "maior"
    return {"nota": NOTAS[tonica], "modo": modo, "tonica": tonica,
            "nome": "%s %s" % (NOTAS[tonica], "maior" if maior else "menor"),
            "nome_en": "%s %s" % (NOTAS[tonica], "Major" if maior else "Minor"),
            "nome_pt": "%s %s" % (NOTAS_PT[tonica], "maior" if maior else "menor"),
            "camelot": (CAMELOT_MAIOR if maior else CAMELOT_MENOR)[tonica]}


# ======================================================================================================================
# Decodificação (FFmpeg)
# ======================================================================================================================
def decodificar(ffmpeg: str, caminho: str, taxa: int = TAXA, max_seg: float = ANALISE_MAX_SEG, inicio: float = 0.0,
                cancelado=None):
    """Áudio mono float32 na `taxa`. Lê do FFmpeg por pipe (o arquivo original nunca é alterado)."""
    np = _np()
    cmd = [ffmpeg, "-nostdin", "-v", "error"]
    if inicio:
        cmd += ["-ss", "%.3f" % inicio]
    cmd += ["-i", str(caminho), "-vn", "-t", "%.1f" % max_seg, "-ac", "1", "-ar", str(taxa), "-f", "f32le", "-"]
    kw = {}
    if sys.platform == "win32":
        kw["creationflags"] = 0x08000000
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw)
    except OSError as e:
        raise ErroAnalise("Não consegui abrir o FFmpeg para ler o áudio (%s)." % e)
    partes = []
    try:
        while True:
            if cancelado and cancelado():
                raise ErroAnalise("cancelado")
            b = p.stdout.read(1 << 20)
            if not b:
                break
            partes.append(b)
        erro = p.stderr.read().decode("utf-8", "replace")
        p.wait(30)
    finally:
        if p.poll() is None:
            p.kill()
            p.wait(10)
        for fluxo in (p.stdout, p.stderr):
            try:
                fluxo.close()
            except OSError:
                pass
    dados = b"".join(partes)
    if p.returncode != 0 and not dados:
        raise ErroAnalise("O FFmpeg não conseguiu ler este arquivo: %s" % (erro.strip().splitlines() or ["?"])[-1][:200])
    x = np.frombuffer(dados[:len(dados) // 4 * 4], dtype="<f4").astype(np.float32)
    if x.size < taxa * 3:
        raise ErroAnalise("O áudio é curto demais para analisar (mínimo 3 segundos).")
    if float(np.max(np.abs(x))) < 1e-4:
        raise ErroAnalise("O áudio está em silêncio.")
    return x


def _quadros(x, n_fft: int, hop: int, inicio: int, n: int):
    np = _np()
    idx = inicio * hop + np.arange(n)[:, None] * hop + np.arange(n_fft)[None, :]
    return x[idx]


def _espectro(x, n_fft: int, hop: int, pedaco: int = 1024):
    """|STFT| por pedaços (a memória não cresce com a duração). Gera (índice do 1º quadro, magnitudes)."""
    np = _np()
    pad = np.concatenate([np.zeros(n_fft // 2, np.float32), x, np.zeros(n_fft // 2, np.float32)])
    total = 1 + (len(pad) - n_fft) // hop
    jan = np.hanning(n_fft).astype(np.float32)
    for ini in range(0, total, pedaco):
        n = min(pedaco, total - ini)
        q = _quadros(pad, n_fft, hop, ini, n) * jan
        yield ini, np.abs(np.fft.rfft(q, axis=1)).astype(np.float32)


# ======================================================================================================================
# BPM
# ======================================================================================================================
def envelope_ataques(x, sr: int = TAXA, hop: int = 256, n_fft: int = 1024):
    """Força dos ataques por quadro (fluxo espectral positivo em 40 bandas log, sem a tendência lenta)."""
    np = _np()
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    bordas = np.geomspace(40.0, min(10000.0, sr / 2 - 1), 41)
    banda = np.digitize(freqs, bordas) - 1
    validos = (banda >= 0) & (banda < 40)
    M = np.zeros((len(freqs), 40), np.float32)
    M[np.nonzero(validos)[0], banda[validos]] = 1.0
    blocos = []
    for _ini, mag in _espectro(x, n_fft, hop):
        blocos.append(np.log1p(1000.0 * (mag @ M)))
    S = np.concatenate(blocos, axis=0)
    flux = np.maximum(0.0, np.diff(S, axis=0)).sum(axis=1)
    flux = np.concatenate([[0.0], flux])
    k = max(3, int(round(0.5 * sr / hop)))
    media = np.convolve(flux, np.ones(k) / k, mode="same")
    env = np.maximum(0.0, flux - media)
    dp = float(np.std(env)) or 1.0
    return (env / dp).astype(np.float64), sr / hop


def _autocorrelacao(env):
    np = _np()
    n = len(env)
    e = env - env.mean()
    f = np.fft.rfft(e, 2 * n)
    ac = np.fft.irfft(f * np.conj(f))[:n]
    return ac / (ac[0] or 1.0)


def _interp(v, pos: float) -> float:
    i = int(pos)
    if i + 1 >= len(v) or i < 0:
        return 0.0
    a = pos - i
    return float(v[i] * (1 - a) + v[i + 1] * a)


def _rastrear_batidas(env, fps: float, bpm: float, apertura: float = 100.0):
    """Programação dinâmica de Ellis (2007): as batidas que maximizam a força dos ataques com intervalos próximos do
    período. Devolve os índices dos quadros das batidas."""
    np = _np()
    periodo = 60.0 * fps / bpm
    larg = max(1, int(round(periodo / 16)))
    g = np.exp(-0.5 * (np.arange(-2 * larg, 2 * larg + 1) / larg) ** 2)
    local = np.convolve(env, g, mode="same")
    n = len(local)
    acumulado = np.zeros(n)
    anterior = -np.ones(n, dtype=int)
    janela = np.arange(-int(round(2 * periodo)), -int(round(periodo / 2)) + 1)
    custo = -apertura * (np.log(-janela / periodo)) ** 2
    for t in range(n):
        idx = t + janela
        ok = idx >= 0
        if np.any(ok):
            cand = acumulado[idx[ok]] + custo[ok]
            j = int(np.argmax(cand))
            if cand[j] > 0:
                acumulado[t] = local[t] + cand[j]
                anterior[t] = idx[ok][j]
                continue
        acumulado[t] = local[t]
    # a última batida: o melhor acumulado perto do fim
    fim = n - 1 - int(np.argmax(acumulado[::-1][:int(periodo * 2)])) if n > periodo * 2 else int(np.argmax(acumulado))
    batidas = [fim]
    while anterior[batidas[-1]] >= 0:
        batidas.append(int(anterior[batidas[-1]]))
    return np.array(batidas[::-1])


def estimar_bpm(x, sr: int = TAXA, minimo: float = 50.0, maximo: float = 220.0) -> dict:
    """{'bpm': 128.0, 'bpm_inteiro': 128, 'confianca': 0..1, 'alternativa': 64.0 ou None, 'batidas': n}"""
    np = _np()
    env, fps = envelope_ataques(x, sr)
    if len(env) < fps * 4 or float(env.max()) <= 0:
        raise ErroAnalise("Não há ataques suficientes no áudio para medir o andamento.")
    ac = _autocorrelacao(env)
    grade = np.arange(minimo, maximo + 0.01, 0.25)
    pont = np.zeros(len(grade))
    for k, b in enumerate(grade):
        lag = 60.0 * fps / b
        pont[k] = sum(_interp(ac, lag * h) / h for h in (1, 2, 3, 4)) + 0.5 * _interp(ac, lag / 2)
    prior = np.exp(-0.5 * (np.log2(grade / 120.0) / 1.0) ** 2)
    final = np.maximum(pont, 0) * prior
    i = int(np.argmax(final))
    bpm0 = float(grade[i])
    # alternativa: o dobro ou a metade com pontuação parecida
    alternativa = None
    for fator in (2.0, 0.5):
        alvo = bpm0 * fator
        if minimo <= alvo <= maximo:
            j = int(np.argmin(np.abs(grade - alvo)))
            if final[j] >= 0.8 * final[i]:
                alternativa = round(alvo, 1)
    batidas = _rastrear_batidas(env, fps, bpm0)
    bpm = bpm0
    regular = 0.0
    if len(batidas) >= 8:
        t = batidas / fps
        ids = np.arange(len(t))
        inclinacao = np.polyfit(ids, t, 1)[0]
        if inclinacao > 0:
            refinado = 60.0 / inclinacao
            if abs(refinado - bpm0) / bpm0 < 0.04:              # o rastreamento só ajusta a casa decimal
                bpm = float(refinado)
        inter = np.diff(t)
        regular = float(max(0.0, 1.0 - min(1.0, np.std(inter) / (np.median(inter) or 1) * 5)))
    forca = float(min(1.0, max(0.0, _interp(ac, 60.0 * fps / bpm0)) / 0.45))
    confianca = round(0.5 * regular + 0.5 * forca, 2)
    return {"bpm": round(bpm, 1), "bpm_inteiro": int(round(bpm)), "confianca": confianca,
            "alternativa": alternativa, "batidas": int(len(batidas))}


# ======================================================================================================================
# Tonalidade
# ======================================================================================================================
def estimar_tom(x, sr: int = TAXA) -> dict:
    """{'tonica': 5, 'modo': 'menor', 'nome': 'F menor', 'camelot': '4A', 'confianca': 0..1, 'afinacao_cents': -12,
    'segunda': {...}, 'croma': [12 valores]}"""
    np = _np()
    n_fft, hop = 8192, 4096
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    faixa = (freqs >= 55.0) & (freqs <= 2000.0)
    idx = np.nonzero(faixa)[0]
    f_sel = freqs[idx]
    picos_f, picos_m = [], []
    for _ini, mag in _espectro(x, n_fft, hop, pedaco=256):
        m = mag[:, idx]
        c = np.log1p(100.0 * m / (m.max() or 1.0))
        pico = (c[:, 1:-1] > c[:, :-2]) & (c[:, 1:-1] >= c[:, 2:]) & (c[:, 1:-1] > 0.2 * c.max(axis=1, keepdims=True))
        q, b = np.nonzero(pico)
        b = b + 1
        # posição do pico com interpolação parabólica (precisão de cents)
        a, y, z = c[q, b - 1], c[q, b], c[q, b + 1]
        den = a - 2 * y + z
        desl = np.where(np.abs(den) > 1e-9, 0.5 * (a - z) / den, 0.0)
        passo = f_sel[1] - f_sel[0]
        picos_f.append(f_sel[b] + desl * passo)
        picos_m.append(y)
    if not picos_f:
        raise ErroAnalise("Não há notas suficientes no áudio para achar a tonalidade.")
    pf, pm = np.concatenate(picos_f), np.concatenate(picos_m)
    if pf.size < 50:
        raise ErroAnalise("Não há notas suficientes no áudio para achar a tonalidade.")
    midi = 69.0 + 12.0 * np.log2(pf / 440.0)
    desvio = (midi - np.round(midi)) * 2 * np.pi                    # afinação: média circular dos desvios
    afin = float(np.angle(np.sum(pm * np.exp(1j * desvio))) / (2 * np.pi))
    midi_c = midi - afin
    classe = np.mod(np.round(midi_c), 12).astype(int)
    peso = pm * np.where(pf < 250.0, 1.6, 1.0)                     # o baixo indica mais a tônica
    croma = np.bincount(classe, weights=peso, minlength=12)
    croma = croma / (croma.max() or 1.0)
    pont = []
    for modo, k in (("maior", 0), ("menor", 1)):
        for tonica in range(12):
            r = 0.0
            for perfil in PERFIS.values():
                p = np.roll(np.array(perfil[k]), tonica)
                r += float(np.corrcoef(croma, p)[0, 1])
            pont.append((r / len(PERFIS), tonica, modo))
    pont.sort(reverse=True)
    r1, t1, m1 = pont[0]
    r2, t2, m2 = pont[1]
    confianca = round(float(max(0.0, min(1.0, (r1 - r2) / 0.12)) * max(0.0, min(1.0, r1 / 0.6))), 2)
    res = nome_tom(t1, m1)
    res.update(confianca=confianca, correlacao=round(r1, 3), afinacao_cents=int(round(afin * 100)),
               segunda=dict(nome_tom(t2, m2), correlacao=round(r2, 3)), croma=[round(float(v), 3) for v in croma])
    return res


def rotulo_confianca(c) -> str:
    if c is None:
        return ""
    return "alta" if c >= 0.7 else ("média" if c >= 0.4 else "baixa")


def analisar_audio(ffmpeg: str, caminho: str, cancelado=None, bpm: bool = True, tom: bool = True) -> dict:
    """Decodifica e calcula BPM e/ou tonalidade. Levanta ErroAnalise com a mensagem em português."""
    x = decodificar(ffmpeg, caminho, cancelado=cancelado)
    r = {"duracao_analisada": round(len(x) / TAXA, 1)}
    if bpm:
        try:
            r["bpm"] = estimar_bpm(x)
        except ErroAnalise as e:
            r["bpm_erro"] = str(e)
    if cancelado and cancelado():
        raise ErroAnalise("cancelado")
    if tom:
        try:
            r["tom"] = estimar_tom(x)
        except ErroAnalise as e:
            r["tom_erro"] = str(e)
    return r


# ======================================================================================================================
# BPM de catálogo (Deezer, API pública sem login)
# ======================================================================================================================
DEEZER_API = "https://api.deezer.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) yPeleTools"


def _normal(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\((?:feat|ft|with)[^)]*\)|\[(?:feat|ft)[^\]]*\]", " ", s)
    s = re.sub(r"\b(official|video|audio|lyrics?|clipe|oficial|hd|4k|remaster(ed)?( \d{4})?)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def _abrir_json(url: str, abrir=None, timeout: float = 12.0):
    if abrir is not None:
        return abrir(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(2_000_000).decode("utf-8", "replace"))


def bpm_do_catalogo(titulo: str, artista: str, duracao=None, isrc: str = "", abrir=None) -> "dict | None":
    """BPM publicado pelo Deezer para a MESMA gravação: pelo ISRC (quando o Spotify informa) ou por busca com título e
    artista, aceitando só resultado com título e artista iguais (normalizados) e duração a até 4 s. bpm 0 = o Deezer não
    tem o dado. Devolve {'bpm', 'fonte', 'id', 'titulo', 'artista', 'duracao'} ou None. Erro de rede -> None."""
    try:
        cand = []
        if isrc:
            d = _abrir_json("%s/track/isrc:%s" % (DEEZER_API, urllib.parse.quote(isrc)), abrir)
            if isinstance(d, dict) and d.get("id") and not d.get("error"):
                cand.append(d)
        if not cand and titulo:
            q = 'artist:"%s" track:"%s"' % (artista, titulo) if artista else titulo
            d = _abrir_json("%s/search?q=%s&limit=10" % (DEEZER_API, urllib.parse.quote(q)), abrir)
            for e in (d.get("data") or []) if isinstance(d, dict) else []:
                if _normal(e.get("title")) != _normal(titulo) and _normal(e.get("title_short")) != _normal(titulo):
                    continue
                art = _normal((e.get("artist") or {}).get("name"))
                if artista and art not in _normal(artista) and _normal(artista).split(" ")[0] not in art:
                    continue
                if duracao and e.get("duration") and abs(float(e["duration"]) - float(duracao)) > 4:
                    continue
                cand.append(e)
        for e in cand[:3]:
            completo = e if "bpm" in e else _abrir_json("%s/track/%s" % (DEEZER_API, e["id"]), abrir)
            if not isinstance(completo, dict):
                continue
            if duracao and completo.get("duration") and abs(float(completo["duration"]) - float(duracao)) > 4:
                continue
            bpm = float(completo.get("bpm") or 0)
            if 40 <= bpm <= 250:
                return {"bpm": round(bpm, 1), "fonte": "Deezer (catálogo público)", "id": completo.get("id"),
                        "titulo": completo.get("title"), "artista": (completo.get("artist") or {}).get("name"),
                        "duracao": completo.get("duration")}
    except Exception:
        return None
    return None
