"""yPeléTools — Web Hub: camada de rede, validação de mídia e mecanismos de download.

Desde a Beta 4.0.0, QUEM DECIDE o mecanismo é a arquitetura de provedores (ypele_webhub_provedores.py: CoreManager e
os provedores YTDLPProvider, GalleryDLProvider, GenericHTMLProvider, YTDLPGenericProvider, StreamlinkProvider e
DynamicPageProvider). Este módulo continua com o que eles usam: a sessão HTTP, a sondagem (o tipo REAL de um endereço
pelo Content-Type e pelos primeiros bytes, nunca pela extensão), o analisador de HTML, o navegador sem janela, os
mecanismos externos e o download. `Roteador` continua existindo como nome antigo do CoreManager.

Mecanismos (do mais leve ao mais pesado; só o necessário roda):
  1. HTTP (requests): o link é um arquivo? (HEAD; sem HEAD confiável, GET do 1º byte). Segue redirecionamentos um a um,
     cada destino conferido como endereço público.
  2. yt-dlp (do app, por callback): sites com extrator próprio e o extrator genérico.
  3. Analisador próprio (requests + Beautiful Soup): Open Graph, <video>/<audio>/<source>, JSON-LD, players
     incorporados (<iframe>), links para arquivos, galerias de imagens. NENHUM endereço achado no HTML é aceito sem
     validação (resposta real, tipo e tamanho).
  4. Playwright (opcional): só quando a página depende de JavaScript e nada foi achado antes; observa as respostas de
     mídia que a página carrega sozinha. Não clica em nada, não resolve CAPTCHA, não contorna verificações.
  5. gallery-dl (opcional): galerias e coleções de imagens de sites que ele conhece.
  6. Streamlink (opcional): transmissões de sites que ele conhece, quando o yt-dlp não serviu.

Nada aqui contorna login, paywall, DRM ou CAPTCHA. Endereços da própria máquina e da rede local são recusados (também
depois de redirecionar). Tokens, assinaturas e cookies não vão para os logs (url_para_log).

O módulo não depende do app: quem usa passa as funções do yt-dlp e o Python que roda os mecanismos externos.
"""
from __future__ import annotations

import ipaddress
import json
import os
import posixpath
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

VERSAO_MODULO = 2
# Chrome estável de outubro de 2026 (com a redução de User-Agent do Chrome, só a versão principal aparece)
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 "
      "Safari/537.36")
CABECALHOS_NAVEGADOR = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
}
LIMITE_HTML = 3_000_000                 # bytes lidos de uma página
MAX_REDIRECIONAMENTOS = 5               # saltos seguidos um a um (cada destino conferido como endereço público)
BYTES_SONDA = 512                       # bytes lidos no GET de sondagem (para reconhecer o arquivo pelo conteúdo)
MAX_CANDIDATOS = 80
MIN_IMAGEM = 8_000                      # bytes: abaixo disso é ícone/pixel de rastreamento, não uma imagem da página
_NOWIN = {"creationflags": 0x08000000} if sys.platform == "win32" else {}

# ----------------------------------------------------------------------------------------------------------------------
# Erros com causa (a interface mostra a mensagem; o diagnóstico guarda o detalhe técnico, sem dados sensíveis)
# ----------------------------------------------------------------------------------------------------------------------
TIPOS_ERRO = {
    "url_invalida": "URL inválida", "local": "Endereço local recusado", "inexistente": "Página inexistente",
    "negado": "Acesso negado", "conexao": "Falha de conexão", "timeout": "Tempo esgotado",
    "redirecionamento": "Redirecionamento inesperado", "sem_midia": "Nenhuma mídia identificável",
    "varios_arquivos": "Vários arquivos na página", "formato": "Formato não suportado",
    "expirado": "Link temporário expirado", "extrator": "Falha do extrator", "dependencia": "Componente indisponível",
    "download": "Falha de download", "conversao": "Falha de conversão", "salvar": "Falha ao salvar",
    "cancelado": "Download cancelado", "protecao": "Proteção do site", "limite": "Limite de pedidos",
    "servidor": "Erro do servidor", "drm": "Conteúdo protegido (DRM)",
}


class ErroWeb(Exception):
    """Erro do Web Hub com a causa (`tipo`, uma chave de TIPOS_ERRO), a mensagem para o usuário e o detalhe técnico."""

    def __init__(self, tipo: str, mensagem: str, detalhe: str = "", componente: str = "") -> None:
        super().__init__(mensagem)
        self.tipo = tipo if tipo in TIPOS_ERRO else "download"
        self.detalhe = detalhe
        self.componente = componente          # "playwright", "gallery-dl"... quando falta um componente

    @property
    def titulo(self) -> str:
        return TIPOS_ERRO[self.tipo]


class Cancelado(Exception):
    """O usuário cancelou (ou o app está fechando)."""


# ----------------------------------------------------------------------------------------------------------------------
# Endereços: público, para o log, temporário
# ----------------------------------------------------------------------------------------------------------------------
def endereco_publico(url: str) -> str:
    """'' se o link aponta para um endereço público na internet; senão, o motivo."""
    try:
        p = urllib.parse.urlsplit(url)
    except ValueError:
        return "endereço malformado"
    if p.scheme not in ("http", "https"):
        return "só links http:// e https:// são aceitos"
    host = (p.hostname or "").strip().lower()
    if not host:
        return "link sem endereço"
    if p.username or p.password:
        return "links com usuário e senha embutidos não são aceitos"
    if os.environ.get("YPELE_UNIVERSAL_PERMITIR_LOCAL") == "1":       # só nos testes (servidor local)
        return ""
    if host == "localhost" or host.endswith((".localhost", ".local", ".internal", ".lan", ".home")):
        return "endereços locais não são aceitos"
    try:
        porta = p.port
    except ValueError:
        return "porta inválida"
    try:
        ips = {i[4][0] for i in socket.getaddrinfo(host, porta or (443 if p.scheme == "https" else 80),
                                                    proto=socket.IPPROTO_TCP)}
    except (OSError, UnicodeError):
        return _NAO_ACHOU + host
    for ip in ips:
        a = ipaddress.ip_address(ip.split("%")[0])
        if a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast or a.is_unspecified:
            return "o link aponta para a rede local (%s), que o Web Hub não acessa" % ip
    return ""


_NAO_ACHOU = "dns:"


def exigir_publico(url: str, redirecionado: int = 0) -> None:
    """Levanta o ErroWeb certo se o endereço não puder ser acessado: domínio que não existe (ou sem internet), rede
    local/própria máquina (também depois de um redirecionamento) ou link malformado."""
    motivo = endereco_publico(url)
    if not motivo:
        return
    if motivo.startswith(_NAO_ACHOU):
        host = motivo[len(_NAO_ACHOU):]
        raise ErroWeb("conexao", "O endereço %s não foi encontrado: confira o link ou a sua internet." % host,
                      "DNS sem resposta para %s" % host)
    if redirecionado:
        raise ErroWeb("redirecionamento", "O link redireciona para um endereço não permitido (%s)." % motivo,
                      "redirecionamento %d -> %s" % (redirecionado, url_para_log(url)))
    raise ErroWeb("local", "Link recusado: %s." % motivo)


_SENSIVEIS = re.compile(r"(token|sig|signature|lsig|key|auth|session|sess|cookie|policy|hash|hmac|expires?|exp|"
                        r"credential|secret|pass|hdnts|hdnea|x-amz-[a-z-]+|x-goog-[a-z-]+)", re.I)


def url_para_log(url: str, limite: int = 120) -> str:
    """Endereço para o log e para as mensagens: domínio e caminho; a consulta (?...) é trocada por '?…' (assinaturas,
    tokens e prazos de URLs temporárias nunca são registrados)."""
    try:
        p = urllib.parse.urlsplit(str(url))
    except ValueError:
        return "(endereço malformado)"
    base = "%s://%s%s" % (p.scheme or "https", p.hostname or "", p.path or "")
    if p.query:
        base += "?…"
    return base if len(base) <= limite else base[:limite - 1] + "…"


_PRAZO = ("expire", "expires", "exp", "x-amz-expires", "x-goog-expires", "e", "validto", "deadline")
_ASSINATURA = ("sig", "signature", "lsig", "token", "x-amz-signature", "x-goog-signature", "policy", "key-pair-id",
               "hdnts", "hdnea", "hmac", "st", "md5", "auth", "s")


def url_temporaria(url: str, agora: float = None) -> dict:
    """{'temporaria': bool, 'expira': timestamp|None, 'expirada': bool}. Temporária = tem prazo ou assinatura na
    consulta (googlevideo, S3, CloudFront, Akamai...). O prazo só é lido quando é um número de tempo Unix plausível."""
    try:
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query, keep_blank_values=True)
    except ValueError:
        return {"temporaria": False, "expira": None, "expirada": False}
    chaves = {k.lower(): v for k, v in q.items()}
    tem_assinatura = any(k in chaves for k in _ASSINATURA)
    expira = None
    for k in _PRAZO:
        v = (chaves.get(k) or [""])[0]
        if v.isdigit() and 1_500_000_000 < int(v) < 4_000_000_000:
            expira = int(v)
            break
    agora = time.time() if agora is None else agora
    return {"temporaria": bool(tem_assinatura or expira), "expira": expira,
            "expirada": bool(expira and expira < agora + 15)}


# ----------------------------------------------------------------------------------------------------------------------
# Categorias de arquivo
# ----------------------------------------------------------------------------------------------------------------------
CAT_EXT = {
    "video": {"mp4", "m4v", "mov", "mkv", "avi", "webm", "wmv", "flv", "mpeg", "mpg", "ts", "m2ts", "3gp", "ogv"},
    "audio": {"mp3", "wav", "ogg", "oga", "flac", "aac", "m4a", "opus", "wma", "aiff", "aif", "alac", "mka"},
    "gif": {"gif"},
    "imagem": {"jpg", "jpeg", "jpe", "jfif", "png", "webp", "bmp", "dib", "tif", "tiff", "apng", "avif", "heic"},
    "documento": {"pdf", "doc", "docx", "odt", "rtf", "txt", "epub", "xls", "xlsx", "ods", "csv", "ppt", "pptx", "odp"},
    "compactado": {"zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "iso"},
    "torrent": {"torrent"},
    "stream": {"m3u8", "mpd"},
}
MIME_STREAM = {"application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl",
               "application/dash+xml", "video/vnd.mpeg.dash.mpd"}
MIME_GENERICO = {"", "application/octet-stream", "binary/octet-stream", "application/force-download",
                 "application/download", "application/x-download"}


def ext_do_caminho(url_ou_nome: str) -> str:
    try:
        caminho = urllib.parse.unquote(urllib.parse.urlsplit(url_ou_nome).path) if "://" in url_ou_nome \
            else url_ou_nome
    except ValueError:
        return ""
    return posixpath.splitext(caminho)[1].lower().lstrip(".")[:8]


def categoria(ext: str = "", mime: str = "") -> str:
    ext = str(ext or "").lower().lstrip(".")
    mime = str(mime or "").lower().split(";")[0].strip()
    if mime in MIME_STREAM or ext in CAT_EXT["stream"]:
        return "stream"
    if mime == "image/gif" or ext == "gif":
        return "gif"
    for cat, exts in CAT_EXT.items():
        if ext in exts:
            return cat
    if mime.startswith("video/"):
        return "video"
    if mime.startswith("audio/"):
        return "audio"
    if mime.startswith("image/"):
        return "imagem"
    if mime == "application/x-bittorrent":
        return "torrent"
    if mime in ("application/pdf", "application/msword") or "officedocument" in mime:
        return "documento"
    if mime in ("application/zip", "application/x-rar-compressed", "application/x-7z-compressed",
                "application/gzip", "application/x-tar", "application/vnd.rar"):
        return "compactado"
    return "arquivo"


# ----------------------------------------------------------------------------------------------------------------------
# HTTP (requests)
# ----------------------------------------------------------------------------------------------------------------------
def _requests():
    """O requests, quando o Python do app tem (ele vem com o yt-dlp na maioria das instalações). None = sem ele: o
    Web Hub usa o urllib da biblioteca padrão, com o mesmo comportamento (nunca deixa de funcionar por isso)."""
    try:
        import requests
        return requests
    except Exception:
        return None


def motor_http() -> str:
    rq = _requests()
    return ("requests %s" % getattr(rq, "__version__", "")).strip() if rq is not None else "urllib (padrão do Python)"


class _SemRedirecionar(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None                       # quem segue os redirecionamentos é _abrir, um a um, conferindo cada destino


class _RespostaUrllib:
    """O pedaço da resposta do requests que o Web Hub usa, sobre o urllib."""

    def __init__(self, r) -> None:
        self._r = r
        self.status_code = int(getattr(r, "status", None) or getattr(r, "code", None) or r.getcode())
        self.headers = r.headers
        ct = self.headers.get("Content-Type") or ""
        m = re.search(r"charset=([\w.:-]+)", ct, re.I)
        self.encoding = m.group(1) if m else None

    @property
    def is_redirect(self) -> bool:
        return self.status_code in (301, 302, 303, 307, 308) and bool(self.headers.get("Location"))

    def iter_content(self, n: int = 65536):
        while True:
            b = self._r.read(n)
            if not b:
                break
            yield b

    def close(self) -> None:
        try:
            self._r.close()
        except Exception:
            pass


class _SessaoUrllib:
    def __init__(self) -> None:
        self.headers: dict = {}
        self.trust_env = True
        self._abridor = urllib.request.build_opener(_SemRedirecionar)

    def request(self, metodo, url, headers=None, timeout=15.0, stream=True, allow_redirects=False):
        cab = dict(self.headers)
        cab.update(headers or {})
        req = urllib.request.Request(url, method=metodo, headers=cab)
        try:
            r = self._abridor.open(req, timeout=timeout)
        except urllib.error.HTTPError as e:     # 3xx (não seguido), 4xx e 5xx: é uma resposta, com status e cabeçalhos
            r = e
        return _RespostaUrllib(r)


def nova_sessao():
    rq = _requests()
    s = rq.Session() if rq is not None else _SessaoUrllib()
    s.headers.update(CABECALHOS_NAVEGADOR)
    s.trust_env = True
    return s


def _erro_de_requisicao(e, url: str) -> ErroWeb:
    import ssl
    rq = _requests()
    alvo = url_para_log(url)
    if isinstance(e, ErroWeb):
        return e
    motivo = getattr(e, "reason", None)
    if isinstance(e, (TimeoutError, socket.timeout)) or isinstance(motivo, (TimeoutError, socket.timeout)) or \
            (rq is not None and isinstance(e, rq.exceptions.Timeout)):
        return ErroWeb("timeout", "O site demorou demais para responder (%s). Tente de novo mais tarde." % alvo, str(e))
    if isinstance(e, ssl.SSLError) or isinstance(motivo, ssl.SSLError) or \
            (rq is not None and isinstance(e, rq.exceptions.SSLError)):
        return ErroWeb("conexao", "Conexão segura recusada (certificado do site inválido): %s." % alvo, str(e))
    if rq is not None and isinstance(e, rq.exceptions.TooManyRedirects):
        return ErroWeb("redirecionamento", "O link redireciona sem parar: %s." % alvo, str(e))
    if rq is not None and isinstance(e, rq.exceptions.InvalidURL) or isinstance(e, ValueError):
        return ErroWeb("url_invalida", "Link inválido: %s." % alvo, str(e))
    if isinstance(e, (urllib.error.URLError, OSError)) or (rq is not None and
                                                           isinstance(e, rq.exceptions.ConnectionError)):
        return ErroWeb("conexao", "Não consegui conectar ao site (%s). Confira a internet e o link." % alvo, str(e))
    return ErroWeb("download", "Falha ao acessar %s: %s." % (alvo, type(e).__name__), str(e))


def erro_http(status: int, url: str) -> ErroWeb:
    alvo = url_para_log(url)
    if status == 404:
        return ErroWeb("inexistente", "Página ou arquivo não encontrado (HTTP 404): %s." % alvo, "HTTP 404")
    if status == 410:
        return ErroWeb("expirado", "O link não existe mais ou expirou (HTTP 410): %s." % alvo, "HTTP 410")
    if status in (401, 403):
        return ErroWeb("negado", "O site recusou o acesso (HTTP %d). O conteúdo pode exigir login, ser privado ou o "
                                 "site pode bloquear downloads automáticos; o yPeléTools não contorna essas proteções."
                       % status, "HTTP %d" % status)
    if status == 429:
        return ErroWeb("limite", "O site limitou os pedidos (HTTP 429). Espere alguns minutos e tente de novo.",
                       "HTTP 429")
    if status >= 500:
        return ErroWeb("servidor", "O servidor do site falhou (HTTP %d). Tente de novo mais tarde." % status,
                       "HTTP %d" % status)
    return ErroWeb("download", "O site respondeu HTTP %d para %s." % (status, alvo), "HTTP %d" % status)


def _nome_de_content_disposition(valor: str) -> str:
    valor = valor or ""
    m = re.search(r"filename\*\s*=\s*[^']*''([^;]+)", valor, re.I)
    if m:
        return urllib.parse.unquote(m.group(1).strip().strip('"'))
    m = re.search(r'filename\s*=\s*"([^"]+)"', valor, re.I) or re.search(r"filename\s*=\s*([^;]+)", valor, re.I)
    return m.group(1).strip() if m else ""


@dataclass
class Sonda:
    url: str
    url_final: str
    status: int
    mime: str = ""
    tamanho: Optional[int] = None
    nome: str = ""
    ext: str = ""
    categoria: str = "arquivo"
    aceita_range: bool = False
    redirecionamentos: int = 0
    metodo: str = "HEAD"
    temporaria: bool = False
    expira: Optional[int] = None
    mime_declarado: str = ""            # (4.0.0) o Content-Type original, quando os primeiros bytes o corrigiram
    pela_assinatura: bool = False       # (4.0.0) o tipo veio da assinatura dos bytes (o servidor não disse)

    @property
    def e_pagina(self) -> bool:
        return self.mime in ("text/html", "application/xhtml+xml")


def _abrir(sessao, metodo: str, url: str, cabecalhos: dict = None, timeout: float = 15.0, stream: bool = True):
    """Uma requisição seguindo redirecionamentos UM A UM: cada destino tem de ser um endereço público. Devolve
    (resposta, url_final, n_redirecionamentos). A resposta fica aberta (stream) para quem chamou ler o que precisar."""
    atual, n = url, 0
    while True:
        exigir_publico(atual, n)
        try:
            r = sessao.request(metodo, atual, headers=cabecalhos or {}, timeout=timeout, stream=stream,
                               allow_redirects=False)
        except Exception as e:
            raise _erro_de_requisicao(e, atual)
        if r.is_redirect or r.status_code in (301, 302, 303, 307, 308) and r.headers.get("Location"):
            destino = urllib.parse.urljoin(atual, r.headers.get("Location", ""))
            r.close()
            n += 1
            if n > MAX_REDIRECIONAMENTOS:
                raise ErroWeb("redirecionamento", "O link redireciona demais (mais de %d vezes)."
                              % MAX_REDIRECIONAMENTOS)
            if r.status_code == 303:
                metodo = "GET"
            atual = destino
            continue
        return r, atual, n


# ---------- tipo REAL do conteúdo (4.0.0): Content-Type e assinatura dos primeiros bytes valem mais que a extensão ----
MIME_PARA_EXT = {
    "video/mp4": "mp4", "video/x-m4v": "m4v", "video/webm": "webm", "video/x-matroska": "mkv",
    "video/quicktime": "mov", "video/x-msvideo": "avi", "video/avi": "avi", "video/x-flv": "flv",
    "video/mp2t": "ts", "video/3gpp": "3gp", "video/ogg": "ogv", "video/mpeg": "mpg", "video/x-ms-wmv": "wmv",
    "audio/mpeg": "mp3", "audio/mp3": "mp3", "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/aac": "aac",
    "audio/ogg": "ogg", "audio/opus": "opus", "audio/wav": "wav", "audio/x-wav": "wav", "audio/wave": "wav",
    "audio/flac": "flac", "audio/x-flac": "flac", "audio/webm": "webm", "audio/x-ms-wma": "wma", "audio/aiff": "aiff",
    "audio/x-aiff": "aiff", "audio/x-matroska": "mka",
    "image/jpeg": "jpg", "image/png": "png", "image/gif": "gif", "image/webp": "webp", "image/avif": "avif",
    "image/bmp": "bmp", "image/tiff": "tif", "image/heic": "heic",
    "application/pdf": "pdf", "application/zip": "zip", "application/x-rar-compressed": "rar",
    "application/vnd.rar": "rar", "application/x-7z-compressed": "7z", "application/gzip": "gz",
    "application/x-bittorrent": "torrent", "application/vnd.apple.mpegurl": "m3u8", "application/x-mpegurl": "m3u8",
    "application/dash+xml": "mpd",
}
# MIME "fraco": o servidor não sabe (ou não diz) o que entrega; aí os primeiros bytes decidem
MIME_FRACO = MIME_GENERICO | {"text/plain", "application/x-unknown", "application/unknown"}


def identificar_conteudo(inicio: bytes) -> tuple:
    """(mime, ext) pela assinatura dos primeiros bytes de um arquivo; ('', '') se não reconhecer.
    Reconhece os formatos que o Web Hub baixa: vídeo (MP4/MOV/3GP, Matroska/WebM, FLV, AVI, MPEG-TS), áudio (MP3,
    AAC, M4A, Ogg/Opus, WAV, FLAC), listas HLS/DASH, imagens (JPEG, PNG, GIF, WebP), PDF, ZIP, RAR, 7z, GZIP e
    .torrent, além de páginas HTML disfarçadas de arquivo (um erro servido como 'video.mp4')."""
    b = bytes(inicio or b"")
    if not b:
        return "", ""
    cabeca = b[:512].lstrip()
    baixo = cabeca[:64].lower()
    if baixo.startswith((b"<!doctype html", b"<html", b"<head", b"<?xml version")) and b"<mpd" not in cabeca.lower():
        if baixo.startswith(b"<?xml") and b"<html" not in cabeca.lower():
            return "", ""
        return "text/html", "html"
    if cabeca.startswith(b"#EXTM3U"):
        return "application/vnd.apple.mpegurl", "m3u8"
    if b"<MPD" in cabeca:
        return "application/dash+xml", "mpd"
    if len(b) >= 12 and b[4:8] == b"ftyp":
        marca = b[8:12]
        if marca in (b"M4A ", b"M4B ", b"M4P "):
            return "audio/mp4", "m4a"
        if marca == b"qt  ":
            return "video/quicktime", "mov"
        if marca.startswith(b"3g"):
            return "video/3gpp", "3gp"
        if marca in (b"avif", b"avis"):
            return "image/avif", "avif"
        if marca in (b"heic", b"heix", b"mif1"):
            return "image/heic", "heic"
        return "video/mp4", "mp4"
    if b.startswith(b"\x1aE\xdf\xa3"):
        return ("video/webm", "webm") if b"webm" in b[:64] else ("video/x-matroska", "mkv")
    if b.startswith(b"FLV\x01"):
        return "video/x-flv", "flv"
    if b.startswith(b"RIFF") and len(b) >= 12:
        sub = b[8:12]
        if sub == b"WAVE":
            return "audio/wav", "wav"
        if sub == b"AVI ":
            return "video/x-msvideo", "avi"
        if sub == b"WEBP":
            return "image/webp", "webp"
    if len(b) > 188 and b[0] == 0x47 and b[188] == 0x47:
        return "video/mp2t", "ts"
    if b.startswith(b"OggS"):
        if b"OpusHead" in b[:128]:
            return "audio/ogg", "opus"
        if b"theora" in b[:128]:
            return "video/ogg", "ogv"
        return "audio/ogg", "ogg"
    if b.startswith(b"fLaC"):
        return "audio/flac", "flac"
    if b.startswith(b"ID3"):
        return "audio/mpeg", "mp3"
    if len(b) >= 2 and b[0] == 0xFF and (b[1] & 0xF6) == 0xF0:          # ADTS (AAC): sync 0xFFF, layer 00
        return "audio/aac", "aac"
    if len(b) >= 2 and b[0] == 0xFF and (b[1] & 0xE0) == 0xE0 and (b[1] & 0x06) != 0:   # quadro MPEG de áudio
        return "audio/mpeg", "mp3"
    if b.startswith(b"\xff\xd8\xff"):
        return "image/jpeg", "jpg"
    if b.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png", "png"
    if b.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif", "gif"
    if b.startswith(b"%PDF"):
        return "application/pdf", "pdf"
    if b.startswith(b"PK\x03\x04"):
        return "application/zip", "zip"
    if b.startswith(b"Rar!\x1a\x07"):
        return "application/vnd.rar", "rar"
    if b.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "application/x-7z-compressed", "7z"
    if b.startswith(b"\x1f\x8b"):
        return "application/gzip", "gz"
    if b.startswith(b"d8:announce") or b.startswith(b"d13:announce-list") or b.startswith(b"d4:info"):
        return "application/x-bittorrent", "torrent"
    return "", ""


def cabecalhos_para(destino: str, referer: str = "") -> dict:
    """Cabeçalhos de um pedido conforme o que se espera receber, como um navegador comum manda (4.0.0):
    'pagina' (documento HTML), 'midia' (vídeo/áudio/arquivo), 'imagem' ou 'manifesto' (HLS/DASH). Com `referer`, a
    página de onde o endereço saiu. Não há troca de identidade, rotação de User-Agent nem imitação de impressão
    digital: a sessão é a de um navegador comum, e proteções do site (login, CAPTCHA, anti-robô) não são contornadas."""
    cab = {"User-Agent": UA, "Accept-Language": CABECALHOS_NAVEGADOR["Accept-Language"]}
    if destino == "pagina":
        cab.update({"Accept": CABECALHOS_NAVEGADOR["Accept"], "Upgrade-Insecure-Requests": "1",
                    "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "same-origin" if referer else "none"})
    elif destino == "imagem":
        cab.update({"Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8", "Sec-Fetch-Dest": "image",
                    "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Site": "cross-site" if referer else "none"})
    elif destino == "manifesto":
        cab.update({"Accept": "*/*", "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "cross-site" if referer else "none"})
    else:
        cab.update({"Accept": "*/*", "Accept-Encoding": "identity",
                    "Sec-Fetch-Dest": "video" if referer else "document",
                    "Sec-Fetch-Mode": "no-cors" if referer else "navigate",
                    "Sec-Fetch-Site": "cross-site" if referer else "none"})
    if referer:
        cab["Referer"] = referer
    return cab


def _preencher(s: Sonda, r, inicio: bytes = b"") -> None:
    """Preenche a sonda com o que a RESPOSTA diz. Ordem de autoridade do tipo (4.0.0): Content-Type específico >
    assinatura dos primeiros bytes (quando o Content-Type é genérico ou falta) > extensão do nome/endereço. A extensão
    da URL nunca decide sozinha se há algo mais forte (um 'foto.jpg' que entrega video/mp4 é vídeo .mp4)."""
    h = r.headers
    s.mime = (h.get("Content-Type") or "").split(";")[0].strip().lower()
    faixa = h.get("Content-Range") or ""
    m = re.search(r"/(\d+)\s*$", faixa)
    tam = h.get("Content-Length")
    if m:
        s.tamanho = int(m.group(1))
    elif tam and tam.isdigit() and (s.metodo == "HEAD" or r.status_code == 200):
        s.tamanho = int(tam)
    s.aceita_range = (r.status_code == 206) or (h.get("Accept-Ranges", "").lower() == "bytes")
    s.nome = _nome_de_content_disposition(h.get("Content-Disposition") or "")
    nome = s.nome or posixpath.basename(urllib.parse.unquote(urllib.parse.urlsplit(s.url_final).path))
    ext_nome = ext_do_caminho(nome) or ext_do_caminho(s.url_final)
    mime_bytes, ext_bytes = identificar_conteudo(inicio) if inicio else ("", "")
    if s.mime in MIME_FRACO and mime_bytes:
        s.mime_declarado, s.mime = s.mime, mime_bytes       # o conteúdo diz o que o servidor não disse
        s.pela_assinatura = True
    if s.mime in ("text/html", "application/xhtml+xml"):
        s.categoria, s.ext = "pagina", ext_nome
    elif s.mime and s.mime not in MIME_FRACO:
        s.categoria = categoria("", s.mime)
        if s.categoria == "arquivo" and categoria(ext_nome) != "arquivo":
            s.categoria = categoria(ext_nome, s.mime)     # MIME específico, mas desconhecido aqui: a extensão ajuda
        ext_mime = ext_bytes if s.pela_assinatura else MIME_PARA_EXT.get(s.mime, "")
        # a extensão do nome vale se combinar com o tipo real; senão, a do tipo real (nome enganoso)
        cat_nome = categoria(ext_nome) if ext_nome else ""
        combina = cat_nome == s.categoria or {cat_nome, s.categoria} <= {"video", "audio"}   # contêiner ambíguo
        s.ext = ext_nome if (ext_nome and combina) else (ext_mime or ext_nome)
    else:
        s.ext = ext_nome
        s.categoria = categoria(ext_nome, s.mime)
    t = url_temporaria(s.url_final)
    s.temporaria, s.expira = t["temporaria"], t["expira"]


_MARCAS_DESAFIO = ("just a moment", "challenges.cloudflare.com", "cf-chl", "verify you are human",
                   "checking your browser", "ddos-guard", "attention required", "captcha", "are you a robot")


def e_desafio(status: int, cabecalhos=None, texto: str = "") -> bool:
    """A resposta é uma verificação anti-robô (Cloudflare e parecidos), e não o conteúdo? O cabeçalho
    cf-mitigated: challenge basta; sem ele, um 403/429/503 com as marcas conhecidas no começo da página."""
    try:
        if str((cabecalhos or {}).get("cf-mitigated") or "").lower() == "challenge":
            return True
    except Exception:
        pass
    if status in (403, 429, 503) and texto:
        t = texto[:8000].lower()
        return any(m in t for m in _MARCAS_DESAFIO)
    return False


def erro_protecao(url: str, detalhe: str = "") -> ErroWeb:
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return ErroWeb("protecao", "O site %s está protegido por uma verificação anti-robô (ex.: Cloudflare) e recusou o "
                               "acesso automático. O yPeléTools não contorna essa proteção: abra o link no navegador."
                   % (host[4:] if host.startswith("www.") else host), detalhe)


def sondar(url: str, cabecalhos: dict = None, sessao=None, timeout: float = 15.0, so_get: bool = False) -> Sonda:
    """O que o endereço entrega, sem baixar o corpo. HEAD primeiro; um GET dos primeiros BYTES_SONDA bytes (Range)
    quando o servidor não aceita HEAD (405/403/501), responde erro só ao HEAD ou não diz um tipo específico
    (Content-Type genérico). Nesse GET, os primeiros bytes identificam o arquivo pela assinatura (4.0.0): a extensão
    da URL nunca decide sozinha. A conexão é fechada logo em seguida. `so_get`: pula o HEAD (o servidor respondeu ao
    HEAD uma coisa e ao GET outra, como um 'download.php' que diz text/html no HEAD e entrega o arquivo no GET)."""
    sessao = sessao or nova_sessao()
    ultimo = None
    base = cabecalhos_para("midia", (cabecalhos or {}).get("Referer", ""))
    passos = (("HEAD", {}), ("GET", {"Range": "bytes=0-%d" % (BYTES_SONDA - 1)}))
    for metodo, extra in passos[1:] if so_get else passos:
        cab = dict(base, **(cabecalhos or {}), **extra)
        r, final, n = _abrir(sessao, metodo, url, cab, timeout)
        try:
            s = Sonda(url, final, r.status_code, redirecionamentos=n, metodo=metodo)
            if r.status_code >= 400:
                ultimo = r.status_code
                if e_desafio(r.status_code, r.headers):
                    raise erro_protecao(final, "HTTP %d, cf-mitigated: challenge (%s)" % (r.status_code, metodo))
                if metodo == "HEAD":
                    continue                      # muitos servidores só erram no HEAD: confirma com GET
                if r.status_code in (403, 429, 503):      # verificação anti-robô sem o cabeçalho? olha o começo
                    try:
                        inicio = next(r.iter_content(8192), b"")[:8192].decode("utf-8", "replace")
                    except Exception:
                        inicio = ""
                    if e_desafio(r.status_code, None, inicio):
                        raise erro_protecao(final, "HTTP %d com página de verificação anti-robô" % r.status_code)
                raise erro_http(r.status_code, final)
            inicio = b""
            if metodo == "GET":
                try:
                    for bloco in r.iter_content(BYTES_SONDA):
                        inicio += bloco
                        if len(inicio) >= BYTES_SONDA:
                            break
                except Exception:
                    pass
            _preencher(s, r, inicio[:BYTES_SONDA])
            if metodo == "HEAD" and s.mime in MIME_FRACO:
                continue                          # HEAD sem tipo específico: os primeiros bytes dizem o que é
            return s
        finally:
            r.close()
    raise erro_http(ultimo or 0, url)


def ler_pagina(url: str, cabecalhos: dict = None, sessao=None, limite: int = LIMITE_HTML,
               timeout: float = 20.0) -> dict:
    """GET da página (até `limite` bytes). {'url_final', 'status', 'html', 'mime'}. Um 4xx/5xx com corpo HTML volta
    também (alguns sites entregam a página com status de erro); quem chama decide se isso conta."""
    sessao = sessao or nova_sessao()
    cab = dict(cabecalhos_para("pagina", (cabecalhos or {}).get("Referer", "")), **(cabecalhos or {}))
    r, final, n = _abrir(sessao, "GET", url, cab, timeout)
    try:
        mime = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        dados = b""
        if mime in ("text/html", "application/xhtml+xml", "") or r.status_code >= 400:
            for bloco in r.iter_content(65536):
                dados += bloco
                if len(dados) >= limite:
                    break
        html = _decodificar(dados, r.headers.get("Content-Type") or "")
        return {"url_final": final, "status": r.status_code, "html": html, "mime": mime, "redirecionamentos": n,
                "desafio": e_desafio(r.status_code, r.headers, html)}
    finally:
        r.close()


def _decodificar(dados: bytes, content_type: str) -> str:
    """Texto da página: charset do cabeçalho; senão o <meta charset> da própria página; senão UTF-8 (e, se não for
    UTF-8 válido, Windows-1252, o padrão dos sites antigos)."""
    cod = ""
    m = re.search(r"charset=([\w.:-]+)", content_type or "", re.I)
    if m:
        cod = m.group(1)
    else:
        m = re.search(rb"<meta[^>]+charset=[\"']?([\w.:-]+)", dados[:4096], re.I)
        if m:
            cod = m.group(1).decode("ascii", "ignore")
    if cod:
        try:
            return dados.decode(cod, "replace")
        except LookupError:
            pass
    try:
        return dados.decode("utf-8")
    except UnicodeDecodeError:
        return dados.decode("cp1252", "replace")


# ----------------------------------------------------------------------------------------------------------------------
# Analisador de HTML (Beautiful Soup; sem ele, só o essencial por expressões regulares)
# ----------------------------------------------------------------------------------------------------------------------
def bs4_disponivel() -> bool:
    return _importa("bs4")


@dataclass
class Candidato:
    url: str
    origem: str
    tipo: str                    # video | audio | imagem | gif | stream | embed | arquivo
    mime: str = ""
    largura: int = 0
    altura: int = 0


_EXT_ARQUIVO_LINK = (CAT_EXT["video"] | CAT_EXT["audio"] | CAT_EXT["documento"] | CAT_EXT["compactado"] |
                     CAT_EXT["torrent"]) - {"txt", "csv"}


def _tipo_por(url: str, mime: str = "", padrao: str = "") -> str:
    c = categoria(ext_do_caminho(url), mime)
    if c in ("video", "audio", "imagem", "gif", "stream"):
        return c
    if c in ("documento", "compactado", "torrent"):
        return "arquivo"
    return padrao


def _jsonld(objs) -> list:
    """contentUrl/embedUrl/thumbnailUrl de objetos VideoObject/AudioObject/ImageObject (inclusive dentro de @graph)."""
    out = []

    def visitar(o):
        if isinstance(o, list):
            for x in o:
                visitar(x)
        elif isinstance(o, dict):
            t = o.get("@type")
            tipos = t if isinstance(t, list) else [t]
            if any(str(x) in ("VideoObject", "AudioObject", "ImageObject", "MediaObject") for x in tipos):
                for k in ("contentUrl", "embedUrl"):
                    v = o.get(k)
                    if isinstance(v, str):
                        out.append((k, v, str(tipos[0])))
            for v in o.values():
                if isinstance(v, (dict, list)):
                    visitar(v)
    visitar(objs)
    return out


# (4.0.0) endereços de mídia dentro de scripts: configurações de player (jwplayer, video.js, Plyr...), estado de
# aplicativos (__NEXT_DATA__, __NUXT__, window.__INITIAL_STATE__) e JSON embutido. O JSON costuma escapar as barras
# (https:\/\/) e o & (\u0026); os dois são desfeitos antes da busca.
_EXT_MIDIA_SCRIPT = "mp4|m4v|webm|mkv|mov|m3u8|mpd|mp3|m4a|aac|ogg|oga|opus|wav|flac|ts"
_RX_URL_SCRIPT = re.compile(r"""(?:(?:https?:)?//|/)[^\s"'<>()\[\]{},;]+?\.(?:%s)"""
                            r"""(?:\?[^\s"'<>()\[\]{}]*)?(?=["'\s,;)\]}]|$)""" % _EXT_MIDIA_SCRIPT, re.I)
_RX_CHAVE_SCRIPT = re.compile(r"""["']?(file|src|source|url|contentUrl|videoUrl|video_url|playbackUrl|stream_url|"""
                              r"""streamUrl|hls|hlsUrl|hls_url|dash|dashUrl|dash_url|mp4|audioUrl|audio_url)["']?\s*[:=]"""
                              r"""\s*["']((?:https?:)?//[^"'\s<>]+)["']""", re.I)
# caminho relativo ("/media/x") só vale nas chaves que SÃO de mídia ("src"/"url" sozinhas apontam para qualquer coisa)
_RX_CHAVE_RELATIVA = re.compile(r"""["']?(file|source|contentUrl|videoUrl|video_url|playbackUrl|stream_url|streamUrl|"""
                                r"""hls|hlsUrl|hls_url|dash|dashUrl|dash_url|mp4|audioUrl|audio_url)["']?\s*[:=]"""
                                r"""\s*["'](/(?!/)[^"'\s<>]+)["']""", re.I)
_EXT_NAO_MIDIA = {"js", "mjs", "css", "json", "map", "html", "htm", "xhtml", "svg", "woff", "woff2", "ttf", "otf",
                  "eot", "ico", "xml", "txt", "wasm"}
_CHAVES_MIDIA = {"hls": "stream", "hlsurl": "stream", "hls_url": "stream", "dash": "stream", "dashurl": "stream",
                 "dash_url": "stream", "audiourl": "audio", "audio_url": "audio"}
MAX_SCRIPT = 1_500_000                  # caracteres de script examinados por página


def urls_em_scripts(textos, base: str) -> list:
    """[(url_absoluta, tipo, origem)] de mídias citadas em scripts/JSON da página (nada validado aqui). `tipo` vem da
    extensão ou do nome da chave ('hls' -> stream); sem nenhum dos dois, 'video' (o servidor confirma depois)."""
    vistos, out, total = set(), [], 0
    for texto in textos:
        if not texto:
            continue
        texto = texto[:max(0, MAX_SCRIPT - total)]
        total += len(texto)
        t = texto.replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/").replace("\\u0026", "&")
        t = t.replace("&amp;", "&")
        achados = [(m.group(2), _CHAVES_MIDIA.get(m.group(1).lower(), ""), "script:%s" % m.group(1))
                   for rx in (_RX_CHAVE_SCRIPT, _RX_CHAVE_RELATIVA) for m in rx.finditer(t)]
        achados += [(m.group(0), "", "script") for m in _RX_URL_SCRIPT.finditer(t)]
        for u, tipo, origem in achados:
            u = u.strip()
            if u.startswith("//"):
                u = "https:" + u
            absoluto = urllib.parse.urljoin(base, u)
            if not absoluto.lower().startswith(("http://", "https://")) or absoluto in vistos:
                continue
            ext = ext_do_caminho(absoluto)
            if ext in _EXT_NAO_MIDIA:
                continue                                   # scripts, folhas de estilo, fontes, dados do próprio site
            if not tipo:
                tipo = _tipo_por(absoluto) or ""
            if not tipo and origem == "script":
                continue                                   # endereço sem extensão de mídia e sem chave: ignora
            if tipo not in ("video", "audio", "stream"):
                if ext and categoria(ext) not in ("video", "audio", "stream", "arquivo"):
                    continue                               # imagens, scripts, CSS citados no código
                tipo = "video"
            vistos.add(absoluto)
            out.append((absoluto, tipo, origem))
            if len(out) >= 40:
                return out
        if total >= MAX_SCRIPT:
            break
    return out


def analisar_html(html: str, base: str) -> dict:
    """Lê a página e devolve o que ela DIZ ter (nada aqui está validado):
    {'titulo', 'miniatura', 'site', 'descricao', 'candidatos': [Candidato], 'precisa_js': bool, 'sinais': [str],
     'motor': 'bs4'|'regex'}."""
    r = {"titulo": "", "miniatura": "", "site": "", "descricao": "", "candidatos": [], "precisa_js": False,
         "sinais": [], "motor": "bs4" if bs4_disponivel() else "regex"}
    vistos = set()

    def add(url, origem, tipo, mime="", larg=0, alt=0):
        if not url or len(r["candidatos"]) >= MAX_CANDIDATOS:
            return
        url = url.strip()
        if url.startswith(("data:", "blob:", "javascript:", "mailto:", "about:", "#")):
            return
        absoluto = urllib.parse.urljoin(base, url)
        if not absoluto.lower().startswith(("http://", "https://")):
            return
        if absoluto in vistos:
            return
        vistos.add(absoluto)
        r["candidatos"].append(Candidato(absoluto, origem, tipo, mime, larg, alt))

    if r["motor"] == "regex":
        _analisar_regex(html, base, r, add)
        return r
    from bs4 import BeautifulSoup
    try:
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        _analisar_regex(html, base, r, add)
        return r

    def meta(*nomes):
        for n in nomes:
            tag = soup.find("meta", attrs={"property": n}) or soup.find("meta", attrs={"name": n})
            if tag and tag.get("content"):
                return str(tag.get("content")).strip()
        return ""
    r["titulo"] = meta("og:title", "twitter:title") or (soup.title.get_text(" ", strip=True) if soup.title else "")
    r["miniatura"] = meta("og:image:secure_url", "og:image", "twitter:image")
    if r["miniatura"]:
        r["miniatura"] = urllib.parse.urljoin(base, r["miniatura"])
    r["site"] = meta("og:site_name")
    r["descricao"] = meta("og:description", "description")[:300]
    for n in ("og:video:secure_url", "og:video:url", "og:video", "twitter:player:stream"):
        v = meta(n)
        if v:
            tipo = _tipo_por(v, meta("og:video:type"), "video")
            add(v, n, "embed" if tipo == "" else tipo, meta("og:video:type"))
    for n in ("og:audio:secure_url", "og:audio"):
        v = meta(n)
        if v:
            add(v, n, _tipo_por(v, meta("og:audio:type"), "audio") or "audio")
    for tag in soup.find_all(["video", "audio"]):
        padrao = tag.name
        src = tag.get("src") or tag.get("data-src")
        if src:
            add(src, "<%s>" % tag.name, _tipo_por(src, tag.get("type", ""), padrao) or padrao, tag.get("type", ""))
        for s in tag.find_all("source"):
            src = s.get("src") or s.get("data-src")
            if src:
                add(src, "<source>", _tipo_por(src, s.get("type", ""), padrao) or padrao, s.get("type", ""))
        if tag.get("poster") and not r["miniatura"]:
            r["miniatura"] = urllib.parse.urljoin(base, tag.get("poster"))
    for s in soup.find_all("script", attrs={"type": "application/ld+json"}):
        try:
            dados = json.loads(s.string or s.get_text() or "")
        except (ValueError, TypeError):
            continue
        for k, v, tipo in _jsonld(dados):
            t = "embed" if k == "embedUrl" else (_tipo_por(v, "", "video" if "Video" in tipo else
                                                            "audio" if "Audio" in tipo else "imagem"))
            add(v, "json-ld %s" % k, t or "video")
    textos = [sc.string or sc.get_text() or "" for sc in soup.find_all("script")
              if not sc.get("src") and str(sc.get("type") or "").lower() != "application/ld+json"]
    for u, tipo, origem in urls_em_scripts(textos, base):
        add(u, origem, tipo)
    for tag in soup.find_all(["iframe", "embed"]):
        src = tag.get("src") or tag.get("data-src")
        if src:
            add(src, "<%s>" % tag.name, "embed")
    for a in soup.find_all("a", href=True):
        href = a["href"]
        ext = ext_do_caminho(urllib.parse.urljoin(base, href))
        if ext in _EXT_ARQUIVO_LINK or a.has_attr("download"):
            add(href, "<a>", _tipo_por(href, "", "arquivo") or "arquivo")
        elif ext in CAT_EXT["imagem"] | CAT_EXT["gif"] and a.find("img"):
            add(href, "<a><img>", _tipo_por(href) or "imagem")      # miniatura que leva à imagem grande
    for img in soup.find_all("img"):
        src = img.get("data-src") or img.get("data-original") or img.get("src")
        srcset = img.get("srcset") or img.get("data-srcset")
        if srcset:                                                   # a maior do srcset
            partes = [p.strip().split() for p in srcset.split(",") if p.strip()]
            if partes:
                src = partes[-1][0]
        if not src:
            continue

        def num(v):
            try:
                return int(str(v).rstrip("px"))
            except (TypeError, ValueError):
                return 0
        larg, alt = num(img.get("width")), num(img.get("height"))
        if (larg and larg < 100) or (alt and alt < 100):
            continue                                                 # ícones, avatares, rastreadores
        add(src, "<img>", _tipo_por(src) or "imagem", "", larg, alt)
    # depende de JavaScript? (pouco texto, muitos scripts, raiz de aplicativo vazia, <noscript> pedindo JS)
    texto = soup.get_text(" ", strip=True)
    scripts = len(soup.find_all("script"))
    raiz = soup.find(id=re.compile(r"^(root|app|__next|__nuxt|main-app)$"))
    if raiz is not None and len(raiz.get_text(strip=True)) < 40:
        r["sinais"].append("raiz do aplicativo vazia (#%s)" % raiz.get("id"))
    ns = " ".join(t.get_text(" ", strip=True).lower() for t in soup.find_all("noscript"))
    if "javascript" in ns:
        r["sinais"].append("<noscript> pede JavaScript")
    if len(texto) < 400 and scripts >= 3:
        r["sinais"].append("pouco texto (%d caracteres) e %d scripts" % (len(texto), scripts))
    if any(re.search(r"(jwplayer|videojs|video\.js|plyr|clappr|hls\.js|dash\.js|flowplayer|playerjs)", str(s),
                     re.I) for s in soup.find_all("script", src=True)):
        r["sinais"].append("player de vídeo carregado por script")
    r["precisa_js"] = bool(r["sinais"])
    return r


_RX_META = re.compile(r'<meta[^>]+(?:property|name)=["\']([^"\']+)["\'][^>]+content=["\']([^"\']*)["\']', re.I)
_RX_SRC = re.compile(r'<(video|audio|source|iframe)[^>]+src=["\']([^"\']+)["\']', re.I)
_RX_A = re.compile(r'<a\s[^>]*href=["\']([^"\']+)["\']', re.I)
_RX_IMG = re.compile(r'<img\s[^>]*>', re.I)


def _analisar_regex(html: str, base: str, r: dict, add) -> None:
    """Sem o Beautiful Soup: Open Graph e src de <video>/<audio>/<source>/<iframe>. É menos completo e a mensagem do
    diagnóstico diz isso."""
    metas = {k.lower(): v for k, v in _RX_META.findall(html or "")}
    r["titulo"] = metas.get("og:title", "")
    if not r["titulo"]:
        m = re.search(r"<title[^>]*>(.*?)</title>", html or "", re.I | re.S)
        r["titulo"] = re.sub(r"\s+", " ", m.group(1)).strip() if m else ""
    if metas.get("og:image"):
        r["miniatura"] = urllib.parse.urljoin(base, metas["og:image"])
    for k in ("og:video:secure_url", "og:video:url", "og:video"):
        if metas.get(k):
            add(metas[k], k, _tipo_por(metas[k], metas.get("og:video:type", ""), "embed") or "embed")
    for tag, src in _RX_SRC.findall(html or ""):
        tag = tag.lower()
        add(src, "<%s>" % tag, "embed" if tag == "iframe" else (_tipo_por(src) or "video"))
    corpos = re.findall(r"<script(?![^>]*\bsrc=)(?![^>]*ld\+json)[^>]*>(.*?)</script>", html or "", re.I | re.S)
    for u, tipo, origem in urls_em_scripts(corpos, base):
        add(u, origem, tipo)
    for m in _RX_A.finditer(html or ""):
        href = m.group(1)
        ext = ext_do_caminho(urllib.parse.urljoin(base, href))
        if ext in _EXT_ARQUIVO_LINK:
            add(href, "<a>", _tipo_por(href, "", "arquivo") or "arquivo")
    for m in _RX_IMG.finditer(html or ""):
        tag = m.group(0)
        src = (re.search(r'\sdata-src=["\']([^"\']+)', tag) or re.search(r'\ssrc=["\']([^"\']+)', tag))
        if not src:
            continue
        dims = [int(x) for x in re.findall(r'\s(?:width|height)=["\']?(\d+)', tag)]
        if any(d < 100 for d in dims):
            continue
        add(src.group(1), "<img>", _tipo_por(src.group(1)) or "imagem")
    r["sinais"].append("analisador simplificado (Beautiful Soup não instalado)")


# ----------------------------------------------------------------------------------------------------------------------
# Validação de um candidato (a resposta real decide; a extensão no HTML não prova nada)
# ----------------------------------------------------------------------------------------------------------------------
def _confere_tipo(esperado: str, s: Sonda) -> bool:
    real = s.categoria
    if s.e_pagina:
        return False
    if esperado in ("video", "audio"):
        if real in ("video", "audio"):
            return True                    # mp4 só com áudio, webm de áudio...: o arquivo decide na conversão
        return s.mime in MIME_GENERICO and categoria(s.ext) in ("video", "audio")
    if esperado in ("imagem", "gif"):
        if real in ("imagem", "gif"):
            return not (s.tamanho is not None and s.tamanho < MIN_IMAGEM)
        return False
    if esperado == "stream":
        return real == "stream" or s.mime in MIME_GENERICO | {"text/plain"} and s.ext in ("m3u8", "mpd")
    if esperado == "arquivo":
        return real not in ("pagina",)
    return real not in ("pagina",)


def _confere_manifesto(url: str, sessao, cabecalhos: dict) -> bool:
    """Um .m3u8/.mpd é mesmo uma lista de transmissão? Lê só o começo."""
    try:
        cab = dict(cabecalhos_para("manifesto", (cabecalhos or {}).get("Referer", "")), **(cabecalhos or {}))
        r, _f, _n = _abrir(sessao, "GET", url, dict(cab, Range="bytes=0-2047"), 15)
    except ErroWeb:
        return False
    try:
        inicio = next(r.iter_content(2048), b"")[:2048]
    except Exception:
        inicio = b""
    finally:
        r.close()
    return inicio.lstrip().startswith(b"#EXTM3U") or b"<MPD" in inicio


def validar_candidato(c: Candidato, referer: str = "", sessao=None, timeout: float = 12.0) -> dict:
    """{'ok', 'url', 'tipo', 'mime', 'tamanho', 'nome', 'ext', 'temporaria', 'expira', 'cabecalhos', 'motivo'}.
    Pede o endereço com o Referer da página (como o navegador faz) e confere status, tipo e tamanho reais."""
    sessao = sessao or nova_sessao()
    cab = {"Referer": referer} if referer else {}
    res = {"ok": False, "url": c.url, "tipo": c.tipo, "mime": "", "tamanho": None, "nome": "", "ext": "",
           "temporaria": False, "expira": None, "cabecalhos": cab, "motivo": "", "origem": c.origem}
    t = url_temporaria(c.url)
    if t["expirada"]:
        res["motivo"] = "link temporário já expirado"
        return res
    destino = "imagem" if c.tipo in ("imagem", "gif") else ("manifesto" if c.tipo == "stream" else "midia")
    try:
        s = sondar(c.url, cabecalhos_para(destino, referer), sessao, timeout)
    except ErroWeb as e:
        res["motivo"] = "%s (%s)" % (e.titulo, e.detalhe or e)
        res["protecao"] = e.tipo == "protecao"
        return res
    res.update(url=s.url_final, mime=s.mime, tamanho=s.tamanho, nome=s.nome, ext=s.ext, temporaria=s.temporaria,
               expira=s.expira)
    if c.tipo == "stream" or s.categoria == "stream":
        if _confere_manifesto(s.url_final, sessao, cab):
            res.update(ok=True, tipo="stream")
        else:
            res["motivo"] = "não é uma lista de transmissão válida"
        return res
    if not _confere_tipo(c.tipo, s):
        res["motivo"] = "o endereço entrega %s, não %s" % (s.mime or "tipo desconhecido", c.tipo)
        return res
    if s.tamanho == 0:
        res["motivo"] = "arquivo vazio"
        return res
    res["tipo"] = s.categoria if s.categoria in ("video", "audio", "imagem", "gif") else c.tipo
    res["ok"] = True
    return res


# ----------------------------------------------------------------------------------------------------------------------
# Componentes opcionais
# ----------------------------------------------------------------------------------------------------------------------
def _importa(nome: str) -> bool:
    try:
        __import__(nome)
        return True
    except Exception:
        return False


def versao_pacote(dist: str) -> str:
    try:
        from importlib import metadata
        return metadata.version(dist)
    except Exception:
        return ""


COMPONENTES = {
    "bs4": {"nome": "Beautiful Soup", "pip": ["beautifulsoup4"], "modulo": "bs4", "dist": "beautifulsoup4",
            "tamanho": "cerca de 1 MB", "para": "ler as páginas (vídeos, áudios, imagens e players incorporados)"},
    "gallery-dl": {"nome": "gallery-dl", "pip": ["gallery-dl"], "modulo": "gallery_dl", "dist": "gallery-dl",
                   "tamanho": "cerca de 2 MB", "para": "galerias e coleções de imagens de sites conhecidos"},
    "streamlink": {"nome": "Streamlink", "pip": ["streamlink"], "modulo": "streamlink", "dist": "streamlink",
                   "tamanho": "cerca de 15 MB", "para": "transmissões (lives) de sites conhecidos"},
    "playwright": {"nome": "Navegador do Web Hub (Playwright + Chromium)", "pip": ["playwright"],
                   "modulo": "playwright", "dist": "playwright", "tamanho": "cerca de 200 MB",
                   "para": "páginas que só mostram o vídeo depois de rodar JavaScript"},
}


def estado_componentes() -> dict:
    """{chave: {'instalado': bool, 'versao': str, ...}} — o navegador do Playwright é conferido à parte."""
    out = {}
    for k, c in COMPONENTES.items():
        ok = _importa(c["modulo"])
        out[k] = dict(c, instalado=ok, versao=versao_pacote(c["dist"]) if ok else "")
    if out["playwright"]["instalado"]:
        nav = navegador_instalado()
        out["playwright"]["navegador"] = nav
        out["playwright"]["instalado"] = nav
    return out


# ---------- Playwright ----------
def navegador_instalado() -> bool:
    """O Chromium do Playwright está baixado? (sem abrir o navegador)"""
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False
    try:
        with sync_playwright() as p:
            return Path(p.chromium.executable_path).is_file()
    except Exception:
        return False


_MIME_MIDIA_NAV = ("video/", "audio/")
_DESAFIOS = ("just a moment", "attention required", "verify you are human", "captcha", "are you a robot",
             "checking your browser", "ddos-guard", "access denied")


def farejar_com_navegador(url: str, timeout_s: float = 30.0, deve_parar=None) -> dict:
    """Abre a página pública num Chromium sem janela, espera ela carregar normalmente e anota as respostas de mídia
    (vídeo, áudio, listas HLS/DASH) que a PRÓPRIA página pediu, além dos <video>/<audio> e do HTML final.
    Nada é clicado; verificações anti-robô e CAPTCHA não são resolvidas (a página volta com desafio=True).
    {'url_final', 'titulo', 'html', 'midias': [{'url','mime','tamanho','status','tipo'}], 'desafio': bool}"""
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        raise ErroWeb("dependencia", "O navegador do Web Hub (Playwright) não está instalado.", str(e), "playwright")
    exigir_publico(url)
    midias, vistos = [], set()
    res = {"url_final": url, "titulo": "", "html": "", "midias": midias, "desafio": False}

    def resposta(r) -> None:
        try:
            u = r.url
            if u in vistos or not u.startswith(("http://", "https://")):
                return
            ct = (r.headers.get("content-type") or "").split(";")[0].strip().lower()
            tipo = ""
            if ct.startswith(_MIME_MIDIA_NAV) or ct in MIME_STREAM:
                tipo = "stream" if ct in MIME_STREAM else ("video" if ct.startswith("video/") else "audio")
            elif ext_do_caminho(u) in ("m3u8", "mpd"):
                tipo = "stream"
            elif ext_do_caminho(u) in CAT_EXT["video"] | CAT_EXT["audio"] and r.request.resource_type == "media":
                tipo = categoria(ext_do_caminho(u))
            if not tipo:
                return
            vistos.add(u)
            tam = r.headers.get("content-length")
            midias.append({"url": u, "mime": ct, "tamanho": int(tam) if tam and tam.isdigit() else None,
                           "status": r.status, "tipo": tipo})
        except Exception:
            pass

    def bloquear_privados(rota) -> None:
        # a página também não pode levar o navegador à rede local
        try:
            if endereco_publico(rota.request.url):
                rota.abort()
            else:
                rota.continue_()
        except Exception:
            try:
                rota.continue_()
            except Exception:
                pass
    try:
        with sync_playwright() as p:
            nav = p.chromium.launch(headless=True)
            try:
                ctx = nav.new_context(user_agent=UA, locale="pt-BR", accept_downloads=False)
                pagina = ctx.new_page()
                if not os.environ.get("YPELE_UNIVERSAL_PERMITIR_LOCAL"):
                    pagina.route("**/*", bloquear_privados)
                pagina.on("response", resposta)
                try:
                    pagina.goto(url, wait_until="domcontentloaded", timeout=timeout_s * 1000)
                except Exception as e:
                    raise ErroWeb("timeout" if "Timeout" in type(e).__name__ else "conexao",
                                  "O navegador não conseguiu abrir a página (%s)." % url_para_log(url), str(e)[:300])
                fim = time.time() + min(12.0, timeout_s)
                ultimo = -1
                while time.time() < fim:                     # espera o player iniciar e a rede sossegar
                    if deve_parar and deve_parar():
                        raise Cancelado()
                    pagina.wait_for_timeout(700)
                    if len(midias) == ultimo and midias:
                        break
                    ultimo = len(midias)
                try:
                    srcs = pagina.eval_on_selector_all(
                        "video, audio, video source, audio source",
                        "els => els.map(e => [e.tagName.toLowerCase(), e.currentSrc || e.src || '', "
                        "e.getAttribute('type') || ''])")
                except Exception:
                    srcs = []
                for tag, src, tp in srcs:
                    if src and src.startswith(("http://", "https://")) and src not in vistos:
                        vistos.add(src)
                        midias.append({"url": src, "mime": tp, "tamanho": None, "status": 0,
                                       "tipo": _tipo_por(src, tp, "audio" if "audio" in tag else "video")
                                       or "video"})
                res["titulo"] = pagina.title() or ""
                res["url_final"] = pagina.url
                res["html"] = pagina.content()[:LIMITE_HTML]
                baixo = (res["titulo"] + " " + res["html"][:4000]).lower()
                res["desafio"] = any(d in baixo for d in _DESAFIOS) and not midias
            finally:
                nav.close()
    except ErroWeb:
        raise
    except Cancelado:
        raise
    except Exception as e:
        raise ErroWeb("dependencia", "O navegador do Web Hub falhou ao abrir a página.", str(e)[:400], "playwright")
    return res


def _erro_de_mecanismo(nome: str, padrao: str, detalhe: str) -> ErroWeb:
    """Erro de um mecanismo externo pela saída dele: HTTP 404/403/429/5xx, login, sem conexão; senão `padrao`."""
    t = (detalhe or "").lower()
    regras = (
        (r"\b404\b|not found", "inexistente", "Página ou galeria não encontrada (HTTP 404)."),
        (r"\b(401|403)\b|forbidden|unauthorized", "negado", "O site recusou o acesso: o conteúdo pode exigir login "
                                                           "ou ser privado; o yPeléTools não contorna isso."),
        (r"login|log in|sign in|authenticat|cookies", "negado", "O conteúdo exige login. O yPeléTools não contorna "
                                                                "isso."),
        (r"\b429\b|too many requests|rate.?limit", "limite", "O site limitou os pedidos (HTTP 429). Espere alguns "
                                                             "minutos."),
        (r"\b5\d\d\b.*(error|server)|server error", "servidor", "O servidor do site falhou. Tente mais tarde."),
        (r"timed? ?out", "timeout", "O site demorou demais para responder."),
        (r"connection|resolve|name or service|getaddrinfo", "conexao", "Não consegui conectar ao site."),
        (r"no plugin|unsupported|no suitable extractor", "extrator", "%s não reconhece este site." % nome),
        (r"no playable streams|offline", "sem_midia", "A transmissão não está no ar agora."),
    )
    for rx, tipo, msg in regras:
        if re.search(rx, t):
            return ErroWeb(tipo, msg, "%s: %s" % (nome, detalhe))
    return ErroWeb("extrator" if "ler" in padrao else "download", padrao, "%s: %s" % (nome, detalhe))


# ---------- gallery-dl ----------
_HOSTS_GALERIA = ("imgur.com", "flickr.com", "deviantart.com", "artstation.com", "pixiv.net", "danbooru.donmai.us",
                  "gelbooru.com", "behance.net", "tumblr.com", "reddit.com", "bsky.app", "mastodon.social",
                  "e621.net", "kemono.su", "catbox.moe", "imgbox.com", "postimg.cc", "imagebam.com", "vsco.co",
                  "500px.com", "unsplash.com", "wikiart.org", "commons.wikimedia.org")


def host_de_galeria(url: str) -> bool:
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return any(host == h or host.endswith("." + h) for h in _HOSTS_GALERIA)


def gallerydl_suporta(url: str):
    """True/False se o gallery-dl tem um extrator ESPECÍFICO para o endereço; None se ele não está instalado."""
    try:
        from gallery_dl import extractor
    except Exception:
        return None
    try:
        ex = extractor.find(url)
    except Exception:
        return False
    if ex is None:
        return False
    return getattr(ex, "category", "") not in ("directlink", "generic", "noop", "recursive")


def _python_mecanismo(python: str) -> list:
    return [python or sys.executable, "-I"]


def gallerydl_listar(url: str, python: str, timeout: float = 120.0) -> dict:
    """Lista a galeria sem baixar (gallery-dl --get-urls). {'total', 'urls'}."""
    cmd = _python_mecanismo(python) + ["-m", "gallery_dl", "--get-urls", "--no-colors", url]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout, stdin=subprocess.DEVNULL, **_NOWIN)
    except subprocess.TimeoutExpired:
        raise ErroWeb("timeout", "O gallery-dl demorou demais para listar a galeria.")
    except OSError as e:
        raise ErroWeb("dependencia", "Não consegui iniciar o gallery-dl.", str(e), "gallery-dl")
    urls = [ln.strip().lstrip("| ") for ln in r.stdout.splitlines()
            if ln.strip().startswith(("http://", "https://", "| http"))]
    if r.returncode != 0 and not urls:
        detalhe = ((r.stderr or r.stdout).strip().splitlines()[-1:] or [""])[0][:300]
        raise _erro_de_mecanismo("gallery-dl", "O gallery-dl não conseguiu ler a galeria.", detalhe)
    return {"total": len(urls), "urls": urls}


def gallerydl_baixar(url: str, pasta: Path, python: str, ao_prog, deve_parar, total: int = None,
                     info: dict = None) -> Path:
    """Baixa a galeria para `pasta` (gallery-dl -D). Progresso = arquivos prontos / total da listagem. `info` recebe
    {'baixados', 'falhas', 'motivo'}: o site pode recusar parte dos arquivos (ex.: HTTP 429 do Wikimedia), e quem
    chamou avisa "x de y" em vez de dar a galeria como completa."""
    info = info if info is not None else {}
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    cmd = _python_mecanismo(python) + ["-m", "gallery_dl", "-D", str(pasta), "--no-colors", "--no-part", url]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL, **_NOWIN)
    except OSError as e:
        raise ErroWeb("dependencia", "Não consegui iniciar o gallery-dl.", str(e), "gallery-dl")
    feitos, ultima, falhas, motivos = 0, "", 0, []
    fila_linhas = []
    leitor = threading.Thread(target=lambda: [fila_linhas.append(ln) for ln in proc.stdout], daemon=True)
    leitor.start()
    t0 = time.time()
    while proc.poll() is None or fila_linhas:
        motivo = deve_parar()
        if motivo:
            proc.kill()
            proc.wait()
            raise Cancelado(motivo)
        while fila_linhas:
            ln = fila_linhas.pop(0).strip()
            if not ln:
                continue
            ultima = ln
            if ln.startswith(("#", "[")):           # "# arquivo" = já existia; "[...]" = aviso/erro do gallery-dl
                if ln.startswith("#"):
                    feitos += 1
                elif "][error]" in ln and "failed to download" in ln.lower():
                    falhas += 1
                elif "][warning]" in ln or "][error]" in ln:
                    motivos.append(re.sub(r"https?://\S+", "", ln)[:160])
                continue
            feitos += 1
            dec = time.time() - t0
            ao_prog({"pct": min(99.0, feitos / total * 100) if total else None,
                     "vel": "%d arquivo(s)" % feitos, "eta": "", "tam": None,
                     "baixado": None, "ext": "", "segundos": dec})
        time.sleep(0.15)
    info.update(baixados=feitos, falhas=falhas, motivo=(motivos[-1] if motivos else ""))
    if proc.returncode not in (0, None) and feitos == 0:
        raise _erro_de_mecanismo("gallery-dl", "O gallery-dl não baixou nenhum arquivo da galeria.",
                                 (motivos[-1] if motivos else ultima)[:300])
    if not any(p.is_file() for p in pasta.rglob("*")):
        raise ErroWeb("download", "A galeria não tinha arquivos para baixar.", ultima[:300])
    return pasta


# ---------- Streamlink ----------
def streamlink_suporta(url: str):
    """True/False se o Streamlink tem um plugin para o endereço; None se ele não está instalado."""
    try:
        import streamlink
    except Exception:
        return None
    try:
        streamlink.Streamlink().resolve_url(url)
        return True
    except Exception:
        return False


def streamlink_baixar(url: str, destino: Path, python: str, ao_prog, deve_parar) -> Path:
    """Grava a transmissão (a melhor qualidade que o Streamlink oferece) em `destino`. Transmissão ao vivo não tem fim
    conhecido: o progresso mostra o tamanho gravado e a velocidade; cancelar para e descarta."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    cmd = _python_mecanismo(python) + ["-m", "streamlink", "--force", "--output", str(destino), url, "best"]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL, **_NOWIN)
    except OSError as e:
        raise ErroWeb("dependencia", "Não consegui iniciar o Streamlink.", str(e), "streamlink")
    saida = []
    threading.Thread(target=lambda: [saida.append(ln) for ln in proc.stdout], daemon=True).start()
    t0, antes, t_antes = time.time(), 0, time.time()
    while proc.poll() is None:
        motivo = deve_parar()
        if motivo:
            proc.kill()
            proc.wait()
            raise Cancelado(motivo)
        time.sleep(0.5)
        try:
            feito = destino.stat().st_size
        except OSError:
            feito = 0
        agora = time.time()
        vel = (feito - antes) / max(0.001, agora - t_antes)
        antes, t_antes = feito, agora
        ao_prog({"pct": None, "vel": ("%.1f MB/s" % (vel / 1e6)) if vel > 0 else "", "eta": "", "tam": None,
                 "baixado": feito, "ext": destino.suffix.lstrip("."), "segundos": agora - t0})
    texto = "".join(saida[-20:])
    if proc.returncode != 0 or not destino.is_file() or destino.stat().st_size == 0:
        ultima = [ln for ln in texto.splitlines() if ln.strip()][-1:] or [""]
        raise _erro_de_mecanismo("Streamlink", "O Streamlink não conseguiu gravar a transmissão.", ultima[0][:300])
    return destino


# ----------------------------------------------------------------------------------------------------------------------
# Download HTTP (requests): progresso real, continuação, endereços públicos, link expirado
# ----------------------------------------------------------------------------------------------------------------------
def _fmt_tam(n: float) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return ("%.0f %s" if u == "B" else "%.1f %s") % (n, u)
        n /= 1024.0
    return "%.1f GB" % n


def _fmt_tempo(s: float) -> str:
    s = int(max(0, s))
    return "%d:%02d:%02d" % (s // 3600, s % 3600 // 60, s % 60) if s >= 3600 else "%d:%02d" % (s // 60, s % 60)


def baixar_http(url: str, destino: Path, cabecalhos: dict, ao_prog, deve_parar, sessao=None,
                timeout: float = 30.0) -> Path:
    """Baixa `url` para `destino` (.part enquanto baixa). Continua de onde parou se o servidor aceitar Range. Link
    temporário vencido ou recusado (403/410) vira ErroWeb('expirado') para quem chamou analisar a página de novo."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    t = url_temporaria(url)
    if t["expirada"]:
        raise ErroWeb("expirado", "O link temporário da mídia já expirou.", "prazo %s" % t["expira"])
    sessao = sessao or nova_sessao()
    parcial = destino.with_name(destino.name + ".part")
    ja = parcial.stat().st_size if parcial.exists() else 0
    cab = dict(cabecalhos_para("midia", (cabecalhos or {}).get("Referer", "")), **(cabecalhos or {}))
    if ja:
        cab["Range"] = "bytes=%d-" % ja
    r, final, _n = _abrir(sessao, "GET", url, cab, timeout)
    try:
        if r.status_code == 416 and ja:
            os.replace(parcial, destino)
            return destino
        if r.status_code >= 400:
            e = erro_http(r.status_code, final)
            if t["temporaria"] and r.status_code in (401, 403, 404, 410):
                raise ErroWeb("expirado", "O link temporário da mídia não vale mais (HTTP %d)." % r.status_code,
                              e.detalhe)
            raise e
        mime = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if mime in ("text/html", "application/xhtml+xml"):
            raise ErroWeb("formato", "O endereço da mídia devolveu uma página, não o arquivo (o link pode ter "
                                     "expirado ou exigir a página aberta).", "Content-Type text/html")
        continua = bool(ja) and r.status_code == 206
        if not continua:
            ja = 0
        total = r.headers.get("Content-Length")
        total = (int(total) + ja) if (total and total.isdigit()) else None
        feito, t0, ult = ja, time.time(), 0.0
        try:
            with open(parcial, "ab" if continua else "wb") as f:
                for bloco in r.iter_content(256 * 1024):
                    motivo = deve_parar()
                    if motivo:
                        raise Cancelado(motivo)
                    if not bloco:
                        continue
                    if feito == 0 and mime in MIME_FRACO and \
                            identificar_conteudo(bloco[:BYTES_SONDA])[0] == "text/html":
                        raise ErroWeb("formato", "O endereço da mídia devolveu uma página, não o arquivo (o link pode "
                                                 "ter expirado ou exigir a página aberta).",
                                      "Content-Type %s com conteúdo HTML" % (mime or "ausente"))
                    f.write(bloco)
                    feito += len(bloco)
                    agora = time.time()
                    if agora - ult > 0.25:
                        ult = agora
                        vel = (feito - ja) / max(0.001, agora - t0)
                        ao_prog({"pct": min(99.0, feito / total * 100) if total else None,
                                 "vel": "%s/s" % _fmt_tam(vel) if vel else "",
                                 "eta": _fmt_tempo((total - feito) / vel) if (total and vel > 0) else "",
                                 "tam": total, "baixado": feito, "ext": destino.suffix.lstrip(".")})
        except OSError as e:
            raise ErroWeb("salvar", "Não consegui gravar o arquivo no disco: %s." % (e.strerror or e), str(e))
        except Exception as e:
            if isinstance(e, (Cancelado, ErroWeb)):
                raise
            raise _erro_de_requisicao(e, final)
    finally:
        r.close()
    if total is not None and feito < total:
        raise ErroWeb("download", "O download terminou incompleto (%s de %s)." % (_fmt_tam(feito), _fmt_tam(total)))
    os.replace(parcial, destino)
    ao_prog({"pct": 99.0, "vel": "", "eta": "", "tam": total or feito, "baixado": feito,
             "ext": destino.suffix.lstrip(".")})
    return destino


# ----------------------------------------------------------------------------------------------------------------------
# Plano: o resultado da análise, entregue à fila (quem decide é o CoreManager de ypele_webhub_provedores.py)
# ----------------------------------------------------------------------------------------------------------------------
@dataclass
class Plano:
    mecanismo: str                      # direto | ytdlp | gallerydl | streamlink | galeria
    alvo: str                           # o endereço que o mecanismo vai usar (o recurso, ou a página para o yt-dlp)
    pagina: str = ""                    # a página que o usuário colou (para analisar de novo quando expirar)
    titulo: str = ""
    site: str = ""
    categoria: str = "arquivo"
    ext: str = ""
    tamanho: Optional[int] = None
    miniatura: str = ""
    duracao: Optional[float] = None
    cabecalhos: dict = field(default_factory=dict)
    temporaria: bool = False
    itens: list = field(default_factory=list)      # galeria: endereços das imagens validadas
    entradas: list = field(default_factory=list)   # playlist do yt-dlp: [{'url', 'titulo', 'duracao'}]
    info: dict = field(default_factory=dict)       # o que o yt-dlp devolveu (sem os formatos)
    tem_video: bool = False
    tem_audio: bool = False
    avisos: list = field(default_factory=list)
    tentativas: list = field(default_factory=list)  # [(mecanismo, resultado)] para o diagnóstico
    sessao: object = None                           # só em memória (nunca salva): para baixar logo em seguida
    provedor: str = ""                              # (4.0.0) o provedor que resolveu o link (diagnóstico e log)


def _primeira_linha(t: str) -> str:
    for ln in str(t or "").splitlines():
        if ln.strip():
            return ln.strip()
    return ""


# ----------------------------------------------------------------------------------------------------------------------
# Galeria achada na página: baixa as imagens confirmadas para uma pasta
# ----------------------------------------------------------------------------------------------------------------------
def baixar_galeria(urls: list, pasta: Path, cabecalhos: dict, ao_prog, deve_parar, sessao=None,
                   info: dict = None) -> Path:
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    sessao = sessao or nova_sessao()
    feitos, falhas = 0, []
    for i, u in enumerate(urls, 1):
        if deve_parar():
            raise Cancelado(deve_parar())
        nome = posixpath.basename(urllib.parse.unquote(urllib.parse.urlsplit(u).path)) or "imagem_%03d" % i
        nome = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", nome)[:120]
        destino = pasta / ("%03d_%s" % (i, nome))
        try:
            baixar_http(u, destino, cabecalhos, lambda d: None, deve_parar, sessao)
            feitos += 1
        except Cancelado:
            raise
        except ErroWeb as e:
            falhas.append("%s: %s" % (nome, e))
        ao_prog({"pct": min(99.0, i / len(urls) * 100), "vel": "%d de %d" % (i, len(urls)), "eta": "",
                 "tam": None, "baixado": None, "ext": ""})
    if info is not None:
        info.update(baixados=feitos, falhas=len(falhas), motivo=falhas[-1] if falhas else "")
    if not feitos:
        raise ErroWeb("download", "Nenhuma imagem da galeria pôde ser baixada.", "; ".join(falhas[:3]))
    return pasta


# ----------------------------------------------------------------------------------------------------------------------
# Compatibilidade: `Roteador` (3.9.0/3.9.1) é o CoreManager da arquitetura de provedores (4.0.0)
# ----------------------------------------------------------------------------------------------------------------------
def carregar_provedores():
    """O módulo ypele_webhub_provedores (mesma pasta deste arquivo), carregado uma vez. O app roda com `python -I`, que
    não põe a pasta do script no sys.path; por isso a carga é pelo caminho do arquivo."""
    import importlib.util
    nome = "ypele_webhub_provedores"
    arq = Path(__file__).resolve().parent / (nome + ".py")
    mod = sys.modules.get(nome)
    if mod is not None and Path(getattr(mod, "__file__", "") or "").resolve() == arq:
        return mod
    if not arq.is_file():
        raise ImportError("ypele_webhub_provedores.py não encontrado ao lado de ypele_webhub.py")
    spec = importlib.util.spec_from_file_location(nome, arq)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[nome] = mod
    try:
        spec.loader.exec_module(mod)
    except Exception:
        sys.modules.pop(nome, None)
        raise
    return mod


def __getattr__(nome: str):
    """`ypele_webhub.Roteador` continua funcionando (é o CoreManager)."""
    if nome == "Roteador":
        return carregar_provedores().CoreManager
    raise AttributeError("module %r has no attribute %r" % (__name__, nome))
