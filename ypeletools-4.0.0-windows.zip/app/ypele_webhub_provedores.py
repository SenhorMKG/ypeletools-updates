"""yPeléTools — Web Hub: arquitetura baseada em provedores (Beta 4.0.0).

Um link colado no Web Hub passa por uma cadeia de PROVEDORES, cada um especialista num jeito de achar a mídia. O
CoreManager (orquestrador) chama os provedores em ordem de prioridade; o primeiro que entregar um plano vence. Quando um
provedor não acha nada ou falha de um jeito recuperável (rede, extrator), o próximo tenta (fallback). Uma falha
TERMINAL encerra a análise na hora: proteção do site, DRM, login, conteúdo privado ou endereço proibido não se contornam
trocando de mecanismo.

    prioridade  provedor               o que faz
    10          YTDLPProvider          sites que o yt-dlp conhece por nome (extrator específico): resolve o endereço
                                       final da mídia que a página esconde atrás do player
    20          GalleryDLProvider      galerias e coleções de imagens de sites que o gallery-dl conhece
    30          GenericHTMLProvider    o próprio link é um arquivo? (Content-Type e primeiros bytes, nunca a extensão);
                                       senão, busca profunda no HTML: <video>/<audio>/<source>, Open Graph, JSON-LD,
                                       scripts e JSON embutido, players incorporados, links para arquivos, galerias
    40          YTDLPGenericProvider   o extrator genérico do yt-dlp (players que ele reconhece dentro da página)
    50          StreamlinkProvider     transmissões ao vivo de sites que o Streamlink conhece
    60          DynamicPageProvider    a página só mostra a mídia depois de rodar JavaScript: Chromium sem janela
                                       (Playwright) observa as respostas de mídia que a PRÓPRIA página carrega

Contrato de um provedor (BaseProvider):
    can_handle(url, ctx)    -> bool        barato: decide se vale tentar (sem baixar nada pesado)
    extract_media(url, ctx) -> Plano|None  resolve a mídia (None = não achou; o próximo provedor tenta)
    get_metadata(url, ctx, plano) -> Metadados   título, miniatura, site, duração e descrição para a fila

`ctx` (ContextoAnalise) é compartilhado pela cadeia: uma sessão HTTP só, a sondagem do link, o HTML da página e a
análise dele são feitos UMA vez e reaproveitados por todos os provedores. Para criar um provedor novo: subclasse de
BaseProvider com `nome` e `prioridade`, e CoreManager.registrar_provedor(MeuProvider()).

A análise roda na thread de análise da fila (nunca na da interface). Exceções inesperadas de um provedor viram uma
linha no diagnóstico e o próximo provedor tenta: um provedor com defeito não derruba a análise nem a fila.
Nada aqui contorna login, paywall, DRM ou CAPTCHA, e endereços da rede local são recusados (também depois de
redirecionar).
"""
from __future__ import annotations

import abc
import concurrent.futures
import importlib.util
import posixpath
import sys
import urllib.parse
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

VERSAO_ARQUITETURA = 1

LogFn = Callable[[str, str], None]
PararFn = Callable[[], str]
ExtratorFn = Callable[[str], str]
InfoFn = Callable[[str, str, bool], dict]


def _carregar_webhub():
    """O ypele_webhub.py desta mesma pasta (o app roda com `python -I`, sem a pasta do script no sys.path)."""
    nome = "ypele_webhub"
    arq = Path(__file__).resolve().parent / (nome + ".py")
    mod = sys.modules.get(nome)
    if mod is not None and Path(getattr(mod, "__file__", "") or "").resolve() == arq:
        return mod
    spec = importlib.util.spec_from_file_location(nome, arq)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[nome] = mod
    spec.loader.exec_module(mod)
    return mod


if TYPE_CHECKING:                       # para o verificador de tipos (mypy) enxergar Plano, Sonda, ErroWeb...
    import ypele_webhub as W
else:
    W = _carregar_webhub()

# Falhas que encerram a análise: tentar outro provedor seria insistir contra uma recusa do site (ou contornar uma
# proteção). As demais (rede, servidor, extrator) deixam o próximo provedor tentar.
TIPOS_TERMINAIS = frozenset({"url_invalida", "local", "redirecionamento", "inexistente", "negado", "protecao", "drm",
                             "limite", "varios_arquivos", "dependencia", "cancelado"})
# Se nenhum provedor achar nada, a falha recuperável mais informativa vira a mensagem final (em vez de "sem mídia")
_ORDEM_ERRO_FINAL = ("servidor", "timeout", "conexao", "extrator", "formato", "download", "sem_midia")
MAX_VALIDACOES_PARALELAS = 6
MAX_CANDIDATOS_MIDIA = 20


def site_de(url: str) -> str:
    h = (urllib.parse.urlsplit(url).hostname or "").lower()
    return h[4:] if h.startswith("www.") else h


def primeira_linha(texto: str) -> str:
    for ln in str(texto or "").splitlines():
        if ln.strip():
            return ln.strip()
    return ""


def nome_do_endereco(url: str) -> str:
    return posixpath.basename(urllib.parse.unquote(urllib.parse.urlsplit(url).path))


# ======================================================================================================================
# Metadados e contexto compartilhado
# ======================================================================================================================
@dataclass
class Metadados:
    """O que a fila mostra do item: título, miniatura, site, duração (segundos) e uma descrição curta."""
    titulo: str = ""
    miniatura: str = ""
    site: str = ""
    duracao: float | None = None
    descricao: str = ""


_NADA = object()


class ContextoAnalise:
    """Estado de UMA análise, compartilhado pelos provedores: sessão HTTP, sondagem do link, página e análise do HTML
    (cada uma feita uma vez, sob demanda), tentativas (diagnóstico), avisos e erros recuperáveis."""

    def __init__(self, url: str, playlist: bool, ytdlp_extrator: ExtratorFn, ytdlp_info: InfoFn, python: str,
                 log: LogFn, deve_parar: PararFn, usar_navegador: Callable[[], bool], sessao=None) -> None:
        self.url = url
        self.playlist = bool(playlist)
        self.site = site_de(url)
        self.python = python or sys.executable
        self.log = log
        self.deve_parar = deve_parar
        self.usar_navegador = usar_navegador
        self.sessao = sessao if sessao is not None else W.nova_sessao()
        self.tentativas: list[tuple[str, str]] = []
        self.avisos: list[str] = []
        self.erros: list[W.ErroWeb] = []
        self.extras: dict[str, Any] = {}
        self._ytdlp_extrator = ytdlp_extrator
        self._ytdlp_info = ytdlp_info
        self._sonda: Any = _NADA
        self._erro_sonda: W.ErroWeb | None = None
        self._pagina: dict | None = None
        self._analise: dict | None = None
        self._extratores: dict[str, str] = {}

    # -- controle
    def parar(self) -> None:
        motivo = self.deve_parar()
        if motivo:
            raise W.Cancelado(motivo)

    def registrar(self, origem: str, resultado: str) -> None:
        self.tentativas.append((origem, resultado))

    def detalhe(self) -> str:
        return "; ".join("%s: %s" % t for t in self.tentativas)

    # -- sondagem do link (o próprio link é um arquivo?)
    def sonda(self) -> W.Sonda | None:
        """A sondagem do link colado (uma vez). None quando o servidor recusou o HEAD/1º byte com 404/403: alguns sites
        só respondem direito ao GET de navegador da página, que é conferido depois."""
        if self._erro_sonda is not None:
            raise self._erro_sonda
        if self._sonda is _NADA:
            try:
                s = W.sondar(self.url, sessao=self.sessao)
            except W.ErroWeb as e:
                if e.tipo in ("inexistente", "negado"):
                    self.registrar("http", "%s no HEAD/1º byte" % (e.detalhe or e))
                    self._sonda = None
                    return None
                self._erro_sonda = e
                raise
            extra = ", %d redirecionamento(s)" % s.redirecionamentos if s.redirecionamentos else ""
            if s.pela_assinatura:
                extra += ", tipo pelos primeiros bytes (servidor disse %s)" % (s.mime_declarado or "nada")
            self.registrar("http (%s)" % W.motor_http().split(" ")[0],
                           "HTTP %d, %s%s" % (s.status, s.mime or "sem tipo", extra))
            self._sonda = s
        return self._sonda

    def e_pagina(self) -> bool:
        """O link é uma página (ou o servidor não deixou saber)? False = é um arquivo/transmissão direto."""
        s = self.sonda()
        return s is None or s.e_pagina

    # -- página e análise do HTML
    def pagina(self) -> dict:
        if self._pagina is None:
            pag = W.ler_pagina(self.url, sessao=self.sessao)
            self.registrar("página", "HTTP %d, %d KB de HTML" % (pag["status"], len(pag["html"]) // 1024))
            self._pagina = pag
        return self._pagina

    def pagina_se_lida(self) -> dict | None:
        return self._pagina

    def analise(self) -> dict:
        if self._analise is None:
            pag = self.pagina()
            self._analise = W.analisar_html(pag["html"], pag["url_final"])
        return self._analise

    def analise_se_lida(self) -> dict | None:
        return self._analise

    # -- yt-dlp (callbacks do app)
    def extrator(self, url: str | None = None) -> str:
        """Nome do extrator ESPECÍFICO do yt-dlp para o endereço ('' = só o genérico). Uma consulta por endereço."""
        url = url or self.url
        if url not in self._extratores:
            try:
                self._extratores[url] = self._ytdlp_extrator(url) or ""
            except Exception:
                self._extratores[url] = ""
        return self._extratores[url]

    def ytdlp(self, alvo: str, referer: str, playlist: bool) -> dict:
        return self._ytdlp_info(alvo, referer, playlist)


# ======================================================================================================================
# Base dos provedores
# ======================================================================================================================
class BaseProvider(abc.ABC):
    """Um jeito de achar a mídia de um link. Subclasses definem `nome`, `prioridade` (menor = antes) e os dois métodos
    abstratos. Para "não achei", extract_media devolve None; para "não adianta continuar" (proteção, DRM, login...),
    levanta W.ErroWeb de um tipo terminal (TIPOS_TERMINAIS)."""

    nome: str = "BaseProvider"
    prioridade: int = 100
    descricao: str = ""

    @abc.abstractmethod
    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        """Vale tentar este provedor para `url`? Deve ser barato (o contexto guarda o que já foi consultado)."""

    @abc.abstractmethod
    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        """Resolve a mídia: um Plano (mecanismo, endereço final, tipo, tamanho...) ou None."""

    def get_metadata(self, url: str, ctx: ContextoAnalise, plano: W.Plano) -> Metadados:
        """Título, miniatura e site para a fila. Padrão: o que o plano trouxe e, se a página foi lida, o Open Graph /
        <title> / pôster do <video> dela."""
        an = ctx.analise_se_lida() or {}
        return Metadados(titulo=plano.titulo or an.get("titulo", ""),
                         miniatura=plano.miniatura or an.get("miniatura", ""),
                         site=plano.site or an.get("site", "") or ctx.site, duracao=plano.duracao,
                         descricao=an.get("descricao", ""))

    def __repr__(self) -> str:
        return "<%s prioridade=%d>" % (self.nome, self.prioridade)


# ======================================================================================================================
# yt-dlp: plano a partir do que ele devolve
# ======================================================================================================================
def erro_ytdlp_final(texto: str) -> W.ErroWeb | None:
    """Erros do yt-dlp que encerram a análise (outro mecanismo seria contornar a proteção)."""
    t = (texto or "").lower()
    if "drm" in t:
        return W.ErroWeb("drm", "Este conteúdo só é entregue com proteção DRM. O yPeléTools não contorna DRM.",
                         texto[:300])
    if any(x in t for x in ("sign in to confirm", "login required", "requires login", "private video",
                            "this video is private", "members-only", "premium", "subscription")):
        return W.ErroWeb("negado", "O conteúdo exige login, assinatura ou é privado. O yPeléTools não contorna isso.",
                         texto[:300])
    if any(x in t for x in ("geo restrict", "not available in your country", "blocked it in your country")):
        return W.ErroWeb("negado", "O conteúdo não está disponível na sua região.", texto[:300])
    return None


def plano_do_ytdlp(alvo: str, pagina: str, info: dict, referer: str = "") -> W.Plano:
    """Plano 'ytdlp' a partir do dicionário do yt-dlp (item único ou lista)."""
    if info.get("entries") is not None:
        ents = [e for e in (info.get("entries") or []) if e]
        entradas = [{"url": e.get("webpage_url") or e.get("url") or "", "titulo": e.get("title") or "",
                     "duracao": e.get("duration")} for e in ents]
        primeira = ents[0] if ents else {}
        p = W.Plano("ytdlp", alvo, pagina, titulo=info.get("title") or primeira.get("title") or "",
                    site=site_de(pagina), categoria="video", entradas=entradas,
                    miniatura=info.get("thumbnail") or primeira.get("thumbnail") or "",
                    cabecalhos={"Referer": referer} if referer else {}, info={"playlist": True})
        p.tem_video = p.tem_audio = True
        return p
    fmts = info.get("formats") or []
    tem_v = any((f.get("vcodec") or "none") != "none" for f in fmts)
    tem_a = any((f.get("acodec") or "none") != "none" for f in fmts)
    desconhecidos = [f for f in (fmts or [info]) if f.get("vcodec") is None and f.get("acodec") is None]
    ext = str(info.get("ext") or "").lower()
    cat = W.categoria(ext)
    avisos = []
    if desconhecidos and any(W.categoria(str(f.get("ext") or ext)) == "video" for f in desconhecidos):
        if not (tem_v and tem_a):
            avisos.append("O site não informou os codecs: as faixas de áudio e vídeo são conferidas no download.")
        tem_v = tem_a = True
    if cat not in ("video", "audio", "imagem", "gif"):
        cat = "video" if tem_v else ("audio" if tem_a else "video")
    tam = info.get("filesize") or info.get("filesize_approx")
    if not tam and fmts:
        tam = fmts[-1].get("filesize") or fmts[-1].get("filesize_approx")
    if tem_v and not tem_a:
        avisos.append("Esta mídia não tem faixa de áudio.")
    if info.get("is_live"):
        avisos.append("É uma transmissão ao vivo: o download só termina quando ela acabar.")
    p = W.Plano("ytdlp", info.get("webpage_url") or alvo, pagina, titulo=info.get("title") or "",
                site=info.get("webpage_url_domain") or site_de(pagina), categoria=cat, ext=ext, tamanho=tam,
                miniatura=info.get("thumbnail") or "", duracao=info.get("duration"),
                cabecalhos={"Referer": referer} if referer else {}, avisos=avisos,
                info={"extrator": info.get("extractor_key") or "", "ao_vivo": bool(info.get("is_live")),
                      "lista_total": info.get("_lista_total")})
    p.tem_video, p.tem_audio = bool(tem_v), bool(tem_a)
    return p


def midia_do_ytdlp_invalida(info: dict, referer: str, sessao=None) -> str:
    """O extrator genérico do yt-dlp aceita um <video src="x.mp4"> pelo nome. O endereço é conferido como qualquer
    candidato da página: '' se é mídia de verdade; senão o motivo."""
    fmts = [f for f in (info.get("formats") or [info]) if f.get("url")]
    diretos = [f for f in fmts if str(f.get("protocol") or "https").startswith("http")
               and not str(f.get("protocol") or "").startswith("m3u8")]
    if not diretos:
        return ""                           # transmissão (HLS/DASH): o yt-dlp lê a lista, que já é conferida por ele
    f = diretos[-1]
    v = W.validar_candidato(W.Candidato(f["url"], "yt-dlp", W._tipo_por(f["url"], "", "video") or "video"), referer,
                            sessao)
    return "" if v["ok"] else "o endereço não é uma mídia (%s)" % v["motivo"]


def tentar_ytdlp(ctx: ContextoAnalise, alvo: str, pagina: str, referer: str, playlist: bool, rotulo: str,
                 validar: bool = False) -> W.Plano | None:
    """Pede ao yt-dlp (callback do app) o que `alvo` entrega. None se ele não achar; ErroWeb terminal para DRM, login,
    conteúdo privado ou bloqueio de região."""
    try:
        info = ctx.ytdlp(alvo, referer, playlist)
    except W.Cancelado:
        raise
    except Exception as e:
        texto = str(e)
        final = erro_ytdlp_final(texto)
        ctx.registrar(rotulo, "falhou: " + primeira_linha(texto)[:200])
        if final is not None:
            final.detalhe = ctx.detalhe()
            raise final from None
        return None
    if not info:
        ctx.registrar(rotulo, "nada encontrado")
        return None
    if validar and info.get("entries") is None:
        motivo = midia_do_ytdlp_invalida(info, referer or pagina, ctx.sessao)
        if motivo:
            ctx.registrar(rotulo, "achou %s, mas %s" % (info.get("extractor_key") or "um endereço", motivo))
            return None
    ctx.registrar(rotulo, "ok (%s)" % (info.get("extractor_key") or "yt-dlp"))
    return plano_do_ytdlp(alvo, pagina, info, referer)


# ======================================================================================================================
# Escolha entre os candidatos de uma página (usada pelo GenericHTMLProvider e pelo DynamicPageProvider)
# ======================================================================================================================
def validar_em_ordem(ctx: ContextoAnalise, candidatos: list[W.Candidato], base: str) -> Iterable[dict]:
    """Valida os candidatos EM PARALELO (até MAX_VALIDACOES_PARALELAS de uma vez) e entrega os resultados NA ORDEM da
    lista: o primeiro confirmado continua sendo o de maior prioridade, mas sem esperar um por um (cada validação pode
    levar até 12 s num servidor lento). Ao parar a iteração, as validações que ainda não começaram são canceladas."""
    if not candidatos:
        return
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=min(MAX_VALIDACOES_PARALELAS, len(candidatos)),
                                               thread_name_prefix="webhub-validar")
    try:
        futuros = [ex.submit(W.validar_candidato, c, base, ctx.sessao) for c in candidatos]
        for f in futuros:
            ctx.parar()
            try:
                yield f.result()
            except Exception as e:                 # uma validação com defeito não derruba as outras
                yield {"ok": False, "motivo": "erro na validação: %s" % type(e).__name__, "protecao": False}
    finally:
        ex.shutdown(wait=False, cancel_futures=True)


def plano_direto(v: dict, pagina: str, titulo: str, base: str) -> W.Plano:
    nome = v.get("nome") or nome_do_endereco(v["url"])
    p = W.Plano("direto", v["url"], pagina, titulo=titulo or posixpath.splitext(nome)[0],
                categoria=v["tipo"] if v["tipo"] in ("video", "audio", "imagem", "gif") else
                W.categoria(v.get("ext", ""), v.get("mime", "")),
                ext=v.get("ext", ""), tamanho=v.get("tamanho"), cabecalhos={"Referer": base} if base else {},
                temporaria=bool(v.get("temporaria")))
    p.tem_video = p.categoria in ("video", "gif")
    p.tem_audio = p.categoria in ("video", "audio")
    if p.temporaria:
        p.avisos.append("O endereço da mídia é temporário: se vencer, o Web Hub analisa a página de novo.")
    return p


def escolher_candidato(ctx: ContextoAnalise, an: dict, base: str, pagina: str) -> W.Plano | None:
    """Valida os candidatos da página, nesta ordem: mídia (vídeo, transmissão, áudio), players incorporados que o yt-dlp
    conhece, galeria de imagens, arquivo para baixar. O primeiro que se confirmar vence. Nada é aceito pela extensão:
    cada endereço é pedido ao servidor e o tipo REAL (Content-Type/primeiros bytes) decide."""
    cands = an["candidatos"]
    ordem = {"video": 0, "stream": 1, "audio": 2}
    midia = sorted([c for c in cands if c.tipo in ordem], key=lambda c: (ordem[c.tipo], c.origem != "navegador"))
    midia = midia[:MAX_CANDIDATOS_MIDIA]
    rejeitados = protegidos = 0
    for v in validar_em_ordem(ctx, midia, base):
        if not v["ok"]:
            rejeitados += 1
            protegidos += 1 if v.get("protecao") else 0
            continue
        ctx.registrar("analisador", "%s confirmado (%s)" % (v["tipo"], v.get("origem", "")))
        if v["tipo"] == "stream":
            pl = tentar_ytdlp(ctx, v["url"], pagina, base, False, "yt-dlp (lista da página)")
            if pl:
                pl.cabecalhos = {"Referer": base}
                return pl
            continue
        pl = plano_direto(v, pagina, an.get("titulo", ""), base)
        outros = len(midia) - 1 - rejeitados
        if outros > 0:
            pl.avisos.append("A página tem outras %d mídia(s); o Web Hub escolheu a primeira confirmada." % outros)
        return pl
    if midia:
        ctx.registrar("analisador", "%d endereço(s) de mídia na página, nenhum confirmado" % len(midia)
                      + (" (%d barrado(s) por verificação anti-robô)" % protegidos if protegidos else ""))
        if protegidos and protegidos == len(midia):
            raise W.erro_protecao(midia[0].url, ctx.detalhe())
    for c in [c for c in cands if c.tipo == "embed"][:6]:
        ext = ctx.extrator(c.url)
        if not ext:
            continue
        pl = tentar_ytdlp(ctx, c.url, pagina, base, ctx.playlist, "yt-dlp (player incorporado: %s)" % ext)
        if pl:
            return pl
    imgs = [c for c in cands if c.tipo in ("imagem", "gif")][:40]
    if imgs:
        boas = [v for v in validar_em_ordem(ctx, imgs, base) if v["ok"]]
        if len(boas) == 1:
            ctx.registrar("analisador", "1 imagem confirmada")
            return plano_direto(boas[0], pagina, "", base)
        if len(boas) > 1:
            ctx.registrar("analisador", "galeria: %d imagens confirmadas" % len(boas))
            pl = W.Plano("galeria", pagina, pagina, categoria="galeria", itens=[v["url"] for v in boas],
                         cabecalhos={"Referer": base}, miniatura=boas[0]["url"])
            pl.tamanho = sum(v["tamanho"] or 0 for v in boas) or None
            return pl
    arquivos = [c for c in cands if c.tipo == "arquivo"][:10]
    if arquivos:
        boas = [v for v in validar_em_ordem(ctx, arquivos, base) if v["ok"]]
        if len(boas) == 1:
            ctx.registrar("analisador", "1 arquivo para baixar")
            return plano_direto(boas[0], pagina, "", base)
        if len(boas) > 1:
            nomes = ", ".join(nome_do_endereco(v["url"]) for v in boas[:3])
            raise W.ErroWeb("varios_arquivos", "A página tem %d arquivos para baixar (%s...). Cole o link de um "
                                               "deles." % (len(boas), nomes))
    return None


# ======================================================================================================================
# Provedores concretos
# ======================================================================================================================
class YTDLPProvider(BaseProvider):
    """Motor primário para sites de hospedagem que escondem o arquivo atrás de um player: o extrator ESPECÍFICO do
    yt-dlp para o site resolve o endereço final da mídia (.mp4, .webm, .m4a, HLS/DASH), o título e a miniatura."""

    nome = "YTDLPProvider"
    prioridade = 10
    descricao = "yt-dlp (extrator específico do site)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        return bool(ctx.extrator(url))

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        return tentar_ytdlp(ctx, url, url, "", ctx.playlist, "yt-dlp (%s)" % ctx.extrator(url))

    def get_metadata(self, url: str, ctx: ContextoAnalise, plano: W.Plano) -> Metadados:
        return Metadados(titulo=plano.titulo, miniatura=plano.miniatura, site=plano.site or ctx.site,
                         duracao=plano.duracao)


class GalleryDLProvider(BaseProvider):
    """Galerias e coleções de imagens de sites que o gallery-dl conhece (componente opcional)."""

    nome = "GalleryDLProvider"
    prioridade = 20
    descricao = "gallery-dl (galerias de sites conhecidos)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        suporta = W.gallerydl_suporta(url)
        if suporta:
            return ctx.e_pagina()                   # um link direto de imagem é um arquivo, não uma galeria
        if suporta is None and W.host_de_galeria(url):
            ctx.registrar("gallery-dl", "não instalado (este site é de galerias)")
        return False

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        try:
            lst = W.gallerydl_listar(url, ctx.python)
        except W.ErroWeb as e:
            ctx.registrar("gallery-dl", "falhou: %s" % (e.detalhe or e))
            return None
        ctx.registrar("gallery-dl", "%d arquivo(s)" % lst["total"])
        if not lst["total"]:
            return None
        pl = W.Plano("gallerydl", url, url, titulo="", site=ctx.site, categoria="galeria", itens=lst["urls"][:2000])
        pl.miniatura = next((u for u in lst["urls"] if W.categoria(W.ext_do_caminho(u)) == "imagem"), "")
        return pl


class GenericHTMLProvider(BaseProvider):
    """O analisador próprio. Primeiro, o link é um arquivo? O tipo vem do Content-Type e, quando ele é genérico, da
    assinatura dos primeiros bytes (um 'foto.jpg' que entrega vídeo é vídeo; um 'video.mp4' que entrega uma página é
    página). Senão, busca profunda no HTML: <video>/<audio>/<source> (inclusive data-src), Open Graph, JSON-LD,
    endereços em scripts e JSON embutido (configurações de player, __NEXT_DATA__...), players incorporados, links para
    arquivos e galerias. Todo endereço achado é pedido ao servidor antes de ser aceito."""

    nome = "GenericHTMLProvider"
    prioridade = 30
    descricao = "analisador próprio (tipo real do link e busca profunda no HTML)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        return url.lower().startswith(("http://", "https://"))

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        s = ctx.sonda()
        if s is not None and not s.e_pagina:
            return self._plano_do_arquivo(ctx, s, url)
        ctx.parar()
        pag = ctx.pagina()
        if pag.get("desafio"):
            ctx.tentativas[-1] = ("página", ctx.tentativas[-1][1] + ", verificação anti-robô")
            raise W.erro_protecao(pag["url_final"], ctx.detalhe())
        if pag["status"] >= 400 and len(pag["html"]) < 2000:
            e = W.erro_http(pag["status"], url)
            e.detalhe = ctx.detalhe()
            raise e
        mime = pag.get("mime") or ""
        if mime and mime not in ("text/html", "application/xhtml+xml") and pag["status"] < 400:
            # o HEAD disse "página" (ou nada), mas o GET entrega outra coisa: o GET decide (URL enganosa)
            s2 = W.sondar(pag["url_final"], sessao=ctx.sessao, so_get=True)
            ctx.registrar("http (GET)", "o GET entrega %s, não uma página" % (s2.mime or "um arquivo"))
            if not s2.e_pagina:
                return self._plano_do_arquivo(ctx, s2, url)
        an = ctx.analise()
        if pag["status"] >= 400:
            ctx.avisos.append("O servidor respondeu HTTP %d, mas entregou o conteúdo da página." % pag["status"])
        if an["motor"] == "regex":
            ctx.avisos.append("Análise simplificada da página (o componente Beautiful Soup não está instalado).")
        return escolher_candidato(ctx, an, pag["url_final"], url)

    @staticmethod
    def _plano_do_arquivo(ctx: ContextoAnalise, s: W.Sonda, url: str) -> W.Plano | None:
        if s.categoria == "stream":
            pl = tentar_ytdlp(ctx, s.url_final, url, "", False, "yt-dlp (lista de transmissão)")
            if pl:
                return pl
            raise W.ErroWeb("extrator", "A lista de transmissão não pôde ser lida.", ctx.detalhe())
        nome = s.nome or nome_do_endereco(s.url_final)
        pl = W.Plano("direto", s.url_final, url, titulo=posixpath.splitext(nome)[0] or nome or ctx.site,
                     site=ctx.site, categoria=s.categoria, ext=s.ext, tamanho=s.tamanho, temporaria=s.temporaria)
        pl.tem_video = s.categoria in ("video", "gif")
        pl.tem_audio = s.categoria in ("video", "audio")
        if s.tamanho is None:
            pl.avisos.append("O servidor não informou o tamanho do arquivo.")
        if s.temporaria:
            pl.avisos.append("O endereço é temporário (assinado/com prazo): baixe logo; se vencer, o Web Hub "
                             "analisa a página de novo.")
        return pl

    def get_metadata(self, url: str, ctx: ContextoAnalise, plano: W.Plano) -> Metadados:
        meta = super().get_metadata(url, ctx, plano)
        if plano.mecanismo == "direto" and ctx.analise_se_lida() is None:
            meta.titulo = plano.titulo or nome_do_endereco(plano.alvo) or ctx.site
        return meta


class YTDLPGenericProvider(BaseProvider):
    """O extrator genérico do yt-dlp: reconhece players incorporados que o analisador próprio não leu. Só para páginas
    de sites SEM extrator específico (esses já passaram pelo YTDLPProvider). O endereço que ele achar é conferido como
    qualquer candidato (o genérico aceita um <video src="x.mp4"> só pelo nome)."""

    nome = "YTDLPGenericProvider"
    prioridade = 40
    descricao = "yt-dlp (extrator genérico)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        return not ctx.extrator(url) and ctx.e_pagina()

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        return tentar_ytdlp(ctx, url, url, "", ctx.playlist, "yt-dlp (genérico)", validar=True)


class StreamlinkProvider(BaseProvider):
    """Transmissões ao vivo de sites que o Streamlink conhece (componente opcional), quando o yt-dlp não serviu."""

    nome = "StreamlinkProvider"
    prioridade = 50
    descricao = "Streamlink (transmissões)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        return bool(W.streamlink_suporta(url)) and ctx.e_pagina()

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        an = ctx.analise_se_lida() or {}
        pl = W.Plano("streamlink", url, url, titulo=an.get("titulo", ""), site=ctx.site, categoria="video", ext="ts")
        pl.tem_video = pl.tem_audio = True
        pl.avisos.append("Transmissão gravada pelo Streamlink: o tamanho final só é conhecido no fim.")
        ctx.registrar("streamlink", "plugin disponível")
        return pl


class DynamicPageProvider(BaseProvider):
    """Páginas que só mostram a mídia depois de rodar JavaScript: abre a página num Chromium sem janela (Playwright,
    componente opcional), espera o player carregar sozinho e anota as respostas de mídia (vídeo, áudio, HLS/DASH) que a
    PRÓPRIA página pediu, além dos <video>/<audio> do DOM final. Não clica, não resolve CAPTCHA e não contorna
    verificações: uma página de verificação encerra a análise com a explicação."""

    nome = "DynamicPageProvider"
    prioridade = 60
    descricao = "navegador sem janela (Playwright + Chromium)"

    def can_handle(self, url: str, ctx: ContextoAnalise) -> bool:
        return ctx.e_pagina()

    def extract_media(self, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        an = ctx.analise_se_lida()
        if not ctx.usar_navegador():
            if an is not None and an.get("precisa_js"):
                ctx.registrar("navegador", "não instalado")
                raise W.ErroWeb("dependencia", "Esta página só mostra o vídeo depois de rodar JavaScript. Instale o "
                                               "Navegador do Web Hub (Componentes do Web Hub) para tentar de novo.",
                                ctx.detalhe(), "playwright")
            return None
        ctx.log("info", "Web Hub: abrindo a página num navegador sem janela (ela depende de JavaScript)...")
        nav = W.farejar_com_navegador(url, deve_parar=ctx.deve_parar)
        if nav["desafio"]:
            ctx.registrar("navegador", "a página mostrou uma verificação anti-robô")
            raise W.ErroWeb("protecao", "O site pede uma verificação (CAPTCHA/anti-robô) antes de mostrar o "
                                        "conteúdo. O yPeléTools não contorna isso: abra a página no navegador.",
                            ctx.detalhe())
        ctx.registrar("navegador", "%d resposta(s) de mídia" % len(nav["midias"]))
        an2 = W.analisar_html(nav["html"], nav["url_final"])
        for m in nav["midias"]:
            an2["candidatos"].insert(0, W.Candidato(m["url"], "navegador", m["tipo"], m["mime"]))
        an2["titulo"] = an2["titulo"] or nav["titulo"]
        ctx.extras["analise_renderizada"] = an2
        return escolher_candidato(ctx, an2, nav["url_final"], url)

    def get_metadata(self, url: str, ctx: ContextoAnalise, plano: W.Plano) -> Metadados:
        meta = super().get_metadata(url, ctx, plano)
        an2 = ctx.extras.get("analise_renderizada") or {}
        meta.titulo = plano.titulo or an2.get("titulo", "") or meta.titulo
        meta.miniatura = plano.miniatura or an2.get("miniatura", "") or meta.miniatura
        meta.site = plano.site or an2.get("site", "") or meta.site
        return meta


def provedores_padrao() -> list[BaseProvider]:
    """A cadeia de provedores do Web Hub, na ordem de prioridade."""
    return [YTDLPProvider(), GalleryDLProvider(), GenericHTMLProvider(), YTDLPGenericProvider(),
            StreamlinkProvider(), DynamicPageProvider()]


# ======================================================================================================================
# Core Manager
# ======================================================================================================================
class CoreManager:
    """Orquestrador do Web Hub: valida o link, cria o contexto da análise e percorre os provedores em ordem de
    prioridade até um entregar o plano (fallback). Callbacks do app:
      ytdlp_extrator(url) -> nome do extrator ESPECÍFICO do yt-dlp para o endereço ('' = só o genérico)
      ytdlp_info(url, referer, playlist) -> dict do yt-dlp (levanta Exception com o texto do erro)
      python -> o Python que roda gallery-dl e Streamlink
      log(nivel, texto) -> mensagens (já sem dados sensíveis)
      deve_parar() -> motivo para parar ('' segue)
      usar_navegador() -> o navegador do Web Hub está pronto?
    `provedores`: outra cadeia (testes, extensões); padrão: provedores_padrao()."""

    def __init__(self, ytdlp_extrator: ExtratorFn, ytdlp_info: InfoFn, python: str = "", log: LogFn | None = None,
                 deve_parar: PararFn | None = None, usar_navegador: Callable[[], bool] | None = None,
                 provedores: list[BaseProvider] | None = None) -> None:
        self.ytdlp_extrator = ytdlp_extrator
        self.ytdlp_info = ytdlp_info
        self.python = python or sys.executable
        self.log: LogFn = log or (lambda nivel, texto: None)
        self.deve_parar: PararFn = deve_parar or (lambda: "")
        self.usar_navegador = usar_navegador if usar_navegador is not None else W.navegador_instalado
        self.provedores: list[BaseProvider] = []
        for p in (provedores if provedores is not None else provedores_padrao()):
            self.registrar_provedor(p)

    def registrar_provedor(self, provedor: BaseProvider) -> None:
        """Acrescenta um provedor à cadeia, na posição da prioridade dele (estável entre prioridades iguais)."""
        if not isinstance(provedor, BaseProvider):
            raise TypeError("provedor precisa ser uma subclasse de BaseProvider")
        self.provedores.append(provedor)
        self.provedores.sort(key=lambda p: p.prioridade)

    @staticmethod
    def validar_url(url: str) -> str:
        url = (url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise W.ErroWeb("url_invalida", "Link inválido: use um endereço que comece com http:// ou https://.")
        try:
            p = urllib.parse.urlsplit(url)
            if not p.hostname or " " in url:
                raise ValueError
        except ValueError:
            raise W.ErroWeb("url_invalida", "Link inválido ou incompleto. Confira se ele foi copiado por inteiro."
                            ) from None
        W.exigir_publico(url)
        return url

    def novo_contexto(self, url: str, playlist: bool = False) -> ContextoAnalise:
        return ContextoAnalise(url, playlist, self.ytdlp_extrator, self.ytdlp_info, self.python, self.log,
                               self.deve_parar, self.usar_navegador)

    def planejar(self, url: str, playlist: bool = False) -> W.Plano:
        """Analisa o link e devolve o Plano do provedor que resolveu. Levanta W.ErroWeb (com o diagnóstico de todas as
        tentativas no detalhe) ou W.Cancelado."""
        url = self.validar_url(url)
        ctx = self.novo_contexto(url, playlist)
        for prov in self.provedores:
            ctx.parar()
            plano = self._rodar(prov, url, ctx)
            if plano is not None:
                return self._finalizar(prov, url, ctx, plano)
        raise self._sem_resultado(ctx)

    # -- execução protegida de um provedor
    def _rodar(self, prov: BaseProvider, url: str, ctx: ContextoAnalise) -> W.Plano | None:
        for etapa in ("can_handle", "extract_media"):
            try:
                if etapa == "can_handle":
                    if not prov.can_handle(url, ctx):
                        return None
                    continue
                return prov.extract_media(url, ctx)
            except W.Cancelado:
                raise
            except W.ErroWeb as e:
                if e.tipo in TIPOS_TERMINAIS:
                    if not e.detalhe:
                        e.detalhe = ctx.detalhe()
                    raise
                ctx.erros.append(e)
                ctx.registrar(prov.nome, "%s: %s" % (e.titulo, primeira_linha(str(e))[:160]))
                return None
            except Exception as e:                 # defeito do provedor: registra e deixa o próximo tentar
                ctx.registrar(prov.nome, "erro interno em %s (%s: %s)" % (etapa, type(e).__name__,
                                                                           primeira_linha(str(e))[:120]))
                self.log("warn", "Web Hub: o provedor %s falhou (%s); tentando o próximo." % (prov.nome,
                                                                                          type(e).__name__))
                return None
        return None

    def _finalizar(self, prov: BaseProvider, url: str, ctx: ContextoAnalise, plano: W.Plano) -> W.Plano:
        try:
            meta = prov.get_metadata(url, ctx, plano)
        except Exception:
            meta = Metadados()
        plano.titulo = plano.titulo or meta.titulo or ctx.site
        plano.miniatura = plano.miniatura or meta.miniatura
        plano.site = plano.site or meta.site or ctx.site
        if plano.duracao is None and meta.duracao is not None:
            plano.duracao = meta.duracao
        plano.pagina = url
        plano.avisos = list(ctx.avisos) + [a for a in plano.avisos if a not in ctx.avisos]
        plano.tentativas = ctx.tentativas
        plano.sessao = plano.sessao or ctx.sessao
        plano.provedor = prov.nome
        return plano

    @staticmethod
    def _sem_resultado(ctx: ContextoAnalise) -> W.ErroWeb:
        for tipo in _ORDEM_ERRO_FINAL:
            for e in ctx.erros:
                if e.tipo == tipo and tipo != "sem_midia":
                    e.detalhe = ctx.detalhe()
                    return e
        an = ctx.analise_se_lida() or {}
        dica = ""
        if an.get("precisa_js"):
            dica = " A página parece depender de JavaScript (%s)." % "; ".join(an.get("sinais", [])[:2])
        return W.ErroWeb("sem_midia", "Nenhuma mídia baixável foi encontrada nesta página, e o link não é um arquivo "
                                      "direto.%s O site pode não ser suportado ou exigir login." % dica, ctx.detalhe())


# Nome antigo (3.9.0/3.9.1): o app e quem usava ypele_webhub.Roteador continuam funcionando
Roteador = CoreManager
