"""yPeléTools — System Care: análise, limpeza e organização de arquivos com segurança (Beta 4.0.0).

Este módulo é só o MOTOR (sem interface): a aba System Care do app chama estas funções em threads de trabalho e mostra
o progresso. Tudo aqui é pensado para nunca apagar nem mover nada que a pessoa não tenha visto e confirmado.

    ferramenta          funções                                   o que faz
    Discos              listar_discos()                           espaço total, usado e livre de cada unidade
    Limpeza             locais_limpeza(), analisar_limpeza(),     acha temporários, caches e resíduos em locais
                        executar_limpeza()                        conhecidos; classifica cada arquivo (Seguro, Requer
                                                                  revisão, Não remover) com o motivo; remove só o que
                                                                  a pessoa marcou
    Organizador         analisar_pasta(), planejar_organizacao(), separa os arquivos de uma pasta por tipo; prévia
                        executar_organizacao()                    completa; nunca sobrescreve sem autorização
    Duplicados          buscar_duplicados(), remover_duplicados() conteúdo idêntico por SHA-256 (tamanho só como
                                                                  pré-filtro); sempre fica ao menos uma cópia
    Armazenamento       analisar_armazenamento()                  quanto cada categoria ocupa numa unidade ou pasta
    Histórico           Historico                                 só metadados das operações (nunca o conteúdo)

Regras de segurança (valem para todas as funções):
  - nada é apagado ou movido sem estar numa lista que a interface mostrou e a pessoa confirmou;
  - pastas do Windows, de programas, de dados de programas e as pastas pessoais nunca são limpas
    (caminho_protegido); arquivos com o atributo de sistema, ligações simbólicas e junções nunca são tocados;
  - arquivos em uso por outro programa não são apagados nem movidos (no Windows, testado de verdade abrindo o arquivo
    sem compartilhamento); erros de permissão viram "ignorado" com o motivo, sem pedir administrador e sem contornar;
  - pastas nunca são apagadas inteiras: só arquivos, um a um; depois, só as subpastas que ficaram VAZIAS dentro do
    local analisado (os.rmdir, que falha se houver qualquer coisa dentro);
  - o Registro do Windows, programas instalados e a inicialização não são tocados; histórico, cookies, senhas e
    sessões dos navegadores também não (só as pastas de cache);
  - antes de apagar ou mover, o arquivo é conferido de novo (tamanho e data; nos duplicados, o SHA-256): se mudou
    depois da análise, fica onde está.
"""
from __future__ import annotations

import errno
import hashlib
import heapq
import json
import os
import shutil
import stat as st_mod
import sys
import tempfile
import threading
import time
import uuid
from collections.abc import Callable, Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

VERSAO_SYSTEMCARE = 1
WINDOWS = sys.platform == "win32"

ProgressoFn = Optional[Callable[[dict], None]]

# ----------------------------------------------------------------------------------------------------------------------
# Categorias de arquivo
# ----------------------------------------------------------------------------------------------------------------------
CATEGORIAS = ("imagens", "videos", "audios", "documentos", "planilhas", "apresentacoes", "compactados", "executaveis",
              "codigo", "outros")
NOMES_CATEGORIA = {"imagens": "Imagens", "videos": "Vídeos", "audios": "Áudios", "documentos": "Documentos",
                   "planilhas": "Planilhas", "apresentacoes": "Apresentações", "compactados": "Compactados",
                   "executaveis": "Executáveis e instaladores", "codigo": "Código", "outros": "Outros"}
# nome da pasta que o Organizador cria para cada categoria (curto e sem caracteres proibidos no Windows)
PASTAS_CATEGORIA = {"imagens": "Imagens", "videos": "Vídeos", "audios": "Áudios", "documentos": "Documentos",
                    "planilhas": "Planilhas", "apresentacoes": "Apresentações", "compactados": "Compactados",
                    "executaveis": "Instaladores e programas", "codigo": "Código", "outros": "Outros"}


def _exts(texto: str) -> frozenset:
    return frozenset("." + e for e in texto.split())


EXTENSOES = {
    "imagens": _exts("jpg jpeg jpe jfif png gif bmp dib tif tiff webp heic heif avif ico svg psd raw cr2 cr3 nef arw "
                     "dng orf rw2 xcf ai eps jxl"),
    "videos": _exts("mp4 m4v mkv avi mov wmv flv webm mpg mpeg m2ts mts ts 3gp 3g2 ogv vob f4v rmvb divx"),
    "audios": _exts("mp3 wav flac aac m4a ogg oga opus wma aiff aif alac mid midi amr ape dsf wv"),
    "documentos": _exts("pdf doc docx docm odt rtf txt md epub mobi azw3 tex wpd pages xps oxps djvu"),
    "planilhas": _exts("xls xlsx xlsm xlsb ods csv tsv numbers"),
    "apresentacoes": _exts("ppt pptx pptm pps ppsx odp key"),
    "compactados": _exts("zip rar 7z tar gz tgz bz2 tbz2 xz txz zst lz lzma cab iso img dmg arj z"),
    "executaveis": _exts("exe msi msix msixbundle appx appxbundle bat cmd com scr apk jar"),
    "codigo": _exts("py pyw ipynb js mjs cjs tsx jsx html htm css scss sass less json xml yaml yml toml ini cfg c h "
                    "cpp hpp cc cs java kt kts go rs rb php pl swift sh ps1 psm1 vbs lua sql r dart scala sln csproj "
                    "vcxproj gradle"),
}
_CATEGORIA_DA_EXT = {e: c for c, s in EXTENSOES.items() for e in s}

# Análise de armazenamento: as 8 categorias pedidas
CATEGORIAS_ARMAZENAMENTO = ("documentos", "imagens", "videos", "audios", "compactados", "aplicativos", "temporarios",
                            "outros")
NOMES_ARMAZENAMENTO = {"documentos": "Documentos", "imagens": "Imagens", "videos": "Vídeos", "audios": "Áudios",
                       "compactados": "Compactados", "aplicativos": "Aplicativos e instaladores",
                       "temporarios": "Temporários", "outros": "Outros"}
EXT_TEMPORARIAS = frozenset((".tmp", ".temp", ".crdownload", ".part", ".partial", ".!ut", ".dmp"))
EXT_APLICATIVOS_EXTRA = frozenset((".dll", ".ocx", ".msp"))


def extensao(nome: str) -> str:
    """Extensão em minúsculas, com o ponto ('' se não tem). '.tar.gz' conta como '.gz' (categoria compactados)."""
    base = os.path.basename(nome)
    i = base.rfind(".")
    return base[i:].lower() if i > 0 else ""


def categoria_por_extensao(nome: str) -> str:
    """Categoria do Organizador pelo nome do arquivo (uma das CATEGORIAS)."""
    return _CATEGORIA_DA_EXT.get(extensao(nome), "outros")


def categoria_armazenamento(nome: str, temporario: bool = False) -> str:
    """Categoria da análise de armazenamento (uma das CATEGORIAS_ARMAZENAMENTO)."""
    ext = extensao(nome)
    if temporario or ext in EXT_TEMPORARIAS or os.path.basename(nome).startswith("~$"):
        return "temporarios"
    c = _CATEGORIA_DA_EXT.get(ext, "outros")
    if c in ("documentos", "planilhas", "apresentacoes"):
        return "documentos"
    if c == "executaveis" or ext in EXT_APLICATIVOS_EXTRA:
        return "aplicativos"
    if c in ("imagens", "videos", "audios", "compactados"):
        return c
    return "outros"


def fmt_bytes(n: float) -> str:
    """1536 -> '1,5 KB' (base 1024, vírgula decimal)."""
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or u == "TB":
            if u == "B":
                return "%d B" % n
            return ("%.1f %s" % (n, u)).replace(".", ",")
        n /= 1024
    return "%d B" % n


# ----------------------------------------------------------------------------------------------------------------------
# Erros, cancelamento e progresso
# ----------------------------------------------------------------------------------------------------------------------
class ErroSystemCare(Exception):
    """Erro com mensagem pronta para a pessoa (pasta protegida, caminho inválido...)."""


class Cancelamento:
    """Sinal de cancelamento compartilhado entre a interface e a thread de trabalho."""

    def __init__(self) -> None:
        self._ev = threading.Event()

    def cancelar(self) -> None:
        self._ev.set()

    @property
    def cancelado(self) -> bool:
        return self._ev.is_set()

    def __bool__(self) -> bool:            # `if cancelar:` lê como "foi cancelado?"
        return self._ev.is_set()


def _cancelado(c: Optional[Cancelamento]) -> bool:
    return bool(c is not None and c.cancelado)


class _Avisador:
    """Chama progresso(dict) no máximo a cada `intervalo` segundos (e sempre no fim): a interface não é inundada."""

    def __init__(self, fn: ProgressoFn, intervalo: float = 0.12) -> None:
        self.fn, self.intervalo, self._ultimo = fn, intervalo, 0.0

    def __call__(self, forcar: bool = False, **dados: Any) -> None:
        if self.fn is None:
            return
        agora = time.monotonic()
        if forcar or agora - self._ultimo >= self.intervalo:
            self._ultimo = agora
            try:
                self.fn(dados)
            except Exception:       # um erro na interface nunca derruba a operação
                pass


@dataclass
class ResultadoOperacao:
    """Resultado de uma operação que remove ou move arquivos."""
    tipo: str
    total: int = 0                           # itens pedidos
    processados: int = 0                     # removidos ou movidos de verdade
    liberado: int = 0                        # bytes liberados (remoções)
    ignorados: list = field(default_factory=list)   # [(caminho, motivo)] não tocados de propósito
    erros: list = field(default_factory=list)       # [(caminho, motivo)] falhas inesperadas
    feitos: list = field(default_factory=list)      # [(origem, destino ou "")] o que foi feito
    cancelado: bool = False
    duracao: float = 0.0


# ----------------------------------------------------------------------------------------------------------------------
# Windows: atributos, arquivo em uso, unidades e Lixeira (ctypes; nada disso pede administrador)
# ----------------------------------------------------------------------------------------------------------------------
FILE_ATTRIBUTE_HIDDEN = 0x2
FILE_ATTRIBUTE_SYSTEM = 0x4
FILE_ATTRIBUTE_REPARSE_POINT = 0x400
FILE_ATTRIBUTE_OFFLINE = 0x1000
FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x40000
FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x400000
_ATRIB_NUVEM = FILE_ATTRIBUTE_OFFLINE | FILE_ATTRIBUTE_RECALL_ON_OPEN | FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS


def _atributos(s: os.stat_result) -> int:
    return int(getattr(s, "st_file_attributes", 0) or 0)


def e_sistema(s: os.stat_result) -> bool:
    return bool(_atributos(s) & FILE_ATTRIBUTE_SYSTEM)


def e_oculto(nome: str, s: os.stat_result) -> bool:
    if WINDOWS:
        return bool(_atributos(s) & FILE_ATTRIBUTE_HIDDEN)
    return os.path.basename(nome).startswith(".")


def e_ligacao(s: os.stat_result) -> bool:
    return st_mod.S_ISLNK(s.st_mode) or bool(_atributos(s) & FILE_ATTRIBUTE_REPARSE_POINT)


def so_na_nuvem(s: os.stat_result) -> bool:
    """Arquivo do OneDrive (ou similar) que não está baixado: ler o conteúdo faria o Windows baixá-lo."""
    return bool(_atributos(s) & _ATRIB_NUVEM)


_ERROR_ACCESS_DENIED = 5
_ERROR_SHARING_VIOLATION = 32
_ERROR_LOCK_VIOLATION = 33


def _testar_uso_windows(caminho: str) -> str:
    """'' livre; 'em_uso' aberto por outro programa; 'sem_permissao' sem acesso; 'sumiu' não existe mais.
    Abre só para LEITURA e sem compartilhamento (dwShareMode=0): se outro processo tem o arquivo aberto, o Windows
    recusa com ERROR_SHARING_VIOLATION. Nada é alterado no arquivo."""
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    k32.CreateFileW.restype = wintypes.HANDLE
    k32.CreateFileW.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD,
                                wintypes.DWORD, wintypes.HANDLE)
    k32.CloseHandle.argtypes = (wintypes.HANDLE,)
    generic_read, open_existing, normal = 0x80000000, 3, 0x80
    h = k32.CreateFileW(caminho, generic_read, 0, None, open_existing, normal, None)
    if h is None or h == wintypes.HANDLE(-1).value:
        err = ctypes.get_last_error()  # type: ignore[attr-defined]
        if err in (_ERROR_SHARING_VIOLATION, _ERROR_LOCK_VIOLATION):
            return "em_uso"
        if err == _ERROR_ACCESS_DENIED:
            return "sem_permissao"
        if err in (2, 3):
            return "sumiu"
        return "em_uso" if err else ""
    k32.CloseHandle(h)
    return ""


# Testes trocam este detector para simular arquivos bloqueados (no Windows real ele é o teste acima).
DETECTOR_EM_USO: Callable[[str], str] = _testar_uso_windows if WINDOWS else (lambda _c: "")


def estado_uso(caminho: str) -> str:
    try:
        return DETECTOR_EM_USO(caminho)
    except Exception:
        return ""


def _tipo_unidade(raiz: str) -> str:
    if not WINDOWS:
        return "fixo"
    try:
        import ctypes
        t = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(raiz))  # type: ignore[attr-defined]
    except Exception:
        return "fixo"
    return {2: "removivel", 3: "fixo", 4: "rede", 5: "cd", 6: "ram"}.get(int(t), "desconhecido")


def _rotulo_unidade(raiz: str) -> str:
    if not WINDOWS:
        return ""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(261)
        ok = ctypes.windll.kernel32.GetVolumeInformationW(ctypes.c_wchar_p(raiz), buf, 261, None, None, None, None, 0)  # type: ignore[attr-defined]
        return buf.value if ok else ""
    except Exception:
        return ""


@dataclass
class Disco:
    raiz: str
    rotulo: str
    tipo: str
    total: int
    usado: int
    livre: int

    @property
    def pct_usado(self) -> float:
        return (self.usado / self.total) if self.total else 0.0


def listar_discos() -> list:
    """Unidades com espaço medido de verdade (shutil.disk_usage). No Windows: todas as letras montadas (menos leitores
    de CD sem disco); fora dele: a raiz e a pasta pessoal, se forem sistemas de arquivos diferentes."""
    raizes: list = []
    if WINDOWS:
        try:
            import ctypes
            mascara = int(ctypes.windll.kernel32.GetLogicalDrives())  # type: ignore[attr-defined]
        except Exception:
            mascara = 0
        for i in range(26):
            if mascara & (1 << i):
                raizes.append("%s:\\" % chr(65 + i))
    else:
        raizes.append("/")
        try:
            casa = str(Path.home())
            if os.stat(casa).st_dev != os.stat("/").st_dev:
                raizes.append(casa)
        except OSError:
            pass
    discos = []
    for r in raizes:
        tipo = _tipo_unidade(r)
        try:
            u = shutil.disk_usage(r)
        except OSError:
            continue                        # CD sem disco, unidade de rede desconectada...
        if u.total <= 0:
            continue
        discos.append(Disco(r, _rotulo_unidade(r), tipo, int(u.total), int(u.used), int(u.free)))
    return discos


def tem_lixeira(caminho: str) -> bool:
    """A Lixeira do Windows só existe em unidades fixas; em pen drives e unidades de rede, 'enviar para a Lixeira'
    apagaria de vez. Fora do Windows: a lixeira do usuário (freedesktop) só recebe arquivos do mesmo disco."""
    if WINDOWS:
        drive = os.path.splitdrive(os.path.abspath(caminho))[0]
        return bool(drive) and not drive.startswith("\\\\") and _tipo_unidade(drive + "\\") == "fixo"
    base = _pasta_lixeira_xdg()
    while not base.exists() and base.parent != base:
        base = base.parent
    try:
        return os.stat(caminho).st_dev == os.stat(base).st_dev
    except OSError:
        return False


def _dados_xdg() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))


def _pasta_lixeira_xdg() -> Path:
    return _dados_xdg() / "Trash"


def _lixeira_windows(caminho: str) -> None:
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", wintypes.LPVOID), ("lpszProgressTitle", wintypes.LPCWSTR)]
    fo_delete = 3
    fof_silent, fof_noconfirmation, fof_allowundo, fof_noerrorui = 0x4, 0x10, 0x40, 0x400
    op = SHFILEOPSTRUCTW(None, fo_delete, os.path.abspath(caminho) + "\0\0", None,
                         fof_silent | fof_noconfirmation | fof_allowundo | fof_noerrorui, False, None, None)
    r = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))  # type: ignore[attr-defined]
    if r != 0 or op.fAnyOperationsAborted:
        raise OSError(errno.EIO, "o Windows não conseguiu enviar para a Lixeira (código %s)" % r)
    if os.path.lexists(caminho):
        raise OSError(errno.EIO, "o arquivo continua no lugar depois de enviar para a Lixeira")


def _lixeira_xdg(caminho: str) -> None:
    """Lixeira do freedesktop.org (Linux): files/ + info/<nome>.trashinfo. Só no mesmo disco (rename atômico)."""
    lix = _pasta_lixeira_xdg()
    (lix / "files").mkdir(parents=True, exist_ok=True)
    (lix / "info").mkdir(parents=True, exist_ok=True)
    base = os.path.basename(caminho)
    nome, k = base, 1
    while True:
        try:
            fd = os.open(str(lix / "info" / (nome + ".trashinfo")), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            break
        except FileExistsError:
            k += 1
            raiz, ext = os.path.splitext(base)
            nome = "%s.%d%s" % (raiz, k, ext)
    from urllib.parse import quote
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("[Trash Info]\nPath=%s\nDeletionDate=%s\n" % (quote(os.path.abspath(caminho)),
                                                              datetime.now().strftime("%Y-%m-%dT%H:%M:%S")))
    try:
        os.rename(caminho, str(lix / "files" / nome))
    except OSError:
        try:
            os.unlink(str(lix / "info" / (nome + ".trashinfo")))
        except OSError:
            pass
        raise


def enviar_lixeira(caminho: str) -> None:
    """Manda um arquivo para a Lixeira (recuperável). Levanta OSError se não der; nunca apaga de vez no lugar."""
    if not tem_lixeira(caminho):
        raise OSError(errno.EXDEV, "esta unidade não tem Lixeira (pen drive, cartão ou unidade de rede)")
    if WINDOWS:
        _lixeira_windows(caminho)
    else:
        _lixeira_xdg(caminho)


# ----------------------------------------------------------------------------------------------------------------------
# Caminhos protegidos
# ----------------------------------------------------------------------------------------------------------------------
def _norm(p: Any) -> str:
    s = os.path.normcase(os.path.abspath(str(p)))
    return s.rstrip("\\/") or s


def dentro_de(caminho: Any, pasta: Any) -> bool:
    """caminho está dentro de pasta (ou é ela)? Comparação sem diferença de maiúsculas no Windows."""
    c, p = _norm(caminho), _norm(pasta)
    if c == p:
        return True
    return c.startswith(p if p.endswith(os.sep) else p + os.sep)


def _pastas_pessoais(home: Path) -> list:
    nomes = ("Documents", "Documentos", "Desktop", "Área de Trabalho", "Pictures", "Imagens", "Music", "Músicas",
             "Videos", "Vídeos", "OneDrive", "Contacts", "Favorites", "Saved Games", "3D Objects")
    return [home / n for n in nomes]


def pastas_protegidas(env: Optional[Mapping] = None, home: Optional[Path] = None) -> list:
    """Pastas onde a LIMPEZA nunca apaga nada (as exceções conhecidas, como Windows\\Temp, ficam em
    excecoes_protegidas)."""
    env = os.environ if env is None else env  # type: ignore[assignment]
    home = Path(home or Path.home())
    lista: list = []
    win = env.get("SystemRoot") or env.get("WINDIR") or ("C:\\Windows" if WINDOWS else "")
    if win:
        lista.append(Path(win))
    for k in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "ProgramData", "CommonProgramFiles",
              "CommonProgramFiles(x86)"):
        if env.get(k):
            lista.append(Path(env[k]))
    if not WINDOWS and not env.get("SystemRoot"):
        lista += [Path(p) for p in ("/bin", "/boot", "/etc", "/lib", "/lib64", "/opt", "/sbin", "/usr", "/var/lib",
                                    "/proc", "/sys", "/dev")]
    lista += _pastas_pessoais(home)
    return lista


def excecoes_protegidas(env: Optional[Mapping] = None) -> list:
    env = os.environ if env is None else env  # type: ignore[assignment]
    win = env.get("SystemRoot") or env.get("WINDIR") or ("C:\\Windows" if WINDOWS else "")
    if not win:
        return []
    return [Path(win) / "Temp", Path(win) / "SoftwareDistribution" / "Download"]


def caminho_protegido(caminho: Any, env: Optional[Mapping] = None, home: Optional[Path] = None) -> bool:
    """True quando a LIMPEZA não pode apagar este caminho (pasta do sistema, de programas ou pessoal)."""
    if any(dentro_de(caminho, e) for e in excecoes_protegidas(env)):
        return False
    return any(dentro_de(caminho, p) for p in pastas_protegidas(env, home))


def pasta_proibida_para_organizar(pasta: Any, env: Optional[Mapping] = None, home: Optional[Path] = None) -> str:
    """Motivo pelo qual o Organizador recusa a pasta ('' se pode). Pastas pessoais (Documentos, Imagens...) PODEM ser
    organizadas: é a pessoa que escolhe. Pastas do sistema e de programas, a raiz da unidade do Windows e as pastas de
    dados de programas (AppData) não."""
    env = os.environ if env is None else env  # type: ignore[assignment]
    home = Path(home or Path.home())
    p = Path(pasta)
    try:
        if not p.is_dir():
            return "a pasta não existe (ou não é uma pasta)"
    except OSError as e:
        return "não consegui abrir a pasta (%s)" % (e.strerror or e)
    win = env.get("SystemRoot") or env.get("WINDIR") or ("C:\\Windows" if WINDOWS else "")
    proibidas = []
    if win:
        proibidas.append((Path(win), "é a pasta do Windows"))
        drive = os.path.splitdrive(str(win))[0]
        if drive and _norm(p) == _norm(drive + os.sep):
            return "é a raiz da unidade do Windows (%s): organize uma subpasta" % drive
    for k in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "ProgramData"):
        if env.get(k):
            proibidas.append((Path(env[k]), "é uma pasta de programas instalados"))
    for k in ("APPDATA", "LOCALAPPDATA"):
        if env.get(k):
            proibidas.append((Path(env[k]), "guarda dados de programas (AppData)"))
    proibidas.append((home / "AppData", "guarda dados de programas (AppData)"))
    if not WINDOWS:
        if _norm(p) in (_norm("/"),):
            return "é a raiz do sistema"
        for x in ("/bin", "/boot", "/etc", "/lib", "/usr", "/var", "/proc", "/sys", "/dev"):
            proibidas.append((Path(x), "é uma pasta do sistema"))
    for pasta_p, motivo in proibidas:
        if dentro_de(p, pasta_p):
            return motivo
    if _norm(p) == _norm(home):
        return "é a sua pasta de usuário inteira: escolha uma subpasta (Downloads, Documentos...)"
    return ""


# ----------------------------------------------------------------------------------------------------------------------
# Varredura de pastas (sem seguir ligações, com cancelamento e sem estourar a memória)
# ----------------------------------------------------------------------------------------------------------------------
def percorrer(raiz: Any, cancelar: Optional[Cancelamento] = None, recursivo: bool = True,
              ao_erro: Optional[Callable[[str, str], None]] = None,
              pular_dir: Optional[Callable[[str], bool]] = None) -> Iterator:
    """Gera (caminho, nome, stat) de cada ARQUIVO. Nunca entra em ligações simbólicas nem junções (evita laços e
    pastas de outros lugares). Pastas sem permissão viram ao_erro(caminho, motivo) e a varredura continua."""
    pilha = [str(raiz)]
    while pilha:
        if _cancelado(cancelar):
            return
        atual = pilha.pop()
        try:
            it = os.scandir(atual)
        except OSError as e:
            if ao_erro is not None:
                ao_erro(atual, motivo_erro(e))
            continue
        with it:
            subpastas = []
            for ent in it:
                if _cancelado(cancelar):
                    return
                try:
                    s = ent.stat(follow_symlinks=False)
                except OSError as e:
                    if ao_erro is not None:
                        ao_erro(ent.path, motivo_erro(e))
                    continue
                if e_ligacao(s):
                    continue
                if st_mod.S_ISDIR(s.st_mode):
                    if recursivo and not (pular_dir is not None and pular_dir(ent.path)):
                        subpastas.append(ent.path)
                    continue
                if st_mod.S_ISREG(s.st_mode):
                    yield ent.path, ent.name, s
            pilha.extend(reversed(subpastas))


def motivo_erro(e: BaseException) -> str:
    """Texto curto do erro para a pessoa."""
    if isinstance(e, PermissionError):
        return "sem permissão (o System Care não pede administrador)"
    if isinstance(e, FileNotFoundError):
        return "não existe mais"
    if isinstance(e, OSError):
        w = getattr(e, "winerror", None)
        if w in (_ERROR_SHARING_VIOLATION, _ERROR_LOCK_VIOLATION):
            return "em uso por outro programa"
        if e.errno == errno.ENOSPC:
            return "disco cheio"
        if e.errno == errno.ENAMETOOLONG:
            return "caminho longo demais"
        return (e.strerror or str(e)).strip() or e.__class__.__name__
    return str(e) or e.__class__.__name__


# ----------------------------------------------------------------------------------------------------------------------
# Limpeza
# ----------------------------------------------------------------------------------------------------------------------
SEGURO, REVISAO, NAO_REMOVER = "seguro", "revisao", "nao_remover"
NOMES_CLASSE = {SEGURO: "Seguro para limpeza", REVISAO: "Requer revisão", NAO_REMOVER: "Não remover"}

# arquivos pessoais encontrados numa pasta temporária vão para revisão (podem ser um anexo aberto, um rascunho...)
_CATS_PESSOAIS = ("imagens", "videos", "audios", "documentos", "planilhas", "apresentacoes")
_NOMES_NUNCA = frozenset(("desktop.ini", "ntuser.dat", "ntuser.ini", "pagefile.sys", "hiberfil.sys", "swapfile.sys",
                          "bootmgr", "iconcache.db"))
DIA = 86400.0
_SINGULAR = {"imagens": "imagem", "videos": "vídeo", "audios": "áudio", "documentos": "documento",
             "planilhas": "planilha", "apresentacoes": "apresentação"}


@dataclass
class LocalLimpeza:
    """Um lugar conhecido onde há arquivos descartáveis."""
    chave: str
    grupo: str                    # título do grupo na interface
    caminho: Path
    classe: str                   # classificação dos arquivos comuns deste local
    motivo: str                   # por que (mostrado em cada arquivo)
    marcado: bool = True          # já vem marcado na lista? (caches de navegador: não; a pessoa escolhe)
    recursivo: bool = True
    idade_minima: float = 0.0     # dias: arquivos mais novos nem entram (logs antigos)
    idade_revisao: float = 0.0    # dias: arquivos mais novos vão para revisão (temporários em uso recente)
    padroes: tuple = ()           # só nomes que terminam com estes sufixos (minúsculas); vazio = todos
    prefixos: tuple = ()          # só nomes que começam com estes prefixos (minúsculas); vazio = todos


@dataclass
class ItemLimpeza:
    caminho: str
    nome: str
    tamanho: int
    mtime: float
    classe: str
    motivo: str
    grupo: str
    local: str                    # chave do LocalLimpeza
    raiz: str                     # pasta do local (as subpastas vazias só são removidas dentro dela)
    marcado: bool = False


@dataclass
class ResultadoLimpeza:
    itens: list
    locais: list                   # [(grupo, caminho, situação)] situação: "ok", "não existe", motivo do erro
    sem_acesso: list               # [(caminho, motivo)] pastas ou arquivos que não deu para ler
    cancelado: bool = False
    duracao: float = 0.0

    def total(self, classe: Optional[str] = None) -> int:
        return sum(i.tamanho for i in self.itens if classe is None or i.classe == classe)

    def quantidade(self, classe: Optional[str] = None) -> int:
        return sum(1 for i in self.itens if classe is None or i.classe == classe)

    @property
    def recuperavel(self) -> int:
        """Bytes que podem ser liberados (Seguro + Requer revisão; 'Não remover' nunca conta)."""
        return sum(i.tamanho for i in self.itens if i.classe != NAO_REMOVER)


_PERFIS_CHROMIUM = ("Default", "Guest Profile", "System Profile")
_CACHES_CHROMIUM = (("Cache", "Cache_Data"), ("Code Cache",), ("GPUCache",), ("Service Worker", "CacheStorage"))
_NAVEGADORES_CHROMIUM = (("Google Chrome", ("LOCALAPPDATA", "Google", "Chrome", "User Data")),
                         ("Microsoft Edge", ("LOCALAPPDATA", "Microsoft", "Edge", "User Data")),
                         ("Brave", ("LOCALAPPDATA", "BraveSoftware", "Brave-Browser", "User Data")),
                         ("Vivaldi", ("LOCALAPPDATA", "Vivaldi", "User Data")),
                         ("Opera", ("APPDATA", "Opera Software", "Opera Stable")),
                         ("Opera GX", ("APPDATA", "Opera Software", "Opera GX Stable")))
_MOTIVO_NAVEGADOR = ("cache do navegador: as páginas e imagens são baixadas de novo quando precisar. Histórico, "
                     "cookies, senhas e sessões abertas NUNCA são tocados")


def _junta(env: Mapping, partes: tuple) -> Optional[Path]:
    base = env.get(partes[0])
    if not base:
        return None
    return Path(base, *partes[1:])


def locais_limpeza(env: Optional[Mapping] = None, extras: Iterable = ()) -> list:
    """Locais conhecidos de temporários, caches e resíduos, montados a partir das variáveis de ambiente (os testes
    passam um `env` que aponta para pastas de teste). `extras`: LocalLimpeza do próprio app (logs antigos, restos de
    downloads). Locais repetidos (mesma pasta por dois caminhos) entram uma vez só."""
    env = dict(os.environ if env is None else env)
    locais: list = []

    def add(chave: str, grupo: str, caminho: Optional[Path], classe: str, motivo: str, **kw: Any) -> None:
        if caminho is not None:
            locais.append(LocalLimpeza(chave, grupo, Path(caminho), classe, motivo, **kw))

    temp_usuario = env.get("TEMP") or env.get("TMP") or (tempfile.gettempdir() if not WINDOWS else "")
    add("temp_usuario", "Temporários do usuário", Path(temp_usuario) if temp_usuario else None, SEGURO,
        "arquivo temporário: programas criam e esquecem aqui", idade_revisao=1.0)
    add("temp_local", "Temporários do usuário", _junta(env, ("LOCALAPPDATA", "Temp")), SEGURO,
        "arquivo temporário: programas criam e esquecem aqui", idade_revisao=1.0)
    win = env.get("SystemRoot") or env.get("WINDIR")
    if win:
        add("temp_windows", "Temporários do Windows", Path(win) / "Temp", SEGURO,
            "temporário do Windows e de instalações", idade_revisao=2.0)
        add("windows_update", "Temporários de instalação", Path(win) / "SoftwareDistribution" / "Download", REVISAO,
            "atualizações já baixadas pelo Windows Update: o Windows baixa de novo se precisar, mas não apague com "
            "uma atualização em andamento", marcado=False)
    add("instalacoes", "Temporários de instalação", _junta(env, ("LOCALAPPDATA", "Downloaded Installations")), REVISAO,
        "instalador guardado por um programa: alguns usam para reparar ou desinstalar", marcado=False)
    add("pacotes_msi", "Temporários de instalação", _junta(env, ("LOCALAPPDATA", "Package Cache")), NAO_REMOVER,
        "pacote de instalação usado para reparar ou desinstalar programas", marcado=False)

    # caches de navegadores (só as pastas de cache; nunca Cookies, History, Login Data, Local Storage...)
    for nome_nav, partes in _NAVEGADORES_CHROMIUM:
        base = _junta(env, partes)
        if base is None:
            continue
        perfis = list(_PERFIS_CHROMIUM)
        try:
            perfis += sorted(n for n in os.listdir(base) if n.startswith("Profile "))
        except OSError:
            pass
        alvos = []
        if nome_nav.startswith("Opera"):
            alvos.append(base)                              # o Opera guarda o perfil direto na pasta
        else:
            alvos += [base / p for p in perfis]
        for alvo in alvos:
            for c in _CACHES_CHROMIUM:
                add("nav_" + nome_nav, "Cache de navegadores — " + nome_nav, alvo.joinpath(*c), SEGURO,
                    _MOTIVO_NAVEGADOR, marcado=False)
        if not nome_nav.startswith("Opera"):
            for nome_c in ("ShaderCache", "GrShaderCache", "GraphiteDawnCache"):
                add("nav_" + nome_nav, "Cache de navegadores — " + nome_nav, base / nome_c, SEGURO, _MOTIVO_NAVEGADOR,
                    marcado=False)
    ff = _junta(env, ("LOCALAPPDATA", "Mozilla", "Firefox", "Profiles"))
    if ff is not None:
        try:
            for p in sorted(os.listdir(ff)):
                add("nav_firefox", "Cache de navegadores — Firefox", ff / p / "cache2", SEGURO, _MOTIVO_NAVEGADOR,
                    marcado=False)
        except OSError:
            pass

    # caches de aplicativos que se reconstroem sozinhos
    caches: tuple = (("cache_inet", ("LOCALAPPDATA", "Microsoft", "Windows", "INetCache"),
               "cache de internet do Windows (Internet Explorer, Office e apps antigos)"),
              ("cache_d3d", ("LOCALAPPDATA", "D3DSCache"), "cache de shaders do DirectX: o Windows recria"),
              ("cache_nvidia_dx", ("LOCALAPPDATA", "NVIDIA", "DXCache"), "cache de shaders da NVIDIA: o driver recria"),
              ("cache_nvidia_gl", ("LOCALAPPDATA", "NVIDIA", "GLCache"), "cache de shaders da NVIDIA: o driver recria"),
              ("cache_amd", ("LOCALAPPDATA", "AMD", "DxCache"), "cache de shaders da AMD: o driver recria"),
              ("cache_pip", ("LOCALAPPDATA", "pip", "Cache"), "cache do pip (Python): pacotes são baixados de novo"),
              ("cache_npm", ("LOCALAPPDATA", "npm-cache"), "cache do npm: pacotes são baixados de novo"),
              ("cache_discord", ("APPDATA", "discord", "Cache"), "cache do Discord: imagens e arquivos vistos"),
              ("cache_discord", ("APPDATA", "discord", "Code Cache"), "cache do Discord"),
              ("cache_discord", ("APPDATA", "discord", "GPUCache"), "cache do Discord"),
              ("cache_vscode", ("APPDATA", "Code", "Cache"), "cache do Visual Studio Code"),
              ("cache_vscode", ("APPDATA", "Code", "CachedData"), "cache do Visual Studio Code"),
              ("cache_vscode", ("APPDATA", "Code", "GPUCache"), "cache do Visual Studio Code"),
              ("cache_teams", ("APPDATA", "Microsoft", "Teams", "Cache"), "cache do Microsoft Teams (clássico)"))
    for chave, partes, motivo in caches:
        add(chave, "Cache de aplicativos", _junta(env, partes), SEGURO, motivo)
    add("cache_spotify", "Cache de aplicativos", _junta(env, ("LOCALAPPDATA", "Spotify", "Data")), REVISAO,
        "cache do Spotify: pode incluir músicas guardadas para ouvir offline", marcado=False)
    add("miniaturas", "Cache de aplicativos", _junta(env, ("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")),
        REVISAO, "cache de miniaturas do Explorador: o Windows recria (as miniaturas demoram a voltar)",
        recursivo=False, prefixos=("thumbcache_",), marcado=False)

    # logs antigos e relatórios de falha
    add("crashdumps", "Logs e relatórios de falha", _junta(env, ("LOCALAPPDATA", "CrashDumps")), REVISAO,
        "relatório de falha de um programa: útil só para suporte técnico", marcado=False)
    add("wer", "Logs e relatórios de falha",
        _junta(env, ("LOCALAPPDATA", "Microsoft", "Windows", "WER", "ReportArchive")), SEGURO,
        "relatório de erro do Windows já enviado ou arquivado")
    add("wer_fila", "Logs e relatórios de falha",
        _junta(env, ("LOCALAPPDATA", "Microsoft", "Windows", "WER", "ReportQueue")), REVISAO,
        "relatório de erro do Windows ainda não enviado", marcado=False)
    locais.extend(extras)

    vistos: set = set()
    unicos = []
    for loc in locais:
        k = (_norm(loc.caminho), loc.prefixos, loc.padroes)
        if k in vistos:
            continue
        vistos.add(k)
        unicos.append(loc)
    return unicos


def classificar(loc: LocalLimpeza, caminho: str, nome: str, s: os.stat_result, agora: float,
                uso: str = "") -> tuple:
    """(classe, motivo) de um arquivo encontrado num local de limpeza. A ordem importa: o que protege vem antes."""
    nl = nome.lower()
    if e_sistema(s) or nl in _NOMES_NUNCA:
        return NAO_REMOVER, "arquivo de sistema do Windows"
    if uso == "em_uso":
        return NAO_REMOVER, "em uso por um programa aberto agora (feche o programa e analise de novo)"
    if uso == "sem_permissao":
        return NAO_REMOVER, "sem permissão para apagar (seria preciso ser administrador)"
    if loc.classe == NAO_REMOVER:
        return NAO_REMOVER, loc.motivo
    cat = categoria_por_extensao(nome)
    idade = (agora - s.st_mtime) / DIA
    if loc.chave.startswith(("temp_", "windows_update")) or loc.chave == "instalacoes":
        if cat in _CATS_PESSOAIS:
            return REVISAO, ("%s dentro de uma pasta temporária: pode ser um anexo ou documento que você abriu e ainda "
                             "quer" % _SINGULAR[cat])
        if cat == "executaveis" or extensao(nome) in (".dll", ".sys"):
            if loc.classe == SEGURO and idade < 7:
                return REVISAO, "programa ou instalador recente numa pasta temporária: uma instalação pode estar usando"
    if loc.idade_revisao and idade < loc.idade_revisao:
        return REVISAO, ("modificado há menos de %s: pode ser de um programa aberto ou de uma instalação em andamento"
                         % ("24 horas" if loc.idade_revisao <= 1 else "%d dias" % loc.idade_revisao))
    return loc.classe, loc.motivo


def analisar_limpeza(locais: Iterable, cancelar: Optional[Cancelamento] = None, progresso: ProgressoFn = None,
                     env: Optional[Mapping] = None, home: Optional[Path] = None,
                     agora: Optional[float] = None) -> ResultadoLimpeza:
    """Lê os locais (só leitura: nada é apagado aqui) e classifica cada arquivo. Locais dentro de pastas protegidas
    são pulados por completo."""
    t0 = time.monotonic()
    agora = time.time() if agora is None else agora
    av = _Avisador(progresso)
    itens: list = []
    situacao: list = []
    sem_acesso: list = []
    vistos: set = set()
    total_bytes = 0
    locais = list(locais)
    for n_loc, loc in enumerate(locais):
        if _cancelado(cancelar):
            break
        raiz = loc.caminho
        if caminho_protegido(raiz, env, home):
            situacao.append((loc.grupo, str(raiz), "pasta protegida: não analisada"))
            continue
        try:
            if not raiz.is_dir():
                continue                                    # o programa não está instalado: nem aparece
        except OSError as e:
            situacao.append((loc.grupo, str(raiz), motivo_erro(e)))
            continue
        try:
            os.listdir(raiz)
        except OSError as e:
            situacao.append((loc.grupo, str(raiz), motivo_erro(e)))
            sem_acesso.append((str(raiz), motivo_erro(e)))
            continue
        antes = len(itens)
        for caminho, nome, s in percorrer(raiz, cancelar, loc.recursivo,
                                          ao_erro=lambda c, m: sem_acesso.append((c, m))):
            nl = nome.lower()
            if loc.prefixos and not nl.startswith(loc.prefixos):
                continue
            if loc.padroes and not nl.endswith(loc.padroes):
                continue
            if loc.idade_minima and (agora - s.st_mtime) / DIA < loc.idade_minima:
                continue
            chave = _norm(caminho)
            if chave in vistos:
                continue
            vistos.add(chave)
            uso = estado_uso(caminho)
            if uso == "sumiu":
                continue
            classe, motivo = classificar(loc, caminho, nome, s, agora, uso)
            tam = int(s.st_size)
            itens.append(ItemLimpeza(caminho, nome, tam, float(s.st_mtime), classe, motivo, loc.grupo, loc.chave,
                                     str(raiz), marcado=(classe == SEGURO and loc.marcado)))
            total_bytes += tam
            av(local=loc.grupo, pasta=str(raiz), arquivos=len(itens), bytes=total_bytes, etapa=n_loc + 1,
               etapas=len(locais))
        situacao.append((loc.grupo, str(raiz), "ok (%d arquivo%s)" % (len(itens) - antes,
                                                                       "" if len(itens) - antes == 1 else "s")))
    av(True, local="", arquivos=len(itens), bytes=total_bytes, etapa=len(locais), etapas=len(locais), fim=True)
    ordem = {SEGURO: 0, REVISAO: 1, NAO_REMOVER: 2}
    itens.sort(key=lambda i: (ordem[i.classe], i.grupo, -i.tamanho))
    return ResultadoLimpeza(itens, situacao, sem_acesso, _cancelado(cancelar), time.monotonic() - t0)


def _remover_subpastas_vazias(pastas: Iterable, raiz: str) -> int:
    """Remove as pastas que ficaram vazias, subindo até (sem incluir) a raiz do local. os.rmdir falha se houver
    qualquer coisa dentro: nunca apaga conteúdo."""
    removidas = 0
    raiz_n = _norm(raiz)
    for p in sorted(set(pastas), key=lambda x: -len(x)):
        atual = p
        while dentro_de(atual, raiz) and _norm(atual) != raiz_n:
            try:
                os.rmdir(atual)
                removidas += 1
            except OSError:
                break
            atual = os.path.dirname(atual)
    return removidas


def executar_limpeza(itens: Iterable, cancelar: Optional[Cancelamento] = None, progresso: ProgressoFn = None,
                     env: Optional[Mapping] = None, home: Optional[Path] = None) -> ResultadoOperacao:
    """Remove os itens CONFIRMADOS pela pessoa. "Seguro para limpeza": apagado de vez (são temporários e caches).
    "Requer revisão": vai para a Lixeira (dá para recuperar); se a unidade não tem Lixeira, fica onde está.
    "Não remover": recusado sempre, mesmo se vier na lista."""
    t0 = time.monotonic()
    itens = list(itens)
    r = ResultadoOperacao("limpeza", total=len(itens))
    av = _Avisador(progresso)
    esvaziadas: dict = {}
    for k, it in enumerate(itens):
        if _cancelado(cancelar):
            r.cancelado = True
            r.ignorados += [(i.caminho, "cancelado antes de chegar a vez") for i in itens[k:]]
            break
        av(feitos=k, total=len(itens), atual=it.nome, removidos=r.processados, liberado=r.liberado,
           ignorados=len(r.ignorados), erros=len(r.erros))
        motivo = _pode_apagar(it, env, home)
        if motivo:
            r.ignorados.append((it.caminho, motivo))
            continue
        try:
            if it.classe == REVISAO:
                enviar_lixeira(it.caminho)
            else:
                os.unlink(it.caminho)
        except FileNotFoundError:
            r.ignorados.append((it.caminho, "já não existia"))
            continue
        except PermissionError:
            r.ignorados.append((it.caminho, "sem permissão (ou em uso): não foi apagado"))
            continue
        except OSError as e:
            if getattr(e, "winerror", None) in (_ERROR_SHARING_VIOLATION, _ERROR_LOCK_VIOLATION):
                r.ignorados.append((it.caminho, "em uso por outro programa"))
            elif e.errno == errno.EXDEV:
                r.ignorados.append((it.caminho, motivo_erro(e)))
            else:
                r.erros.append((it.caminho, motivo_erro(e)))
            continue
        r.processados += 1
        r.liberado += it.tamanho
        r.feitos.append((it.caminho, "lixeira" if it.classe == REVISAO else ""))
        esvaziadas.setdefault(it.raiz, set()).add(os.path.dirname(it.caminho))
    for raiz, pastas in esvaziadas.items():
        _remover_subpastas_vazias(pastas, raiz)
    av(True, feitos=len(itens), total=len(itens), atual="", removidos=r.processados, liberado=r.liberado,
       ignorados=len(r.ignorados), erros=len(r.erros), fim=True)
    r.duracao = time.monotonic() - t0
    return r


def _pode_apagar(it: ItemLimpeza, env: Optional[Mapping], home: Optional[Path]) -> str:
    """'' se pode apagar; senão o motivo. Confere tudo DE NOVO, no momento de apagar."""
    if it.classe == NAO_REMOVER:
        return "classificado como “Não remover”"
    if it.classe not in (SEGURO, REVISAO):
        return "classificação desconhecida"
    if not it.raiz or not dentro_de(it.caminho, it.raiz) or _norm(it.caminho) == _norm(it.raiz):
        return "fora do local analisado"
    if caminho_protegido(it.caminho, env, home):
        return "pasta protegida"
    try:
        s = os.stat(it.caminho, follow_symlinks=False)
    except FileNotFoundError:
        return "já não existia"
    except OSError as e:
        return motivo_erro(e)
    if not st_mod.S_ISREG(s.st_mode) or e_ligacao(s):
        return "não é um arquivo comum"
    if e_sistema(s) or os.path.basename(it.caminho).lower() in _NOMES_NUNCA:
        return "arquivo de sistema do Windows"
    if int(s.st_size) != it.tamanho or abs(float(s.st_mtime) - it.mtime) > 2.0:
        return "mudou depois da análise (analise de novo)"
    uso = estado_uso(it.caminho)
    if uso == "em_uso":
        return "em uso por outro programa"
    if uso == "sem_permissao":
        return "sem permissão (o System Care não pede administrador)"
    return ""


# ----------------------------------------------------------------------------------------------------------------------
# Organizador
# ----------------------------------------------------------------------------------------------------------------------
@dataclass
class ArquivoInfo:
    caminho: str
    nome: str
    ext: str
    tamanho: int
    mtime: float
    categoria: str


@dataclass
class ResultadoPasta:
    pasta: str
    arquivos: list
    ignorados: list                 # [(caminho, motivo)]
    cancelado: bool = False
    duracao: float = 0.0

    def por_categoria(self) -> dict:
        d: dict = {c: [0, 0] for c in CATEGORIAS}
        for a in self.arquivos:
            d[a.categoria][0] += 1
            d[a.categoria][1] += a.tamanho
        return d


def analisar_pasta(pasta: Any, recursivo: bool = False, cancelar: Optional[Cancelamento] = None,
                   progresso: ProgressoFn = None, env: Optional[Mapping] = None, home: Optional[Path] = None,
                   ignorar_pastas_categoria: Optional[Any] = None) -> ResultadoPasta:
    """Lista e classifica por tipo os arquivos de uma pasta (só leitura). Arquivos de sistema e ocultos ficam de fora
    (com o motivo). `ignorar_pastas_categoria`: pasta de destino da organização; com subpastas, as pastas de
    categoria que já estão nela não são reanalisadas."""
    t0 = time.monotonic()
    motivo = pasta_proibida_para_organizar(pasta, env, home)
    if motivo:
        raise ErroSystemCare("Esta pasta não pode ser organizada: %s." % motivo)
    av = _Avisador(progresso)
    arquivos: list = []
    ignorados: list = []
    pular = None
    if recursivo and ignorar_pastas_categoria:
        destinos = {_norm(Path(ignorar_pastas_categoria) / n) for n in PASTAS_CATEGORIA.values()}
        pular = lambda d: _norm(d) in destinos          # noqa: E731
    for caminho, nome, s in percorrer(pasta, cancelar, recursivo, ao_erro=lambda c, m: ignorados.append((c, m)),
                                      pular_dir=pular):
        if e_sistema(s) or nome.lower() in _NOMES_NUNCA:
            ignorados.append((caminho, "arquivo de sistema do Windows"))
            continue
        if e_oculto(nome, s):
            ignorados.append((caminho, "arquivo oculto"))
            continue
        arquivos.append(ArquivoInfo(caminho, nome, extensao(nome), int(s.st_size), float(s.st_mtime),
                                    categoria_por_extensao(nome)))
        av(arquivos=len(arquivos), atual=nome)
    av(True, arquivos=len(arquivos), atual="", fim=True)
    return ResultadoPasta(str(pasta), arquivos, ignorados, _cancelado(cancelar), time.monotonic() - t0)


RENOMEAR, PULAR, SUBSTITUIR = "renomear", "pular", "substituir"


@dataclass
class Movimento:
    origem: str
    destino: str
    categoria: str
    tamanho: int
    mtime: float
    situacao: str                  # "mover" | "renomeado" | "pular" | "substituir" | "no_lugar"
    nota: str = ""


_INVALIDOS_WIN = set('<>:"/\\|?*') | {chr(i) for i in range(32)}
_RESERVADOS_WIN = ({"CON", "PRN", "AUX", "NUL"} | {"COM%d" % i for i in range(1, 10)}
                   | {"LPT%d" % i for i in range(1, 10)})


def nome_valido(nome: str) -> bool:
    if not nome or nome in (".", "..") or any(c in _INVALIDOS_WIN for c in nome):
        return False
    if nome.endswith((" ", ".")):
        return False
    return os.path.splitext(nome)[0].upper() not in _RESERVADOS_WIN


def nome_livre(pasta: str, nome: str, reservados: set) -> str:
    """'foto.jpg' -> 'foto (2).jpg', 'foto (3).jpg'... até um nome que não existe no disco nem no plano."""
    raiz, ext = os.path.splitext(nome)
    k = 2
    while True:
        cand = "%s (%d)%s" % (raiz, k, ext)
        alvo = os.path.join(pasta, cand)
        if _norm(alvo) not in reservados and not os.path.lexists(alvo):
            return cand
        k += 1


def planejar_organizacao(arquivos: Iterable, destino_base: Any, politica: str = RENOMEAR,
                         pastas: Optional[dict] = None) -> list:
    """Prévia: para onde cada arquivo iria (pasta da categoria dentro de destino_base) e o que acontece com os
    conflitos. Nada é movido aqui. Conflitos:
      - já existe um arquivo com o mesmo nome no destino: politica RENOMEAR -> 'foto (2).jpg'; PULAR -> fica onde
        está; SUBSTITUIR -> só com autorização explícita na execução (o arquivo antigo vai para a Lixeira);
      - dois arquivos do lote com o mesmo nome indo para a mesma pasta: o segundo é renomeado (ou pulado com PULAR);
        um arquivo do lote nunca substitui outro do lote."""
    if politica not in (RENOMEAR, PULAR, SUBSTITUIR):
        raise ValueError("política desconhecida: %r" % politica)
    pastas = pastas or PASTAS_CATEGORIA
    base = str(destino_base)
    reservados: set = set()
    plano: list = []
    for a in arquivos:
        pasta_dest = os.path.join(base, pastas.get(a.categoria, "Outros"))
        alvo = os.path.join(pasta_dest, a.nome)
        if _norm(alvo) == _norm(a.caminho):
            plano.append(Movimento(a.caminho, alvo, a.categoria, a.tamanho, a.mtime, "no_lugar", "já está na pasta"))
            continue
        if not nome_valido(a.nome):
            plano.append(Movimento(a.caminho, alvo, a.categoria, a.tamanho, a.mtime, "pular",
                                   "nome inválido no Windows"))
            continue
        situacao, nota = "mover", ""
        if _norm(alvo) in reservados:
            if politica == PULAR:
                situacao, nota = "pular", "outro arquivo do lote vai com o mesmo nome"
            else:
                novo = nome_livre(pasta_dest, a.nome, reservados)
                alvo, situacao = os.path.join(pasta_dest, novo), "renomeado"
                nota = "outro arquivo do lote tem o mesmo nome"
        elif os.path.lexists(alvo):
            if politica == RENOMEAR:
                novo = nome_livre(pasta_dest, a.nome, reservados)
                alvo, situacao, nota = os.path.join(pasta_dest, novo), "renomeado", "já existe um arquivo com este nome"
            elif politica == PULAR:
                situacao, nota = "pular", "já existe um arquivo com este nome no destino"
            else:
                situacao, nota = "substituir", "substitui o arquivo que já está no destino (ele vai para a Lixeira)"
        if situacao != "pular":
            reservados.add(_norm(alvo))
        plano.append(Movimento(a.caminho, alvo, a.categoria, a.tamanho, a.mtime, situacao, nota))
    return plano


def mover_sem_sobrescrever(origem: str, destino: str) -> None:
    """Move sem nunca sobrescrever: se o destino já existe, levanta FileExistsError. Na mesma unidade é uma
    renomeação (Windows: os.rename recusa destino existente; Linux: link + unlink). Entre unidades: cópia para um
    arquivo criado em modo exclusivo, conferência do tamanho e só então a origem é apagada; se algo falhar, a cópia
    parcial é removida e a origem fica intacta."""
    if os.path.lexists(destino):
        raise FileExistsError(errno.EEXIST, "já existe", destino)
    try:
        if WINDOWS:
            os.rename(origem, destino)
        else:
            os.link(origem, destino)
            try:
                os.unlink(origem)
            except OSError:
                os.unlink(destino)
                raise
        return
    except FileExistsError:
        raise
    except OSError as e:
        if e.errno not in (errno.EXDEV, errno.EPERM, errno.ENOTSUP, errno.EOPNOTSUPP, errno.EMLINK) and \
                getattr(e, "winerror", None) != 17:
            raise
    fd = os.open(destino, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o666)
    ok = False
    try:
        with os.fdopen(fd, "wb") as fo, open(origem, "rb") as fi:
            shutil.copyfileobj(fi, fo, 1024 * 1024)
        shutil.copystat(origem, destino)
        if os.path.getsize(destino) != os.path.getsize(origem):
            raise OSError(errno.EIO, "a cópia ficou com tamanho diferente")
        ok = True
    finally:
        if not ok:
            try:
                os.unlink(destino)
            except OSError:
                pass
    os.unlink(origem)


def executar_organizacao(plano: Iterable, destino_base: Any, autorizar_substituicao: bool = False,
                         cancelar: Optional[Cancelamento] = None, progresso: ProgressoFn = None) -> ResultadoOperacao:
    """Move os arquivos da prévia CONFIRMADA. Cada arquivo é conferido de novo antes de mover (existe, mesmo tamanho
    e data, não está em uso). Nunca sobrescreve: um destino que apareceu depois da prévia é renomeado (ou pulado se
    a política era pular). 'substituir' só acontece com autorizar_substituicao=True, e o arquivo antigo vai para a
    Lixeira antes (sem Lixeira na unidade: não substitui)."""
    t0 = time.monotonic()
    plano = list(plano)
    r = ResultadoOperacao("organizacao", total=len(plano))
    av = _Avisador(progresso)
    base = str(destino_base)
    reservados = {_norm(m.destino) for m in plano if m.situacao in ("mover", "renomeado", "substituir")}
    for k, m in enumerate(plano):
        if _cancelado(cancelar):
            r.cancelado = True
            r.ignorados += [(x.origem, "cancelado antes de chegar a vez") for x in plano[k:]
                            if x.situacao not in ("no_lugar", "pular")]
            break
        av(feitos=k, total=len(plano), atual=os.path.basename(m.origem), movidos=r.processados,
           ignorados=len(r.ignorados), erros=len(r.erros))
        if m.situacao in ("no_lugar", "pular"):
            if m.situacao == "pular":
                r.ignorados.append((m.origem, m.nota or "pulado"))
            continue
        if not dentro_de(m.destino, base):
            r.ignorados.append((m.origem, "destino fora da pasta escolhida"))
            continue
        try:
            s = os.stat(m.origem, follow_symlinks=False)
        except FileNotFoundError:
            r.ignorados.append((m.origem, "não existe mais (foi movido ou apagado)"))
            continue
        except OSError as e:
            r.ignorados.append((m.origem, motivo_erro(e)))
            continue
        if int(s.st_size) != m.tamanho or abs(float(s.st_mtime) - m.mtime) > 2.0:
            r.ignorados.append((m.origem, "mudou depois da análise (analise de novo)"))
            continue
        uso = estado_uso(m.origem)
        if uso == "em_uso":
            r.ignorados.append((m.origem, "em uso por outro programa"))
            continue
        if uso == "sem_permissao":
            r.ignorados.append((m.origem, "sem permissão para mover"))
            continue
        pasta_dest = os.path.dirname(m.destino)
        try:
            os.makedirs(pasta_dest, exist_ok=True)
        except OSError as e:
            r.erros.append((m.origem, "não consegui criar a pasta %s: %s" % (pasta_dest, motivo_erro(e))))
            continue
        destino = m.destino
        if os.path.lexists(destino):
            if m.situacao == "substituir":
                if not autorizar_substituicao:
                    r.ignorados.append((m.origem, "já existe no destino e a substituição não foi autorizada"))
                    continue
                if estado_uso(destino) == "em_uso":
                    r.ignorados.append((m.origem, "o arquivo do destino está em uso"))
                    continue
                try:
                    enviar_lixeira(destino)
                except OSError as e:
                    r.ignorados.append((m.origem, "não substituí: o arquivo do destino não foi para a Lixeira (%s)"
                                        % motivo_erro(e)))
                    continue
            elif m.situacao in ("mover", "renomeado"):
                novo = nome_livre(pasta_dest, os.path.basename(destino), reservados)
                destino = os.path.join(pasta_dest, novo)
                reservados.add(_norm(destino))
        try:
            mover_sem_sobrescrever(m.origem, destino)
        except FileExistsError:
            r.ignorados.append((m.origem, "apareceu um arquivo com o mesmo nome no destino: nada foi sobrescrito"))
            continue
        except PermissionError:
            r.ignorados.append((m.origem, "sem permissão (ou em uso): ficou onde estava"))
            continue
        except OSError as e:
            if getattr(e, "winerror", None) in (_ERROR_SHARING_VIOLATION, _ERROR_LOCK_VIOLATION):
                r.ignorados.append((m.origem, "em uso por outro programa"))
            else:
                r.erros.append((m.origem, motivo_erro(e)))
            continue
        r.processados += 1
        r.feitos.append((m.origem, destino))
    av(True, feitos=len(plano), total=len(plano), atual="", movidos=r.processados, ignorados=len(r.ignorados),
       erros=len(r.erros), fim=True)
    r.duracao = time.monotonic() - t0
    return r


# ----------------------------------------------------------------------------------------------------------------------
# Duplicados (SHA-256)
# ----------------------------------------------------------------------------------------------------------------------
BLOCO_HASH = 1024 * 1024
BLOCO_PREVIA = 64 * 1024


def sha256_arquivo(caminho: str, cancelar: Optional[Cancelamento] = None, limite: Optional[int] = None) -> str:
    """SHA-256 em blocos de 1 MB (memória constante). `limite`: só os primeiros N bytes (pré-filtro)."""
    h = hashlib.sha256()
    lido = 0
    with open(caminho, "rb") as f:
        while True:
            if _cancelado(cancelar):
                raise InterruptedError("cancelado")
            n = BLOCO_HASH if limite is None else min(BLOCO_HASH, limite - lido)
            if n <= 0:
                break
            b = f.read(n)
            if not b:
                break
            h.update(b)
            lido += len(b)
    return h.hexdigest()


@dataclass
class GrupoDuplicado:
    hash: str
    tamanho: int
    arquivos: list                  # [ArquivoInfo] (2 ou mais, conteúdo idêntico)

    @property
    def copias(self) -> int:
        return len(self.arquivos)

    @property
    def recuperavel(self) -> int:
        return self.tamanho * (len(self.arquivos) - 1)


@dataclass
class ResultadoDuplicados:
    pastas: list
    grupos: list
    analisados: int
    comparados: int                 # arquivos que tiveram o SHA-256 calculado
    ignorados: list
    cancelado: bool = False
    duracao: float = 0.0

    @property
    def recuperavel(self) -> int:
        return sum(g.recuperavel for g in self.grupos)


def buscar_duplicados(pastas: Iterable, cancelar: Optional[Cancelamento] = None, progresso: ProgressoFn = None,
                      tamanho_minimo: int = 1) -> ResultadoDuplicados:
    """Arquivos com CONTEÚDO idêntico. O tamanho só serve para descartar quem não pode ser igual (tamanhos diferentes
    nunca são iguais); dentro de cada tamanho, um SHA-256 dos primeiros 64 KB separa os candidatos e o SHA-256 do
    arquivo inteiro decide. Mesmo nome não conta nada. Ligações físicas (o mesmo arquivo em dois lugares) não são
    duplicados: apagar uma não libera espaço. Arquivos que estão só na nuvem (OneDrive) não são lidos."""
    t0 = time.monotonic()
    av = _Avisador(progresso)
    raizes: list = []
    for p in pastas:
        p = str(p)
        if any(dentro_de(p, r) for r in raizes):
            continue
        raizes = [r for r in raizes if not dentro_de(r, p)] + [p]
    por_tamanho: dict = {}
    ignorados: list = []
    inodes: set = set()
    analisados = 0
    for raiz in raizes:
        for caminho, nome, s in percorrer(raiz, cancelar, True, ao_erro=lambda c, m: ignorados.append((c, m))):
            analisados += 1
            if e_sistema(s):
                continue
            if s.st_size < max(1, tamanho_minimo):
                continue
            if so_na_nuvem(s):
                ignorados.append((caminho, "está só na nuvem (não foi baixado para não gastar internet)"))
                continue
            ino = (s.st_dev, s.st_ino)
            if s.st_ino and ino in inodes:
                continue
            inodes.add(ino)
            por_tamanho.setdefault(int(s.st_size), []).append(
                ArquivoInfo(caminho, nome, extensao(nome), int(s.st_size), float(s.st_mtime),
                            categoria_por_extensao(nome)))
            av(etapa="listando", arquivos=analisados, atual=nome)
    inodes.clear()
    candidatos = [lst for lst in por_tamanho.values() if len(lst) > 1]
    por_tamanho.clear()
    total_cand = sum(len(lst) for lst in candidatos)
    feitos = 0
    comparados = 0
    grupos: list = []
    for lst in candidatos:
        if _cancelado(cancelar):
            break
        tam = lst[0].tamanho
        sub: dict = {}
        if tam > BLOCO_PREVIA:
            for a in lst:
                feitos += 1
                try:
                    sub.setdefault(sha256_arquivo(a.caminho, cancelar, BLOCO_PREVIA), []).append(a)
                except InterruptedError:
                    break
                except OSError as e:
                    ignorados.append((a.caminho, motivo_erro(e)))
                av(etapa="comparando", feitos=feitos, total=total_cand, atual=a.nome)
            listas = [x for x in sub.values() if len(x) > 1]
        else:
            feitos += len(lst)
            listas = [lst]
        for l2 in listas:
            final: dict = {}
            for a in l2:
                if _cancelado(cancelar):
                    break
                try:
                    final.setdefault(sha256_arquivo(a.caminho, cancelar), []).append(a)
                    comparados += 1
                except InterruptedError:
                    break
                except OSError as e:
                    ignorados.append((a.caminho, motivo_erro(e)))
                av(etapa="comparando", feitos=feitos, total=total_cand, atual=a.nome)
            for h, l3 in final.items():
                if len(l3) > 1:
                    grupos.append(GrupoDuplicado(h, tam, sorted(l3, key=lambda x: (x.mtime, x.caminho))))
    grupos.sort(key=lambda g: -g.recuperavel)
    av(True, etapa="fim", feitos=total_cand, total=total_cand, atual="", fim=True)
    return ResultadoDuplicados(raizes, grupos, analisados, comparados, ignorados, _cancelado(cancelar),
                               time.monotonic() - t0)


def remover_duplicados(selecao: Iterable, definitivo: bool = False, cancelar: Optional[Cancelamento] = None,
                       progresso: ProgressoFn = None) -> ResultadoOperacao:
    """selecao: [(GrupoDuplicado, [ArquivoInfo a remover])]. Regras: ao menos uma cópia de cada grupo fica (um grupo
    com todas as cópias marcadas é recusado inteiro); antes de remover, a cópia que fica é conferida (existe e tem o
    mesmo SHA-256) e cada cópia a remover tem o SHA-256 recalculado; arquivos em uso ficam. Padrão: Lixeira.
    definitivo=True (só com confirmação da pessoa): apaga de vez."""
    t0 = time.monotonic()
    selecao = [(g, list(rem)) for g, rem in selecao]
    total = sum(len(rem) for _g, rem in selecao)
    r = ResultadoOperacao("duplicados", total=total)
    av = _Avisador(progresso)
    feitos = 0
    for g, rem in selecao:
        if _cancelado(cancelar):
            r.cancelado = True
            break
        marcados = {_norm(a.caminho) for a in rem}
        fica = [a for a in g.arquivos if _norm(a.caminho) not in marcados]
        if not fica:
            r.ignorados += [(a.caminho, "todas as cópias estavam marcadas: pelo menos uma sempre fica") for a in rem]
            feitos += len(rem)
            continue
        if any(_norm(a.caminho) not in {_norm(x.caminho) for x in g.arquivos} for a in rem):
            r.ignorados += [(a.caminho, "não faz parte deste grupo de duplicados") for a in rem]
            feitos += len(rem)
            continue
        referencia = None
        for a in fica:
            try:
                if sha256_arquivo(a.caminho, cancelar) == g.hash:
                    referencia = a
                    break
            except (OSError, InterruptedError):
                continue
        if referencia is None:
            r.ignorados += [(a.caminho, "a cópia que ficaria mudou ou sumiu: nada removido deste grupo") for a in rem]
            feitos += len(rem)
            continue
        for a in rem:
            if _cancelado(cancelar):
                r.cancelado = True
                break
            feitos += 1
            av(feitos=feitos, total=total, atual=a.nome, removidos=r.processados, liberado=r.liberado)
            try:
                s = os.stat(a.caminho, follow_symlinks=False)
                if e_ligacao(s) or not st_mod.S_ISREG(s.st_mode):
                    r.ignorados.append((a.caminho, "não é um arquivo comum"))
                    continue
                if sha256_arquivo(a.caminho, cancelar) != g.hash:
                    r.ignorados.append((a.caminho, "o conteúdo mudou depois da análise"))
                    continue
            except InterruptedError:
                r.cancelado = True
                break
            except FileNotFoundError:
                r.ignorados.append((a.caminho, "não existe mais"))
                continue
            except OSError as e:
                r.ignorados.append((a.caminho, motivo_erro(e)))
                continue
            uso = estado_uso(a.caminho)
            if uso:
                r.ignorados.append((a.caminho, "em uso por outro programa" if uso == "em_uso" else "sem permissão"))
                continue
            try:
                if definitivo:
                    os.unlink(a.caminho)
                else:
                    enviar_lixeira(a.caminho)
            except PermissionError:
                r.ignorados.append((a.caminho, "sem permissão (ou em uso)"))
                continue
            except OSError as e:
                if e.errno == errno.EXDEV:
                    r.ignorados.append((a.caminho, motivo_erro(e)))
                else:
                    r.erros.append((a.caminho, motivo_erro(e)))
                continue
            r.processados += 1
            r.liberado += g.tamanho
            r.feitos.append((a.caminho, "" if definitivo else "lixeira"))
    av(True, feitos=total, total=total, atual="", removidos=r.processados, liberado=r.liberado, fim=True)
    r.duracao = time.monotonic() - t0
    return r


# ----------------------------------------------------------------------------------------------------------------------
# Armazenamento
# ----------------------------------------------------------------------------------------------------------------------
@dataclass
class ResultadoArmazenamento:
    raiz: str
    por_categoria: dict             # categoria -> [bytes, quantidade]
    total_bytes: int
    total_arquivos: int
    maiores_pastas: list            # [(caminho, bytes)] subpastas diretas da raiz, da maior para a menor
    maiores_arquivos: list          # [(bytes, caminho)]
    sem_acesso: int
    disco: Optional[tuple] = None   # (total, usado, livre) da unidade
    cancelado: bool = False
    duracao: float = 0.0


def analisar_armazenamento(raiz: Any, cancelar: Optional[Cancelamento] = None, progresso: ProgressoFn = None,
                           pastas_temp: Iterable = (), top: int = 25) -> ResultadoArmazenamento:
    """Soma o tamanho dos arquivos de uma unidade ou pasta por categoria (só leitura, sem seguir ligações). O uso de
    memória não cresce com o número de arquivos: só os totais, as subpastas diretas e os N maiores arquivos."""
    t0 = time.monotonic()
    raiz = str(raiz)
    av = _Avisador(progresso, 0.2)
    cats = {c: [0, 0] for c in CATEGORIAS_ARMAZENAMENTO}
    temps = [str(p) for p in pastas_temp if p]
    por_filho: dict = {}
    maiores: list = []
    total_b = total_n = sem_acesso = 0
    raiz_n = _norm(raiz)
    pref = raiz_n if raiz_n.endswith(os.sep) else raiz_n + os.sep

    def erro(_c: str, _m: str) -> None:
        nonlocal sem_acesso
        sem_acesso += 1

    for caminho, nome, s in percorrer(raiz, cancelar, True, ao_erro=erro):
        tam = int(s.st_size)
        temporario = any(dentro_de(caminho, t) for t in temps) if temps else False
        c = categoria_armazenamento(nome, temporario)
        cats[c][0] += tam
        cats[c][1] += 1
        total_b += tam
        total_n += 1
        cn = _norm(caminho)
        resto = cn[len(pref):] if cn.startswith(pref) else ""
        if os.sep in resto:
            filho = resto.split(os.sep, 1)[0]
            por_filho[filho] = por_filho.get(filho, 0) + tam
        if len(maiores) < top:
            heapq.heappush(maiores, (tam, caminho))
        elif tam > maiores[0][0]:
            heapq.heapreplace(maiores, (tam, caminho))
        av(arquivos=total_n, bytes=total_b, atual=caminho)
    disco = None
    try:
        u = shutil.disk_usage(raiz)
        disco = (int(u.total), int(u.used), int(u.free))
    except OSError:
        pass
    pastas = sorted(((os.path.join(raiz, k), v) for k, v in por_filho.items()), key=lambda x: -x[1])[:top]
    av(True, arquivos=total_n, bytes=total_b, atual="", fim=True)
    return ResultadoArmazenamento(raiz, cats, total_b, total_n, pastas, sorted(maiores, reverse=True), sem_acesso,
                                  disco, _cancelado(cancelar), time.monotonic() - t0)


# ----------------------------------------------------------------------------------------------------------------------
# Histórico (só metadados)
# ----------------------------------------------------------------------------------------------------------------------
TIPOS_HISTORICO = {"limpeza_analise": "Análise de limpeza", "limpeza": "Limpeza",
                   "organizacao_analise": "Análise de pasta", "organizacao": "Organização",
                   "duplicados_analise": "Busca de duplicados", "duplicados": "Remoção de duplicados",
                   "armazenamento": "Análise de armazenamento"}
MAX_DETALHES = 60


class Historico:
    """Histórico das operações do System Care num JSON (gravação atômica). Guarda data, tipo, local, contagens,
    espaço liberado e os motivos dos itens ignorados ou com erro (nome e motivo): nunca o conteúdo dos arquivos."""

    def __init__(self, arquivo: Any, limite: int = 300) -> None:
        self.arquivo = Path(arquivo)
        self.limite = limite
        self._trava = threading.Lock()
        self._itens: Optional[list] = None

    def _ler(self) -> list:
        if self._itens is None:
            try:
                d = json.loads(self.arquivo.read_text(encoding="utf-8"))
                self._itens = [x for x in d.get("itens", []) if isinstance(x, dict)] if isinstance(d, dict) else []
            except (OSError, ValueError):
                self._itens = []
        return self._itens

    def listar(self) -> list:
        """Do mais recente para o mais antigo."""
        with self._trava:
            return list(reversed(self._ler()))

    def ultimo(self, tipos: Optional[Iterable] = None) -> Optional[dict]:
        tipos = set(tipos) if tipos else None
        for x in self.listar():
            if tipos is None or x.get("tipo") in tipos:
                return x
        return None

    def adicionar(self, tipo: str, local: str = "", encontrados: int = 0, processados: int = 0, liberado: int = 0,
                  ignorados: Iterable = (), erros: Iterable = (), cancelado: bool = False, duracao: float = 0.0,
                  extra: Optional[dict] = None) -> dict:
        ignorados, erros = list(ignorados), list(erros)
        reg = {"id": uuid.uuid4().hex[:12], "quando": datetime.now().isoformat(timespec="seconds"), "tipo": tipo,
               "local": str(local), "encontrados": int(encontrados), "processados": int(processados),
               "liberado": int(liberado), "ignorados": len(ignorados), "erros": len(erros),
               "cancelado": bool(cancelado), "duracao": round(float(duracao), 2),
               "detalhes": [{"arquivo": str(c), "motivo": str(m), "erro": False} for c, m in ignorados[:MAX_DETALHES]]
               + [{"arquivo": str(c), "motivo": str(m), "erro": True} for c, m in erros[:MAX_DETALHES]]}
        if extra:
            reg["extra"] = {k: v for k, v in extra.items() if isinstance(v, (int, float, str, bool))}
        with self._trava:
            itens = self._ler()
            itens.append(reg)
            del itens[:-self.limite]
            self._gravar(itens)
        return reg

    def limpar(self) -> None:
        with self._trava:
            self._itens = []
            self._gravar([])

    def _gravar(self, itens: list) -> None:
        try:
            self.arquivo.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.arquivo.with_name(self.arquivo.name + ".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"versao": VERSAO_SYSTEMCARE, "itens": itens}, f, ensure_ascii=False, indent=1)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.arquivo)
        except OSError:
            pass


# ----------------------------------------------------------------------------------------------------------------------
# Resumo para a tela principal
# ----------------------------------------------------------------------------------------------------------------------
def contar_organizaveis(pasta: Any, cancelar: Optional[Cancelamento] = None) -> tuple:
    """(quantidade, bytes) de arquivos soltos no primeiro nível da pasta que o Organizador moveria (sem os ocultos e
    os de sistema). Só leitura."""
    n = b = 0
    for _c, nome, s in percorrer(pasta, cancelar, recursivo=False):
        if e_sistema(s) or e_oculto(nome, s) or nome.lower() in _NOMES_NUNCA:
            continue
        n += 1
        b += int(s.st_size)
    return n, b
