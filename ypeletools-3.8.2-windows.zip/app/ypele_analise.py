#!/usr/bin/env python3
"""
Áudio Tools: o Analyser do yPeléTools (BPM, tonalidade e a ficha da música), SEM interface.
(Beta 3.7: BPM Analyzer e Key Detector; Beta 3.7.1: as duas viraram uma ferramenta só, o Analyser.)

Tudo aqui é cálculo de verdade sobre o áudio (ou um dado de catálogo de verdade): nada é estimado pelo título, pela
capa ou por valores fixos. Usa só o NumPy (que o app já tem) e o FFmpeg do app para decodificar qualquer formato.

  BPM (andamento) ...... envelope de ataques (fluxo espectral em 40 bandas log), autocorrelação com harmônicos
                         (tempograma) e uma preferência suave em torno de 120 BPM para escolher a oitava; depois o
                         rastreamento das batidas por programação dinâmica (Ellis, 2007) e uma regressão linear dos
                         tempos das batidas dá o valor com uma casa decimal. A confiança combina a força do pico e a
                         regularidade das batidas. Quando o dobro/a metade também é plausível, o resultado diz.
  Tonalidade ........... afinação estimada pelos picos do espectro (a música pode estar alguns cents fora do Lá 440),
                         perfil de classes de altura (cromagrama) dos picos entre 55 Hz e 2 kHz, com o baixo pesando mais,
                         correlação com os perfis de Krumhansl-Kessler e de Temperley (24 tonalidades). A confiança vem
                         da distância entre a melhor e a segunda melhor tonalidade.
  Catálogo (link) ...... BPM publicado pelo catálogo público do Deezer (api.deezer.com, sem login), só quando título,
                         artista e duração conferem. Marcado como "dado de catálogo", nunca como cálculo.

Limitações honestas: músicas com mudança de andamento, sem percussão, com métrica irregular ou com modulação de
tonalidade dão resultados menos confiáveis (a confiança cai e o app avisa); a escolha entre o dobro e a metade do
andamento (ex.: 87 x 174 BPM) depende do estilo; tonalidades relativas (Dó maior x Lá menor) às vezes se confundem.
"""

import json
import re
import subprocess
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

TAXA = 22050
ANALISE_MAX_SEG = 8 * 60                 # o andamento e a tonalidade não precisam de mais que isso

NOTAS = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]
NOTAS_PT = ["Dó", "Dó#", "Ré", "Mi♭", "Mi", "Fá", "Fá#", "Sol", "Lá♭", "Lá", "Si♭", "Si"]
# Roda de Camelot: tônica (classe de altura) -> código. Maior = B, menor = A.
CAMELOT_MAIOR = {0: "8B", 7: "9B", 2: "10B", 9: "11B", 4: "12B", 11: "1B", 6: "2B", 1: "3B", 8: "4B", 3: "5B",
                 10: "6B", 5: "7B"}
CAMELOT_MENOR = {9: "8A", 4: "9A", 11: "10A", 6: "11A", 1: "12A", 8: "1A", 3: "2A", 10: "3A", 5: "4A", 0: "5A",
                 7: "6A", 2: "7A"}
PERFIS = {
    "kk": ([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88],
           [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]),
    "temperley": ([5.0, 2.0, 3.5, 2.0, 4.5, 4.0, 2.0, 4.5, 2.0, 3.5, 1.5, 4.0],
                  [5.0, 2.0, 3.5, 4.5, 2.0, 4.0, 2.0, 4.5, 3.5, 2.0, 1.5, 4.0]),
}


class ErroAnalise(Exception):
    pass


def _np():
    import numpy as np
    return np


def nome_tom(tonica: int, modo: str) -> dict:
    """{'nome': 'F menor', 'nome_en': 'F Minor', 'nome_pt': 'Fá menor', 'camelot': '4A', 'nota': 'F', 'modo': 'menor'}"""
    maior = modo == "maior"
    return {"nota": NOTAS[tonica], "modo": modo, "tonica": tonica,
            "nome": "%s %s" % (NOTAS[tonica], "maior" if maior else "menor"),
            "nome_en": "%s %s" % (NOTAS[tonica], "Major" if maior else "Minor"),
            "nome_pt": "%s %s" % (NOTAS_PT[tonica], "maior" if maior else "menor"),
            "camelot": (CAMELOT_MAIOR if maior else CAMELOT_MENOR)[tonica]}


# ======================================================================================================================
# Decodificação (FFmpeg)
# ======================================================================================================================
def decodificar(ffmpeg: str, caminho: str, taxa: int = TAXA, max_seg: float = ANALISE_MAX_SEG, inicio: float = 0.0,
                cancelado=None):
    """Áudio mono float32 na `taxa`. Lê do FFmpeg por pipe (o arquivo original nunca é alterado)."""
    np = _np()
    cmd = [ffmpeg, "-nostdin", "-v", "error"]
    if inicio:
        cmd += ["-ss", "%.3f" % inicio]
    cmd += ["-i", str(caminho), "-vn", "-t", "%.1f" % max_seg, "-ac", "1", "-ar", str(taxa), "-f", "f32le", "-"]
    kw = {}
    if sys.platform == "win32":
        kw["creationflags"] = 0x08000000
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw)
    except OSError as e:
        raise ErroAnalise("Não consegui abrir o FFmpeg para ler o áudio (%s)." % e)
    partes = []
    try:
        while True:
            if cancelado and cancelado():
                raise ErroAnalise("cancelado")
            b = p.stdout.read(1 << 20)
            if not b:
                break
            partes.append(b)
        erro = p.stderr.read().decode("utf-8", "replace")
        p.wait(30)
    finally:
        if p.poll() is None:
            p.kill()
            p.wait(10)
        for fluxo in (p.stdout, p.stderr):
            try:
                fluxo.close()
            except OSError:
                pass
    dados = b"".join(partes)
    if p.returncode != 0 and not dados:
        raise ErroAnalise("O FFmpeg não conseguiu ler este arquivo: %s" % (erro.strip().splitlines() or ["?"])[-1][:200])
    x = np.frombuffer(dados[:len(dados) // 4 * 4], dtype="<f4").astype(np.float32)
    if x.size < taxa * 3:
        raise ErroAnalise("O áudio é curto demais para analisar (mínimo 3 segundos).")
    if float(np.max(np.abs(x))) < 1e-4:
        raise ErroAnalise("O áudio está em silêncio.")
    return x


def _quadros(x, n_fft: int, hop: int, inicio: int, n: int):
    np = _np()
    idx = inicio * hop + np.arange(n)[:, None] * hop + np.arange(n_fft)[None, :]
    return x[idx]


def _espectro(x, n_fft: int, hop: int, pedaco: int = 1024):
    """|STFT| por pedaços (a memória não cresce com a duração). Gera (índice do 1º quadro, magnitudes)."""
    np = _np()
    pad = np.concatenate([np.zeros(n_fft // 2, np.float32), x, np.zeros(n_fft // 2, np.float32)])
    total = 1 + (len(pad) - n_fft) // hop
    jan = np.hanning(n_fft).astype(np.float32)
    for ini in range(0, total, pedaco):
        n = min(pedaco, total - ini)
        q = _quadros(pad, n_fft, hop, ini, n) * jan
        yield ini, np.abs(np.fft.rfft(q, axis=1)).astype(np.float32)


# ======================================================================================================================
# BPM
# ======================================================================================================================
def envelope_ataques(x, sr: int = TAXA, hop: int = 256, n_fft: int = 1024):
    """Força dos ataques por quadro (fluxo espectral positivo em 40 bandas log, sem a tendência lenta)."""
    np = _np()
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    bordas = np.geomspace(40.0, min(10000.0, sr / 2 - 1), 41)
    banda = np.digitize(freqs, bordas) - 1
    validos = (banda >= 0) & (banda < 40)
    M = np.zeros((len(freqs), 40), np.float32)
    M[np.nonzero(validos)[0], banda[validos]] = 1.0
    blocos = []
    for _ini, mag in _espectro(x, n_fft, hop):
        blocos.append(np.log1p(1000.0 * (mag @ M)))
    S = np.concatenate(blocos, axis=0)
    flux = np.maximum(0.0, np.diff(S, axis=0)).sum(axis=1)
    flux = np.concatenate([[0.0], flux])
    k = max(3, int(round(0.5 * sr / hop)))
    media = np.convolve(flux, np.ones(k) / k, mode="same")
    env = np.maximum(0.0, flux - media)
    dp = float(np.std(env)) or 1.0
    return (env / dp).astype(np.float64), sr / hop


def _autocorrelacao(env):
    np = _np()
    n = len(env)
    e = env - env.mean()
    f = np.fft.rfft(e, 2 * n)
    ac = np.fft.irfft(f * np.conj(f))[:n]
    return ac / (ac[0] or 1.0)


def _interp(v, pos: float) -> float:
    i = int(pos)
    if i + 1 >= len(v) or i < 0:
        return 0.0
    a = pos - i
    return float(v[i] * (1 - a) + v[i + 1] * a)


def _rastrear_batidas(env, fps: float, bpm: float, apertura: float = 100.0):
    """Programação dinâmica de Ellis (2007): as batidas que maximizam a força dos ataques com intervalos próximos do
    período. Devolve os índices dos quadros das batidas."""
    np = _np()
    periodo = 60.0 * fps / bpm
    larg = max(1, int(round(periodo / 16)))
    g = np.exp(-0.5 * (np.arange(-2 * larg, 2 * larg + 1) / larg) ** 2)
    local = np.convolve(env, g, mode="same")
    n = len(local)
    acumulado = np.zeros(n)
    anterior = -np.ones(n, dtype=int)
    janela = np.arange(-int(round(2 * periodo)), -int(round(periodo / 2)) + 1)
    custo = -apertura * (np.log(-janela / periodo)) ** 2
    for t in range(n):
        idx = t + janela
        ok = idx >= 0
        if np.any(ok):
            cand = acumulado[idx[ok]] + custo[ok]
            j = int(np.argmax(cand))
            if cand[j] > 0:
                acumulado[t] = local[t] + cand[j]
                anterior[t] = idx[ok][j]
                continue
        acumulado[t] = local[t]
    # a última batida: o melhor acumulado perto do fim
    fim = n - 1 - int(np.argmax(acumulado[::-1][:int(periodo * 2)])) if n > periodo * 2 else int(np.argmax(acumulado))
    batidas = [fim]
    while anterior[batidas[-1]] >= 0:
        batidas.append(int(anterior[batidas[-1]]))
    return np.array(batidas[::-1])


def estimar_bpm(x, sr: int = TAXA, minimo: float = 50.0, maximo: float = 220.0) -> dict:
    """{'bpm': 128.0, 'bpm_inteiro': 128, 'confianca': 0..1, 'alternativa': 64.0 ou None, 'batidas': n}"""
    np = _np()
    env, fps = envelope_ataques(x, sr)
    if len(env) < fps * 4 or float(env.max()) <= 0:
        raise ErroAnalise("Não há ataques suficientes no áudio para medir o andamento.")
    ac = _autocorrelacao(env)
    grade = np.arange(minimo, maximo + 0.01, 0.25)
    pont = np.zeros(len(grade))
    for k, b in enumerate(grade):
        lag = 60.0 * fps / b
        pont[k] = sum(_interp(ac, lag * h) / h for h in (1, 2, 3, 4)) + 0.5 * _interp(ac, lag / 2)
    prior = np.exp(-0.5 * (np.log2(grade / 120.0) / 1.0) ** 2)
    final = np.maximum(pont, 0) * prior
    i = int(np.argmax(final))
    bpm0 = float(grade[i])
    # alternativa: o dobro ou a metade com pontuação parecida
    alternativa = None
    for fator in (2.0, 0.5):
        alvo = bpm0 * fator
        if minimo <= alvo <= maximo:
            j = int(np.argmin(np.abs(grade - alvo)))
            if final[j] >= 0.8 * final[i]:
                alternativa = round(alvo, 1)
    batidas = _rastrear_batidas(env, fps, bpm0)
    bpm = bpm0
    regular = 0.0
    if len(batidas) >= 8:
        t = batidas / fps
        ids = np.arange(len(t))
        inclinacao = np.polyfit(ids, t, 1)[0]
        if inclinacao > 0:
            refinado = 60.0 / inclinacao
            if abs(refinado - bpm0) / bpm0 < 0.04:              # o rastreamento só ajusta a casa decimal
                bpm = float(refinado)
        inter = np.diff(t)
        regular = float(max(0.0, 1.0 - min(1.0, np.std(inter) / (np.median(inter) or 1) * 5)))
    forca = float(min(1.0, max(0.0, _interp(ac, 60.0 * fps / bpm0)) / 0.45))
    confianca = round(0.5 * regular + 0.5 * forca, 2)
    return {"bpm": round(bpm, 1), "bpm_inteiro": int(round(bpm)), "confianca": confianca,
            "alternativa": alternativa, "batidas": int(len(batidas))}


# ======================================================================================================================
# Tonalidade
# ======================================================================================================================
def estimar_tom(x, sr: int = TAXA) -> dict:
    """{'tonica': 5, 'modo': 'menor', 'nome': 'F menor', 'camelot': '4A', 'confianca': 0..1, 'afinacao_cents': -12,
    'segunda': {...}, 'croma': [12 valores]}"""
    np = _np()
    n_fft, hop = 8192, 4096
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    faixa = (freqs >= 55.0) & (freqs <= 2000.0)
    idx = np.nonzero(faixa)[0]
    f_sel = freqs[idx]
    picos_f, picos_m = [], []
    for _ini, mag in _espectro(x, n_fft, hop, pedaco=256):
        m = mag[:, idx]
        c = np.log1p(100.0 * m / (m.max() or 1.0))
        pico = (c[:, 1:-1] > c[:, :-2]) & (c[:, 1:-1] >= c[:, 2:]) & (c[:, 1:-1] > 0.2 * c.max(axis=1, keepdims=True))
        q, b = np.nonzero(pico)
        b = b + 1
        # posição do pico com interpolação parabólica (precisão de cents)
        a, y, z = c[q, b - 1], c[q, b], c[q, b + 1]
        den = a - 2 * y + z
        desl = np.where(np.abs(den) > 1e-9, 0.5 * (a - z) / den, 0.0)
        passo = f_sel[1] - f_sel[0]
        picos_f.append(f_sel[b] + desl * passo)
        picos_m.append(y)
    if not picos_f:
        raise ErroAnalise("Não há notas suficientes no áudio para achar a tonalidade.")
    pf, pm = np.concatenate(picos_f), np.concatenate(picos_m)
    if pf.size < 50:
        raise ErroAnalise("Não há notas suficientes no áudio para achar a tonalidade.")
    midi = 69.0 + 12.0 * np.log2(pf / 440.0)
    desvio = (midi - np.round(midi)) * 2 * np.pi                    # afinação: média circular dos desvios
    afin = float(np.angle(np.sum(pm * np.exp(1j * desvio))) / (2 * np.pi))
    midi_c = midi - afin
    classe = np.mod(np.round(midi_c), 12).astype(int)
    peso = pm * np.where(pf < 250.0, 1.6, 1.0)                     # o baixo indica mais a tônica
    croma = np.bincount(classe, weights=peso, minlength=12)
    croma = croma / (croma.max() or 1.0)
    pont = []
    for modo, k in (("maior", 0), ("menor", 1)):
        for tonica in range(12):
            r = 0.0
            for perfil in PERFIS.values():
                p = np.roll(np.array(perfil[k]), tonica)
                r += float(np.corrcoef(croma, p)[0, 1])
            pont.append((r / len(PERFIS), tonica, modo))
    pont.sort(reverse=True)
    r1, t1, m1 = pont[0]
    r2, t2, m2 = pont[1]
    confianca = round(float(max(0.0, min(1.0, (r1 - r2) / 0.12)) * max(0.0, min(1.0, r1 / 0.6))), 2)
    res = nome_tom(t1, m1)
    res.update(confianca=confianca, correlacao=round(r1, 3), afinacao_cents=int(round(afin * 100)),
               segunda=dict(nome_tom(t2, m2), correlacao=round(r2, 3)), croma=[round(float(v), 3) for v in croma])
    return res


def rotulo_confianca(c) -> str:
    if c is None:
        return ""
    if isinstance(c, str):
        return {"alta": "alta", "media": "média", "média": "média", "baixa": "baixa"}.get(c, c)
    return "alta" if c >= 0.7 else ("média" if c >= 0.4 else "baixa")


def analisar_audio(ffmpeg: str, caminho: str, cancelado=None, bpm: bool = True, tom: bool = True) -> dict:
    """Decodifica e calcula BPM e/ou tonalidade. Levanta ErroAnalise com a mensagem em português."""
    x = decodificar(ffmpeg, caminho, cancelado=cancelado)
    r = {"duracao_analisada": round(len(x) / TAXA, 1)}
    if bpm:
        try:
            r["bpm"] = estimar_bpm(x)
        except ErroAnalise as e:
            r["bpm_erro"] = str(e)
    if cancelado and cancelado():
        raise ErroAnalise("cancelado")
    if tom:
        try:
            r["tom"] = estimar_tom(x)
        except ErroAnalise as e:
            r["tom_erro"] = str(e)
    return r


# ======================================================================================================================
# BPM de catálogo (Deezer, API pública sem login)
# ======================================================================================================================
DEEZER_API = "https://api.deezer.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) yPeleTools"


def _normal(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\((?:feat|ft|with)[^)]*\)|\[(?:feat|ft)[^\]]*\]", " ", s)
    s = re.sub(r"\b(official|video|audio|lyrics?|clipe|oficial|hd|4k|remaster(ed)?( \d{4})?)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def _abrir_json(url: str, abrir=None, timeout: float = 12.0):
    if abrir is not None:
        return abrir(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(2_000_000).decode("utf-8", "replace"))


def bpm_do_catalogo(titulo: str, artista: str, duracao=None, isrc: str = "", abrir=None) -> "dict | None":
    """BPM publicado pelo Deezer para a MESMA gravação: pelo ISRC (quando o Spotify informa) ou por busca com título e
    artista, aceitando só resultado com título e artista iguais (normalizados) e duração a até 4 s. bpm 0 = o Deezer não
    tem o dado. Devolve {'bpm', 'fonte', 'id', 'titulo', 'artista', 'duracao'} ou None. Erro de rede -> None."""
    try:
        cand = []
        if isrc:
            d = _abrir_json("%s/track/isrc:%s" % (DEEZER_API, urllib.parse.quote(isrc)), abrir)
            if isinstance(d, dict) and d.get("id") and not d.get("error"):
                cand.append(d)
        if not cand and titulo:
            # Beta 3.8: o filtro 'artist:"…"' da busca do Deezer passou a devolver 0 resultados; a busca vai em texto
            # livre e o filtro de título, artista (o MESMO artista, não um que só contém o nome) e duração é feito aqui
            q = ("%s %s" % (artista, titulo)) if artista else titulo
            d = _abrir_json("%s/search?q=%s&limit=15" % (DEEZER_API, urllib.parse.quote(q)), abrir)
            for e in (d.get("data") or []) if isinstance(d, dict) else []:
                if _normal(e.get("title")) != _normal(titulo) and _normal(e.get("title_short")) != _normal(titulo):
                    continue
                if artista and not mesmo_artista((e.get("artist") or {}).get("name"), artista):
                    continue
                if duracao and e.get("duration") and abs(float(e["duration"]) - float(duracao)) > 4:
                    continue
                cand.append(e)
        for e in cand[:3]:
            completo = e if "bpm" in e else _abrir_json("%s/track/%s" % (DEEZER_API, e["id"]), abrir)
            if not isinstance(completo, dict):
                continue
            if duracao and completo.get("duration") and abs(float(completo["duration"]) - float(duracao)) > 4:
                continue
            bpm = float(completo.get("bpm") or 0)
            if 40 <= bpm <= 250:
                return {"bpm": round(bpm, 1), "fonte": "Deezer (catálogo público)", "id": completo.get("id"),
                        "titulo": completo.get("title"), "artista": (completo.get("artist") or {}).get("name"),
                        "duracao": completo.get("duration")}
    except Exception:
        return None
    return None


# ======================================================================================================================
# Analyser (Beta 3.7.1): busca por link, nome e/ou artista e a ficha completa da música, com a fonte de cada dado
# ======================================================================================================================
# Fontes, na ordem em que entram, e por quê:
#   Deezer (api.deezer.com) ....... API pública sem login: busca, ISRC, BPM (quando o Deezer tem), lançamento, faixa,
#                                   ranking, contribuidores; o álbum dá UPC, gravadora e gêneros.
#   MusicBrainz (musicbrainz.org) . base aberta: créditos (produção, composição, mixagem...), gravadora e data quando o
#                                   Deezer não tem, e a busca reserva se o Deezer estiver fora. Pede no máx. 1 pedido/s e
#                                   um User-Agent com contato: respeitado aqui.
#   GetSongBPM (api.getsong.co) ... BPM e TONALIDADE publicados, só com a chave gratuita da PRÓPRIA pessoa (a API exige
#                                   chave e um link para GetSongBPM.com; o app mostra o link quando usa o dado).
#   TuneBat ....................... NÃO é consultado pelo app: os Termos de Serviço do TuneBat (seção IX(a)(ix)) proíbem
#                                   robôs e qualquer acesso automatizado. O app só abre a página do TuneBat no navegador
#                                   (url_tunebat), para a pessoa conferir lá.
# Nada aqui inventa valor: campo sem dado fica None ("Não disponível" na tela). Erro, limite ou serviço fora do ar viram
# um aviso e a ficha segue com as outras fontes.
import time as _time

MB_API = "https://musicbrainz.org/ws/2"
GSB_API = "https://api.getsong.co"
UA_MB = "yPeleTools/3.7 ( https://github.com/SenhorMKG/ypeletools-updates )"
_MB_ULTIMO = [0.0]
_esperar = _time.sleep                    # (os testes trocam por uma função que não espera)

NOTAS_EN = {"C": 0, "C#": 1, "DB": 1, "D": 2, "D#": 3, "EB": 3, "E": 4, "FB": 4, "E#": 5, "F": 5, "F#": 6, "GB": 6,
            "G": 7, "G#": 8, "AB": 8, "A": 9, "A#": 10, "BB": 10, "B": 11, "CB": 11, "B#": 0}
PAPEIS_PT = {"producer": "Produção", "co-producer": "Coprodução", "executive producer": "Produção executiva",
             "mix": "Mixagem", "mix-DJ": "Mixagem (DJ)", "mastering": "Masterização", "engineer": "Engenharia",
             "audio": "Engenharia de áudio", "sound": "Engenharia de som", "recording": "Engenharia de gravação",
             "programming": "Programação", "vocal": "Vocais", "instrument": "Instrumentos", "performer": "Intérprete",
             "composer": "Composição", "lyricist": "Letra", "writer": "Autoria", "arranger": "Arranjo",
             "remixer": "Remix", "featured": "Participação", "main": "Artista principal"}


class ErroFonte(Exception):
    """Um serviço respondeu com erro, limite ou não respondeu (a mensagem já está em português)."""

    def __init__(self, msg: str = "", codigo: int = 0) -> None:
        super().__init__(msg)
        self.codigo = codigo


def _pedir_json(url: str, abrir=None, cabecalhos=None, timeout: float = 12.0):
    if abrir is not None:
        return abrir(url)
    req = urllib.request.Request(url, headers=dict({"User-Agent": UA, "Accept": "application/json"}, **(cabecalhos or {})))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read(3_000_000).decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        if e.code == 429 or e.code == 503:
            raise ErroFonte("limite de consultas atingido (%d); tente de novo em alguns minutos" % e.code, e.code)
        if e.code == 404:
            raise ErroFonte("não encontrado (404)", 404)
        raise ErroFonte("respondeu %d" % e.code, e.code)
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise ErroFonte("sem resposta (%s)" % getattr(e, "reason", e))
    except ValueError:
        raise ErroFonte("resposta inválida")


def _deezer(caminho: str, abrir=None):
    d = _pedir_json(DEEZER_API + caminho, abrir)
    if isinstance(d, dict) and d.get("error"):
        err = d["error"] if isinstance(d["error"], dict) else {"message": str(d["error"])}
        if err.get("code") == 4:
            raise ErroFonte("limite de consultas do Deezer atingido; tente de novo em alguns segundos")
        if err.get("code") == 800:
            return None                                  # "no data": não existe
        raise ErroFonte(err.get("message") or "erro")
    return d


def _mb(caminho: str, abrir=None):
    """MusicBrainz: no máximo 1 pedido por segundo e, se o serviço recusar por excesso (503/429, comum mesmo
    respeitando o limite), mais 2 tentativas com espera de 2,5 s e 5 s (Beta 3.8)."""
    sep = "&" if "?" in caminho else "?"
    for n in range(3):
        espera = 1.1 - (_time.monotonic() - _MB_ULTIMO[0])
        if espera > 0 and abrir is None:
            _esperar(espera)
        _MB_ULTIMO[0] = _time.monotonic()
        try:
            return _pedir_json(MB_API + caminho + sep + "fmt=json", abrir, {"User-Agent": UA_MB})
        except ErroFonte as e:
            if e.codigo not in (429, 503) or n == 2:
                raise
            _esperar(2.5 * (n + 1))


def _artistas_mb(credito) -> list:
    return [c.get("name") or (c.get("artist") or {}).get("name") for c in (credito or []) if isinstance(c, dict)]


def _res_deezer(e: dict) -> dict:
    alb = e.get("album") or {}
    return {"fonte_busca": "Deezer", "deezer_id": e.get("id"), "mbid": "", "titulo": e.get("title") or "",
            "titulo_curto": e.get("title_short") or e.get("title") or "", "artista": (e.get("artist") or {}).get("name") or "",
            "artistas": [(e.get("artist") or {}).get("name")] if e.get("artist") else [], "album": alb.get("title") or "",
            "duracao": e.get("duration") or None, "capa": alb.get("cover_big") or alb.get("cover_medium") or "",
            "capa_pequena": alb.get("cover_small") or alb.get("cover_medium") or "", "isrc": e.get("isrc") or "",
            "explicita": bool(e.get("explicit_lyrics")), "rank": e.get("rank")}


def _res_mb(r: dict) -> dict:
    rel = (r.get("releases") or [{}])[0]
    arts = _artistas_mb(r.get("artist-credit"))
    return {"fonte_busca": "MusicBrainz", "deezer_id": None, "mbid": r.get("id") or "", "titulo": r.get("title") or "",
            "titulo_curto": r.get("title") or "", "artista": ", ".join(a for a in arts if a), "artistas": arts,
            "album": rel.get("title") or "", "duracao": round(r["length"] / 1000) if r.get("length") else None,
            "capa": ("https://coverartarchive.org/release/%s/front-250" % rel["id"]) if rel.get("id") else "",
            "capa_pequena": ("https://coverartarchive.org/release/%s/front-250" % rel["id"]) if rel.get("id") else "",
            "isrc": (r.get("isrcs") or [""])[0], "explicita": False, "rank": None, "mb_release": rel.get("id") or ""}


def buscar_musicas(texto: str = "", titulo: str = "", artista: str = "", limite: int = 10, abrir=None) -> dict:
    """Busca por nome da música, do artista ou os dois. `texto`: o que a pessoa digitou (livre); `titulo`/`artista`:
    campos separados (busca dirigida, usada a partir de um link). Devolve {'resultados': [...], 'fonte', 'avisos'}.
    Deezer primeiro; se o Deezer falhar, MusicBrainz. Nunca escolhe sozinho: quem chama mostra a lista."""
    avisos = []
    if titulo or artista:
        # Beta 3.8: 'artist:"…"' não funciona mais na busca do Deezer (0 resultados); 'track:"…"' funciona. A busca
        # dirigida usa o título no filtro e o artista no texto; o resultado que é do MESMO artista vem primeiro.
        q = " ".join(p for p in (artista, 'track:"%s"' % titulo.replace('"', "") if titulo else "") if p)
    else:
        q = texto.strip()
    if not q:
        return {"resultados": [], "fonte": "", "avisos": ["Digite o nome da música e/ou do artista."]}
    try:
        d = _deezer("/search?q=%s&limit=%d" % (urllib.parse.quote(q), limite), abrir) or {}
        res = [_res_deezer(e) for e in d.get("data") or [] if isinstance(e, dict) and e.get("type", "track") == "track"]
        if artista and res:
            res.sort(key=lambda r: 0 if mesmo_artista(r.get("artista"), artista) else 1)
        if res or not (titulo or artista):
            return {"resultados": res[:limite], "fonte": "Deezer", "avisos": avisos}
        if titulo and artista:                           # busca dirigida sem nada: tenta como texto livre
            d = _deezer("/search?q=%s&limit=%d" % (urllib.parse.quote("%s %s" % (artista, titulo)), limite), abrir) or {}
            res = [_res_deezer(e) for e in d.get("data") or [] if isinstance(e, dict)]
            if res:
                return {"resultados": res[:limite], "fonte": "Deezer", "avisos": avisos}
    except ErroFonte as e:
        avisos.append("Deezer: %s." % e)
    try:
        partes = []
        if titulo or artista:
            if titulo:
                partes.append('recording:"%s"' % titulo.replace('"', ""))
            if artista:
                partes.append('artist:"%s"' % artista.replace('"', ""))
            consulta = " AND ".join(partes)
        else:
            consulta = q.replace('"', "")
        d = _mb("/recording?query=%s&limit=%d" % (urllib.parse.quote(consulta), limite), abrir) or {}
        res = [_res_mb(r) for r in d.get("recordings") or [] if isinstance(r, dict)]
        return {"resultados": res[:limite], "fonte": "MusicBrainz", "avisos": avisos}
    except ErroFonte as e:
        avisos.append("MusicBrainz: %s." % e)
    return {"resultados": [], "fonte": "", "avisos": avisos}


def mesmo_artista(a: str, b: str) -> bool:
    """O MESMO artista (normalizado): igual, ou um dos nomes de uma lista ('A, B & C') igual. 'Hello I'm Adele' não é
    'Adele' (Beta 3.8: antes bastava conter o nome)."""
    def nomes(x):
        return {_normal(p) for p in re.split(r"\s*(?:,|&|;| feat\.? | ft\.? | e | and | x )\s*", str(x or ""), flags=re.I)
                if _normal(p)} | ({_normal(x)} if _normal(x) else set())
    na, nb = nomes(a), nomes(b)
    return bool(na and nb and (na & nb))


def mesma_faixa(a: dict, b: dict, tolerancia: float = 3.0) -> bool:
    """Critério estrito para ligar um link a um resultado SEM perguntar: o mesmo ISRC, ou título e artista iguais
    (normalizados) e duração a até `tolerancia` segundos. Nome parecido sozinho nunca basta."""
    if a.get("isrc") and b.get("isrc"):
        return a["isrc"].upper() == b["isrc"].upper()
    ta, tb = _normal(a.get("titulo")), {_normal(b.get("titulo")), _normal(b.get("titulo_curto"))}
    if not ta or ta not in tb:
        return False
    aa = {_normal(x) for x in (a.get("artistas") or [a.get("artista")]) if x}
    ab = {_normal(x) for x in (b.get("artistas") or [b.get("artista")]) if x}
    if not aa or not ab or not (aa & ab):
        return False
    if not a.get("duracao") or not b.get("duracao"):
        return False
    return abs(float(a["duracao"]) - float(b["duracao"])) <= tolerancia


def nota_pt(tonica: int) -> str:
    return NOTAS_PT[tonica % 12]


def tom_de_texto(txt: str, modo_padrao: str = None):
    """'F#m', 'F♯m', 'Bb', 'E♭ minor', 'C major' -> nome_tom(...) ou None (texto que não é uma tonalidade).
    Beta 3.8: uma NOTA ISOLADA ('E', 'Bb') não diz o modo. Sem 'm'/'minor'/'major' no texto, o modo só vem de
    `modo_padrao` (quando a fonte documenta a convenção); senão volta {'tonica', 'nota', 'modo': None, ...}."""
    s = str(txt or "").strip().replace("♯", "#").replace("♭", "b")
    m = re.match(r"^([A-Ga-g])\s*([#b]?)\s*(m|min|minor|maj|major|menor|maior|dur|moll)?$", s, re.I)
    if not m:
        return None
    nota = (m.group(1).upper() + m.group(2).upper()).replace("#", "#")
    if nota not in NOTAS_EN:
        return None
    suf = (m.group(3) or "").lower()
    if suf in ("m", "min", "minor", "menor", "moll"):
        modo = "menor"
    elif suf in ("maj", "major", "maior", "dur"):
        modo = "maior"
    else:
        modo = modo_padrao
    if modo is None:
        t = NOTAS_EN[nota]
        return {"nota": NOTAS[t], "modo": None, "tonica": t, "nome": NOTAS[t], "nome_en": NOTAS[t],
                "nome_pt": nota_pt(t), "camelot": ""}
    return nome_tom(NOTAS_EN[nota], modo)


def tom_de_open_key(ok: str):
    """Notação Open Key ('1d' = Dó maior, '1m' = Lá menor, '2d' = Sol maior...): d = dur (maior), m = moll (menor).
    None se não for."""
    m = re.fullmatch(r"\s*(1[0-2]|[1-9])\s*([dm])\s*", str(ok or ""), re.I)
    if not m:
        return None
    n, letra = int(m.group(1)), m.group(2).lower()
    tonica = (7 * (n - 1)) % 12 if letra == "d" else (9 + 7 * (n - 1)) % 12
    return nome_tom(tonica, "maior" if letra == "d" else "menor")


def relativas(a: dict, b: dict) -> bool:
    """Duas tonalidades relativas (mesma armadura: Dó maior e Lá menor)."""
    if not a or not b or not a.get("modo") or not b.get("modo") or a["modo"] == b["modo"]:
        return False
    maior, menor = (a, b) if a["modo"] == "maior" else (b, a)
    return (maior["tonica"] - 3) % 12 == menor["tonica"]


def _gsb(titulo: str, artista: str, chave: str, duracao=None, abrir=None):
    """GetSongBPM: BPM e tonalidade publicados, só se título e artista conferirem. None se não achar."""
    if not chave:
        return None
    # a chave vai só no cabeçalho X-API-KEY (a API aceita assim): fora da URL, ela nunca aparece num log de endereço
    url = "%s/search/?type=both&lookup=%s" % (GSB_API, urllib.parse.quote("song:%s artist:%s" % (titulo, artista)))
    d = _pedir_json(url, abrir, {"X-API-KEY": chave})
    itens = d.get("search") if isinstance(d, dict) else None
    if not isinstance(itens, list):
        if isinstance(itens, dict) and itens.get("error") and "no result" not in str(itens.get("error")):
            raise ErroFonte(str(itens["error"]))
        return None
    for e in itens:
        if not isinstance(e, dict):
            continue
        if _normal(e.get("title")) != _normal(titulo):
            continue
        if not mesmo_artista((e.get("artist") or {}).get("name"), artista):
            continue
        bpm = None
        try:
            bpm = float(e.get("tempo") or 0) or None
        except (TypeError, ValueError):
            pass
        tom = tom_de_open_key(e.get("open_key")) or tom_de_texto(e.get("key_of"))
        return {"bpm": round(bpm, 1) if bpm and 30 <= bpm <= 300 else None, "tom": tom,
                "compasso": e.get("time_sig") or "", "url": e.get("uri") or "https://getsongbpm.com"}
    return None


def _creditos_mb(rec: dict) -> list:
    papeis = {}

    def somar(nome, papel):
        if nome and papel:
            papeis.setdefault(nome, [])
            if papel not in papeis[nome]:
                papeis[nome].append(papel)
    for rel in rec.get("relations") or []:
        if rel.get("target-type") == "artist":
            tipo = rel.get("type") or ""
            papel = PAPEIS_PT.get(tipo, tipo.capitalize() if tipo else "")
            if tipo in ("instrument", "vocal") and rel.get("attributes"):
                papel = "%s (%s)" % (papel, ", ".join(rel["attributes"]))
            somar((rel.get("artist") or {}).get("name"), papel)
        elif rel.get("target-type") == "work":
            for wr in (rel.get("work") or {}).get("relations") or []:
                if wr.get("target-type") == "artist":
                    somar((wr.get("artist") or {}).get("name"), PAPEIS_PT.get(wr.get("type"), wr.get("type") or ""))
    return [{"nome": n, "papeis": p} for n, p in papeis.items()]


def _campo(valor, fonte):
    return {"valor": valor, "fonte": fonte} if valor not in (None, "", [], 0) else None


# ---------- estimativas externas de BPM e tonalidade (Beta 3.8) ----------
# Quando nenhuma fonte PUBLICA o BPM e a tonalidade (o caso mais comum sem a chave do GetSongBPM), duas bases abertas
# têm uma ESTIMATIVA calculada por análise automática do áudio. Elas aparecem sempre como estimativa, com a fonte, e
# nunca no lugar de um dado publicado:
#   AcousticBrainz (acousticbrainz.org) ... base do MetaBrainz com as análises do Essentia enviadas pela comunidade
#                                           (congelada desde 2022; sem login, licença CC0). Liga pela gravação do
#                                           MusicBrainz (MBID) e compara várias análises da mesma gravação.
#   ReccoBeats (api.reccobeats.com) ...... API gratuita, sem chave, com "audio features" por faixa do Spotify. Liga
#                                           pelo ID do Spotify ou pelo ISRC (+ duração). Nos testes deste projeto, a
#                                           tonalidade dela errou mais que a do AcousticBrainz (confunde relativas e
#                                           quintas), então entra só quando o AcousticBrainz não tem a música e com
#                                           confiança "baixa".
ACOUSTICBRAINZ_API = "https://acousticbrainz.org/api/v1"
RECCOBEATS_API = "https://api.reccobeats.com/v1"


class CacheConsultas:
    """Cache das estimativas externas (chave -> valor), com validade. Só fica ativo depois de configurar(arquivo)
    (o app usa um arquivo na pasta de dados); sem isso, nada é guardado (os testes e o uso sem app)."""

    def __init__(self) -> None:
        import threading
        self.arquivo = None
        self.dados: dict = {}
        self._trava = threading.Lock()

    def configurar(self, arquivo) -> None:
        from pathlib import Path
        self.arquivo = Path(arquivo) if arquivo else None
        self.dados = {}
        if self.arquivo and self.arquivo.is_file():
            try:
                d = json.loads(self.arquivo.read_text(encoding="utf-8"))
                agora = _time.time()
                self.dados = {k: v for k, v in d.items() if isinstance(v, dict) and v.get("ate", 0) > agora}
            except (OSError, ValueError):
                self.dados = {}

    def obter(self, chave: str):
        if self.arquivo is None:
            return None
        with self._trava:
            v = self.dados.get(chave)
        if v and v.get("ate", 0) > _time.time():
            return v
        return None

    def guardar(self, chave: str, valor, dias: float) -> None:
        if self.arquivo is None:
            return
        with self._trava:
            self.dados[chave] = {"valor": valor, "ate": _time.time() + dias * 86400}
            if len(self.dados) > 4000:
                for k in sorted(self.dados, key=lambda k: self.dados[k]["ate"])[:500]:
                    self.dados.pop(k, None)
            copia = dict(self.dados)
        try:
            self.arquivo.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.arquivo.with_name(self.arquivo.name + ".tmp")
            tmp.write_text(json.dumps(copia, ensure_ascii=False), encoding="utf-8")
            import os
            os.replace(tmp, self.arquivo)
        except OSError:
            pass


CACHE = CacheConsultas()
CACHE_DIAS_ACHADO = 30            # estimativa encontrada: 30 dias
CACHE_DIAS_SEM_DADO = 3           # "não tem": 3 dias (a base pode ganhar a música)


def _com_cache(chave: str, buscar):
    c = CACHE.obter(chave)
    if c is not None:
        return c["valor"]
    v = buscar()
    CACHE.guardar(chave, v, CACHE_DIAS_ACHADO if v else CACHE_DIAS_SEM_DADO)
    return v


def acousticbrainz_tom(mbids, duracao=None, abrir=None):
    """Tonalidade e BPM estimados pelo AcousticBrainz para a(s) gravação(ões) do MusicBrainz. Lê até 3 análises de
    cada MBID e só aceita análises com a duração a até 6 s da faixa (outra versão não entra). A tonalidade é a da
    maioria; a confiança cai quando as análises discordam. None quando não há dado."""
    mbids = [m for m in dict.fromkeys(mbids or []) if re.fullmatch(r"[0-9a-f\-]{36}", str(m or ""))][:3]
    if not mbids:
        return None

    def buscar():
        ids = ";".join("%s:%d" % (m, k) for m in mbids for k in range(3))
        url = ("%s/low-level?recording_ids=%s&features=%s" % (
            ACOUSTICBRAINZ_API, ids, "tonal.key_key;tonal.key_scale;tonal.key_strength;rhythm.bpm"))
        d = _pedir_json(url, abrir, timeout=30.0)
        if not isinstance(d, dict):
            return None
        amostras = []
        for mbid, subs in d.items():
            if mbid == "mbid_mapping" or not isinstance(subs, dict):
                continue
            for sub in subs.values():
                if not isinstance(sub, dict):
                    continue
                ton, rit = sub.get("tonal") or {}, sub.get("rhythm") or {}
                tom = tom_de_texto("%s %s" % (ton.get("key_key") or "", ton.get("key_scale") or "")) \
                    if ton.get("key_key") and ton.get("key_scale") in ("major", "minor") else None
                dur = ((sub.get("metadata") or {}).get("audio_properties") or {}).get("length")
                if duracao and dur and abs(float(dur) - float(duracao)) > 6:
                    continue
                amostras.append({"tom": tom, "forca": float(ton.get("key_strength") or 0),
                                 "bpm": float(rit.get("bpm") or 0) or None, "mbid": mbid})
        com_tom = [a for a in amostras if a["tom"]]
        if not amostras:
            return None
        r = {"fonte": "AcousticBrainz", "n": len(amostras), "mbid": amostras[0]["mbid"],
             "link": "https://acousticbrainz.org/%s" % amostras[0]["mbid"]}
        if com_tom:
            votos: dict = {}
            for a in com_tom:
                k = (a["tom"]["tonica"], a["tom"]["modo"])
                votos.setdefault(k, []).append(a["forca"])
            (ton, modo), forcas = max(votos.items(), key=lambda kv: (len(kv[1]), sum(kv[1])))
            frac = len(forcas) / len(com_tom)
            media = sum(forcas) / len(forcas)
            if frac == 1 and len(com_tom) >= 2 and media >= 0.55:
                conf = "alta"
            elif frac > 0.5 and media >= 0.45:
                conf = "media"
            else:
                conf = "baixa"
            r.update(tom=nome_tom(ton, modo), confianca=conf, concordam=len(forcas), analises=len(com_tom),
                     forca=round(media, 2))
        bpms = sorted(a["bpm"] for a in amostras if a["bpm"] and 40 <= a["bpm"] <= 250)
        if bpms:
            r["bpm"] = round(bpms[len(bpms) // 2], 1)
        return r if (r.get("tom") or r.get("bpm")) else None
    return _com_cache("ab:" + ",".join(mbids) + ":%s" % (round(float(duracao)) if duracao else ""), buscar)


def reccobeats_tom(spotify_id: str = "", isrc: str = "", duracao=None, abrir=None):
    """Tonalidade e BPM estimados pelo ReccoBeats para a faixa do Spotify (pelo ID; sem ID, pelo ISRC com a duração
    a até 3 s). Confiança sempre "baixa" para a tonalidade (ver o comentário acima). None quando não há dado."""
    spotify_id = spotify_id if re.fullmatch(r"[A-Za-z0-9]{22}", str(spotify_id or "")) else ""
    isrc = re.sub(r"[^A-Z0-9]", "", str(isrc or "").upper())
    if not spotify_id and not isrc:
        return None

    def buscar():
        sid = spotify_id
        if not sid:
            d = _pedir_json("%s/track?ids=%s" % (RECCOBEATS_API, isrc), abrir)
            cands = []
            for t in (d or {}).get("content") or [] if isinstance(d, dict) else []:
                if not isinstance(t, dict) or str(t.get("isrc") or "").upper() != isrc:
                    continue
                m = re.search(r"/track/([A-Za-z0-9]{22})", str(t.get("href") or ""))
                if not m:
                    continue
                if duracao and t.get("durationMs") and abs(t["durationMs"] / 1000.0 - float(duracao)) > 3:
                    continue
                cands.append(m.group(1))
            if not cands:
                return None
            sid = cands[0]
        d = _pedir_json("%s/audio-features?ids=%s" % (RECCOBEATS_API, sid), abrir)
        itens = (d or {}).get("content") if isinstance(d, dict) else None
        if not itens or not isinstance(itens[0], dict):
            return None
        a = itens[0]
        r = {"fonte": "ReccoBeats", "id": sid, "confianca": "baixa"}
        try:
            k, modo = int(a.get("key", -1)), a.get("mode")
        except (TypeError, ValueError):
            k, modo = -1, None
        if 0 <= k <= 11 and modo in (0, 1):
            r["tom"] = nome_tom(k, "maior" if modo == 1 else "menor")
        try:
            bpm = float(a.get("tempo") or 0)
        except (TypeError, ValueError):
            bpm = 0
        if 40 <= bpm <= 250:
            r["bpm"] = round(bpm, 1)
        return r if (r.get("tom") or r.get("bpm")) else None
    return _com_cache("rb:%s:%s:%s" % (spotify_id, isrc, round(float(duracao)) if duracao else ""), buscar)


def _campo_est(valor, fonte, confianca):
    c = _campo(valor, fonte)
    if c:
        c.update(tipo="externa", confianca=confianca)
    return c


def combinar_tom_bpm(f: dict, estimativas: list) -> None:
    """Completa BPM, tonalidade e modo da ficha, CAMPO A CAMPO, com as estimativas externas (na ordem de confiança),
    sem trocar nada que já veio publicado. Registra as divergências entre fontes em f['divergencias'] e todas as
    leituras em f['leituras'] (fonte, tonalidade, BPM, tipo)."""
    f.setdefault("divergencias", [])
    f.setdefault("leituras", [])
    pub_tom = f.get("_tom_pub")
    for e in estimativas:
        if not e:
            continue
        f["leituras"].append({"fonte": e["fonte"], "tom": (e.get("tom") or {}).get("nome_pt"),
                              "bpm": e.get("bpm"), "tipo": "estimativa", "confianca": e.get("confianca")})
    ests = [e for e in estimativas if e]
    # tonalidade e modo
    if not f.get("tom"):
        for e in ests:
            if e.get("tom") and e.get("confianca") in ("alta", "media", "baixa"):
                f["tom"] = _campo_est(e["tom"]["nome_pt"], e["fonte"], e["confianca"])
                f["modo"] = _campo_est("Maior" if e["tom"]["modo"] == "maior" else "Menor", e["fonte"], e["confianca"])
                if e.get("link"):
                    f.setdefault("links", {})["acousticbrainz"] = e["link"]
                break
    elif pub_tom and pub_tom.get("modo") is None and not f.get("modo"):
        # a fonte publicou só a nota: o modo vem de uma estimativa com a MESMA tônica (senão fica "Não disponível")
        for e in ests:
            if e.get("tom") and e["tom"]["tonica"] == pub_tom["tonica"]:
                f["modo"] = _campo_est("Maior" if e["tom"]["modo"] == "maior" else "Menor", e["fonte"],
                                       e.get("confianca"))
                f["tom"] = _campo(e["tom"]["nome_pt"], f["tom"]["fonte"] + " + " + e["fonte"])
                break
    # BPM
    if not f.get("bpm"):
        for e in ests:
            if e.get("bpm"):
                f["bpm"] = _campo_est(e["bpm"], e["fonte"], "media" if e["fonte"] == "AcousticBrainz" else "baixa")
                break
    # divergências (todas as fontes, publicadas e estimadas)
    toms = ([("%s (publicado)" % f["tom"]["fonte"], pub_tom)] if pub_tom and pub_tom.get("modo") else []) + \
        [(e["fonte"], e["tom"]) for e in ests if e.get("tom")]
    for i in range(len(toms)):
        for j in range(i + 1, len(toms)):
            (fa, ta), (fb, tb) = toms[i], toms[j]
            if (ta["tonica"], ta["modo"]) == (tb["tonica"], tb["modo"]):
                continue
            rel = " (tonalidades relativas, mesma armadura)" if relativas(ta, tb) else ""
            f["divergencias"].append("Tonalidade: %s diz %s; %s diz %s%s." % (fa, ta["nome_pt"], fb, tb["nome_pt"],
                                                                              rel))
    bpms = ([("%s (publicado)" % f["bpm"]["fonte"], f["bpm"]["valor"])] if f.get("bpm") and
            f["bpm"].get("tipo") != "externa" else []) + [(e["fonte"], e["bpm"]) for e in ests if e.get("bpm")]
    for i in range(len(bpms)):
        for j in range(i + 1, len(bpms)):
            (fa, a), (fb, b) = bpms[i], bpms[j]
            if abs(a - b) <= 2:
                continue
            dobro = " (um é o dobro do outro: a mesma pulsação contada de outro jeito)" if \
                abs(a * 2 - b) <= 3 or abs(b * 2 - a) <= 3 else ""
            f["divergencias"].append("BPM: %s diz %g; %s diz %g%s." % (fa, a, fb, b, dobro))


def ficha_da_musica(escolha: dict, chave_getsongbpm: str = "", abrir=None, estimativas: bool = True) -> dict:
    """A ficha completa de UMA música já escolhida (um resultado de buscar_musicas ou os dados de um link). Cada campo é
    {'valor', 'fonte'} ou None. Junta Deezer, MusicBrainz e GetSongBPM; a falha de uma fonte vira um aviso."""
    f = {"titulo": escolha.get("titulo") or "", "artistas": [a for a in escolha.get("artistas") or [] if a] or
         ([escolha["artista"]] if escolha.get("artista") else []), "capa": escolha.get("capa") or "",
         "explicita": bool(escolha.get("explicita")), "avisos": [], "fontes": [], "creditos": [], "links": {}}
    for k in ("album", "duracao", "bpm", "tom", "modo", "lancamento", "gravadora", "faixa", "popularidade", "isrc",
              "upc", "compasso", "generos"):
        f[k] = None
    origem = escolha.get("fonte_link") or escolha.get("fonte_busca") or ""
    f["album"] = _campo(escolha.get("album"), origem)
    f["duracao"] = _campo(escolha.get("duracao"), origem)
    f["isrc"] = _campo((escolha.get("isrc") or "").upper(), origem)

    def fonte(nome):
        if nome not in f["fontes"]:
            f["fontes"].append(nome)
    if origem:
        fonte(origem)
    # ---- Deezer
    trk = None
    try:
        if escolha.get("deezer_id"):
            trk = _deezer("/track/%s" % escolha["deezer_id"], abrir)
        elif escolha.get("isrc"):
            trk = _deezer("/track/isrc:%s" % urllib.parse.quote(escolha["isrc"]), abrir)
        if trk and escolha.get("isrc") and trk.get("isrc") and trk["isrc"].upper() != escolha["isrc"].upper():
            trk = None
    except ErroFonte as e:
        f["avisos"].append("Deezer: %s." % e)
    if trk:
        fonte("Deezer")
        f["links"]["deezer"] = trk.get("link") or ""
        f["titulo"] = f["titulo"] or trk.get("title") or ""
        contrib = [c.get("name") for c in trk.get("contributors") or [] if c.get("name")]
        if contrib:
            f["artistas"] = contrib
        elif not f["artistas"] and trk.get("artist"):
            f["artistas"] = [trk["artist"].get("name")]
        f["duracao"] = f["duracao"] or _campo(trk.get("duration"), "Deezer")
        f["isrc"] = f["isrc"] or _campo((trk.get("isrc") or "").upper(), "Deezer")
        f["lancamento"] = _campo(trk.get("release_date") if trk.get("release_date") not in ("0000-00-00",) else "",
                                 "Deezer")
        if trk.get("track_position"):
            f["faixa"] = _campo("%s" % trk["track_position"], "Deezer")
        f["popularidade"] = _campo(trk.get("rank"), "Deezer")
        f["explicita"] = f["explicita"] or bool(trk.get("explicit_lyrics"))
        try:
            bpm = float(trk.get("bpm") or 0)
        except (TypeError, ValueError):
            bpm = 0
        if 40 <= bpm <= 250:
            f["bpm"] = _campo(round(bpm, 1), "Deezer")
        alb = trk.get("album") or {}
        f["album"] = f["album"] or _campo(alb.get("title"), "Deezer")
        f["capa"] = f["capa"] or alb.get("cover_big") or alb.get("cover_medium") or ""
        if alb.get("id"):
            try:
                a = _deezer("/album/%s" % alb["id"], abrir) or {}
                f["upc"] = _campo(a.get("upc"), "Deezer")
                f["gravadora"] = _campo(a.get("label"), "Deezer")
                if a.get("nb_tracks") and f["faixa"]:
                    f["faixa"] = _campo("%s de %s" % (f["faixa"]["valor"], a["nb_tracks"]), "Deezer")
                f["lancamento"] = f["lancamento"] or _campo(a.get("release_date"), "Deezer")
                gen = [g.get("name") for g in (a.get("genres") or {}).get("data") or [] if g.get("name")]
                f["generos"] = _campo(", ".join(gen), "Deezer")
            except ErroFonte as e:
                f["avisos"].append("Deezer (álbum): %s." % e)
    # ---- MusicBrainz (créditos e o que faltar)
    isrc = (f["isrc"] or {}).get("valor") or ""
    mbids = []
    try:
        rec_id = escolha.get("mbid") or ""
        if not rec_id and isrc:
            d = _mb("/isrc/%s?inc=artist-credits+releases" % urllib.parse.quote(isrc), abrir) or {}
            recs = d.get("recordings") or []
            if recs:
                rec_id = recs[0].get("id") or ""
        if rec_id:
            rec = _mb("/recording/%s?inc=artist-credits+artist-rels+work-rels+work-level-rels+releases" % rec_id,
                      abrir) or {}
            if rec:
                mbids.append(rec_id)
                fonte("MusicBrainz")
                f["creditos"] = _creditos_mb(rec)
                f["links"]["musicbrainz"] = "https://musicbrainz.org/recording/%s" % rec_id
                rels = [r for r in rec.get("releases") or [] if isinstance(r, dict)]
                if rels:
                    r0 = sorted(rels, key=lambda r: r.get("date") or "9999")[0]
                    f["lancamento"] = f["lancamento"] or _campo(r0.get("date"), "MusicBrainz")
                    f["album"] = f["album"] or _campo(r0.get("title"), "MusicBrainz")
                    if not f["gravadora"] or not f["upc"]:
                        rel = _mb("/release/%s?inc=labels" % r0["id"], abrir) or {}
                        lab = [li.get("label", {}).get("name") for li in rel.get("label-info") or []
                               if (li.get("label") or {}).get("name")]
                        f["gravadora"] = f["gravadora"] or _campo(", ".join(dict.fromkeys(lab)), "MusicBrainz")
                        f["upc"] = f["upc"] or _campo(rel.get("barcode"), "MusicBrainz")
    except ErroFonte as e:
        f["avisos"].append("MusicBrainz: %s." % e)
    # ---- GetSongBPM (BPM e tonalidade publicados; só com a chave da própria pessoa)
    if chave_getsongbpm and f["titulo"] and f["artistas"]:
        try:
            g = _gsb(f["titulo"], f["artistas"][0], chave_getsongbpm, abrir=abrir)
            if g:
                fonte("GetSongBPM")
                f["links"]["getsongbpm"] = g["url"]
                if g.get("bpm"):
                    if f["bpm"] and abs(f["bpm"]["valor"] - g["bpm"]) > 1.5:
                        f["avisos"].append("O Deezer informa %g BPM e o GetSongBPM, %g." % (f["bpm"]["valor"], g["bpm"]))
                    f["bpm"] = f["bpm"] or _campo(g["bpm"], "GetSongBPM")
                if g.get("tom"):
                    f["_tom_pub"] = g["tom"]
                    f["tom"] = _campo(g["tom"]["nome_pt"], "GetSongBPM")
                    if g["tom"].get("modo"):                    # nota isolada não define o modo
                        f["modo"] = _campo("Maior" if g["tom"]["modo"] == "maior" else "Menor", "GetSongBPM")
                f["compasso"] = _campo(g.get("compasso"), "GetSongBPM")
        except ErroFonte as e:
            f["avisos"].append("GetSongBPM: %s." % e)
    # ---- estimativas externas (Beta 3.8): só para o que nenhuma fonte publicou, e marcadas como estimativa
    precisa = not f["bpm"] or not f["tom"] or (f["tom"] and not f["modo"])
    if estimativas and precisa:
        dur = (f["duracao"] or {}).get("valor")
        ests = []
        try:
            ests.append(acousticbrainz_tom(mbids, dur, abrir))
        except ErroFonte as e:
            f["avisos"].append("AcousticBrainz: %s." % e)
        if not (ests[-1:] and ests[-1] and ests[-1].get("tom") and ests[-1].get("bpm")):
            try:
                ests.append(reccobeats_tom(escolha.get("spotify_id") or "", isrc, dur, abrir))
            except ErroFonte as e:
                f["avisos"].append("ReccoBeats: %s." % e)
        for e in ests:
            if e:
                fonte(e["fonte"])
        combinar_tom_bpm(f, ests)
    else:
        f.setdefault("divergencias", [])
        f.setdefault("leituras", [])
    f.pop("_tom_pub", None)
    f["links"]["tunebat"] = url_tunebat(f["titulo"], (f["artistas"] or [""])[0])
    return f


def url_tunebat(titulo: str, artista: str = "") -> str:
    """A busca do TuneBat no NAVEGADOR (o app não lê o site: os termos do TuneBat proíbem acesso automatizado)."""
    q = " ".join(p for p in (artista, titulo) if p).strip()
    return "https://tunebat.com/Search?q=%s" % urllib.parse.quote(q) if q else "https://tunebat.com/"
