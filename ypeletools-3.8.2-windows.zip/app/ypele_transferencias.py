#!/usr/bin/env python3
"""
yTorrents (Beta 3.7): os motores de transferência do yPeléTools, SEM interface (a aba yTorrents fica no app).

O que existe aqui, cada parte com um mecanismo REAL (nada de porcentagem, velocidade ou peers simulados):
  - HTTP/HTTPS ......... download por streaming (blocos de 256 KiB, nunca o arquivo inteiro na memória), retomada por
                         HTTP Range (com If-Range: se o arquivo mudou no servidor, recomeça do zero), novas tentativas
                         com espera crescente, redirecionamentos, nome/extensão/tamanho pelos cabeçalhos, limite de
                         velocidade, conferência de tamanho e (quando há como saber) de hash, e página HTML com UM link
                         de download claro seguida uma vez.
  - Provedores ......... interface comum (Provedor): cada serviço transforma o link da página num endereço direto.
                         Pixeldrain (API pública documentada), MediaFire (botão de download da página pública), Dropbox
                         (?dl=1, documentado), MEGA (API pública + AES do próprio MEGA, chave no link) e um aviso claro
                         para serviços que exigem CAPTCHA/contagem regressiva no navegador (DropGalaxy e afins): o app
                         não contorna CAPTCHA, login, limite nem paywall.
  - BitTorrent ......... cliente próprio (BEP 3) em asyncio, numa thread só: arquivos .torrent e magnet links (troca de
                         metadados BEP 9/10), rastreadores HTTP e UDP (BEP 15), DHT (BEP 5) para achar peers,
                         escolha da peça mais rara, conferência SHA-1 de cada peça, retomada (as peças conferidas ficam
                         registradas e o que está no disco é conferido de novo ao abrir), envio de peças para os peers
                         durante o download e a estrutura de pastas do torrent preservada. Limites: sem criptografia de
                         protocolo (MSE), sem uTP e sem torrents só v2 (BEP 52) — o app avisa.

Nada aqui usa a interface: o app chama Gerenciador e recebe eventos por ao_evento(tipo, *dados) (seguro entre threads).
"""

import asyncio
import base64
import binascii
import collections
import concurrent.futures
import hashlib
import html.parser
import ipaddress
import json
import os
import random
import re
import socket
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

VERSAO_MOTOR = "1"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
BLOCO_HTTP = 256 * 1024
TENTATIVAS_PADRAO = 5
SUFIXO_PARCIAL = ".ypele-parcial"


class ErroTransferencia(Exception):
    """Falha com mensagem já em português. `definitivo`: tentar de novo agora não adianta (404, link expirado...)."""

    def __init__(self, msg: str, definitivo: bool = False, detalhe: str = ""):
        super().__init__(msg)
        self.definitivo, self.detalhe = definitivo, detalhe


class Parado(Exception):
    """A transferência foi pausada ou cancelada pela pessoa (não é erro)."""


# ======================================================================================================================
# Nomes, tipos de arquivo e pastas
# ======================================================================================================================
_PROIBIDOS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
# Caracteres que não aparecem (ou aparecem como um vão enorme): preenchimento coreano (U+3164, U+115F/1160, U+FFA0),
# braille em branco (U+2800), espaços de largura zero, marcas de direção e o hífen invisível. Nomes de arquivo do
# MediaFire às vezes vêm cheios deles ("!ㅤㅤㅤㅤ CEU SPOP"): viram um espaço comum (Beta 3.7.1).
_INVISIVEIS = re.compile("[\u115f\u1160\u3164\uffa0\u2800\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069"
                         "\ufeff\u00ad\u180e]")


def nome_visivel(nome: str) -> str:
    """O nome como ele deve aparecer: sem caracteres invisíveis e sem sequências de espaços."""
    return re.sub(r"\s+", " ", _INVISIVEIS.sub(" ", str(nome or ""))).strip()
_RESERVADOS = {"con", "prn", "aux", "nul", *("com%d" % i for i in range(1, 10)), *("lpt%d" % i for i in range(1, 10))}


def nome_seguro(nome: str, limite: int = 150, padrao: str = "download") -> str:
    """Um componente de caminho válido no Windows: sem / \\ : * ? " < > |, sem controle, sem ponto/espaço no fim, sem
    nomes reservados (CON, NUL, COM1...). A extensão é preservada quando o nome precisa ser cortado."""
    t = _PROIBIDOS.sub("_", nome_visivel(nome)).strip().strip(". ")
    t = re.sub(r"\s+", " ", t)
    if not t:
        t = padrao
    if t.split(".")[0].strip().lower() in _RESERVADOS:
        t = "_" + t
    if len(t) > limite:
        base, ext = os.path.splitext(t)
        ext = ext if 1 < len(ext) <= 12 else ""
        t = base[:max(1, limite - len(ext))].rstrip(". ") + ext
    return t


def nome_livre(pasta: Path, nome: str, e_pasta: bool = False, ocupados=()) -> Path:
    """`pasta/nome`, ou 'nome (2)', 'nome (3)'... se já existir (arquivo, pasta ou parcial de outra transferência).
    Nada é sobrescrito."""
    pasta = Path(pasta)
    base, ext = (nome, "") if e_pasta else os.path.splitext(nome)
    ocup = {str(o).casefold() for o in ocupados}
    for n in range(1, 10000):
        cand = pasta / (nome if n == 1 else "%s (%d)%s" % (base, n, ext))
        if cand.exists() or Path(str(cand) + SUFIXO_PARCIAL).exists() or str(cand).casefold() in ocup:
            continue
        return cand
    return pasta / ("%s (%s)%s" % (base, uuid.uuid4().hex[:6], ext))


TIPOS_ARQUIVO = {
    "compactado": {"zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "cab"},
    "torrent": {"torrent"},
    "video": {"mp4", "mkv", "avi", "mov", "webm", "wmv", "flv", "m4v", "mpg", "mpeg", "ts", "3gp"},
    "audio": {"mp3", "wav", "flac", "m4a", "aac", "ogg", "opus", "wma", "aiff", "alac"},
    "disco": {"iso", "img", "vhd", "vhdx", "dmg", "cue", "nrg"},
    "instalador": {"exe", "msi", "msix", "appx", "apk", "deb", "rpm"},
    "documento": {"pdf", "doc", "docx", "odt", "rtf", "txt", "epub", "xls", "xlsx", "ppt", "pptx", "csv"},
    "imagem": {"jpg", "jpeg", "png", "webp", "gif", "bmp", "tif", "tiff", "avif", "heic", "svg"},
}


def tipo_arquivo(nome: str, eh_torrent: bool = False) -> str:
    """'compactado', 'torrent', 'video', 'audio', 'disco', 'instalador', 'documento', 'imagem', 'pasta' ou 'outro'
    (o ícone de cada linha da lista). Sem nome ainda: 'torrent' para torrents/magnets, 'outro' para o resto."""
    ext = os.path.splitext(str(nome or ""))[1].lower().lstrip(".")
    for tipo, exts in TIPOS_ARQUIVO.items():
        if ext in exts:
            return tipo
    return "torrent" if eh_torrent else "outro"


# ======================================================================================================================
# Bencode (BEP 3)
# ======================================================================================================================
class ErroBencode(ValueError):
    pass


def bdecode(dados: bytes, guardar_info: bool = False):
    """Decodifica bencode. Com `guardar_info`, devolve (objeto, bytes crus do dicionário 'info'), que é o que o
    info_hash usa (re-codificar pode mudar bytes de um .torrent fora do padrão)."""
    dados = bytes(dados)
    pos = [0]
    cru = {}

    def ler(prof=0):
        if prof > 64:
            raise ErroBencode("aninhamento demais")
        if pos[0] >= len(dados):
            raise ErroBencode("fim inesperado")
        c = dados[pos[0]:pos[0] + 1]
        if c == b"i":
            fim = dados.index(b"e", pos[0])
            txt = dados[pos[0] + 1:fim]
            if not re.fullmatch(rb"-?(0|[1-9][0-9]*)", txt) or txt == b"-0":
                raise ErroBencode("inteiro inválido")
            pos[0] = fim + 1
            return int(txt)
        if c == b"l":
            pos[0] += 1
            lst = []
            while dados[pos[0]:pos[0] + 1] != b"e":
                lst.append(ler(prof + 1))
            pos[0] += 1
            return lst
        if c == b"d":
            pos[0] += 1
            d = {}
            while dados[pos[0]:pos[0] + 1] != b"e":
                k = ler(prof + 1)
                if not isinstance(k, bytes):
                    raise ErroBencode("chave que não é texto")
                ini = pos[0]
                v = ler(prof + 1)
                if k == b"info" and prof == 0:
                    cru["info"] = dados[ini:pos[0]]
                d[k] = v
            pos[0] += 1
            return d
        if c.isdigit():
            sep = dados.index(b":", pos[0])
            n = int(dados[pos[0]:sep])
            ini = sep + 1
            if ini + n > len(dados):
                raise ErroBencode("texto cortado")
            pos[0] = ini + n
            return dados[ini:ini + n]
        raise ErroBencode("byte inesperado %r" % c)

    try:
        obj = ler()
    except (IndexError, ValueError) as e:
        if isinstance(e, ErroBencode):
            raise
        raise ErroBencode(str(e))
    if guardar_info:
        return obj, cru.get("info")
    return obj


def bencode(o) -> bytes:
    if isinstance(o, bool):
        o = int(o)
    if isinstance(o, int):
        return b"i%de" % o
    if isinstance(o, str):
        o = o.encode("utf-8")
    if isinstance(o, (bytes, bytearray)):
        return b"%d:%s" % (len(o), bytes(o))
    if isinstance(o, (list, tuple)):
        return b"l" + b"".join(bencode(x) for x in o) + b"e"
    if isinstance(o, dict):
        itens = sorted(((k.encode("utf-8") if isinstance(k, str) else k), v) for k, v in o.items())
        return b"d" + b"".join(bencode(k) + bencode(v) for k, v in itens) + b"e"
    raise TypeError("não sei codificar %r" % type(o))


# ======================================================================================================================
# Metadados de torrent e magnet links
# ======================================================================================================================
def _txt(b) -> str:
    if isinstance(b, bytes):
        try:
            return b.decode("utf-8")
        except UnicodeDecodeError:
            return b.decode("latin-1")
    return str(b or "")


class MetaTorrent:
    """O dicionário 'info' de um torrent v1 (ou híbrido v1+v2). Caminhos já limpos para o Windows (sem '..', sem
    caracteres proibidos), na estrutura original do torrent."""

    def __init__(self, info_cru: bytes, rastreadores=(), web_seeds=()):
        info = bdecode(info_cru)
        if not isinstance(info, dict):
            raise ErroTransferencia("O torrent é inválido (dicionário 'info' ausente).", True)
        if b"pieces" not in info:
            if b"meta version" in info or b"file tree" in info:
                raise ErroTransferencia("Este torrent é só da versão 2 (BEP 52), que o motor do app ainda não "
                                        "baixa. Procure o mesmo conteúdo num torrent v1 ou híbrido.", True)
            raise ErroTransferencia("O torrent é inválido (sem a lista de peças).", True)
        self.info_cru = bytes(info_cru)
        self.info_hash = hashlib.sha1(self.info_cru).digest()
        self.nome = nome_seguro(_txt(info.get(b"name.utf-8") or info.get(b"name")) or self.info_hash.hex()[:12],
                                padrao="torrent")
        self.tam_peca = int(info.get(b"piece length") or 0)
        pecas = info[b"pieces"]
        if not self.tam_peca or self.tam_peca < 1024 or len(pecas) % 20:
            raise ErroTransferencia("O torrent é inválido (tamanho de peça ou hashes).", True)
        self.hashes = [pecas[i:i + 20] for i in range(0, len(pecas), 20)]
        self.privado = bool(info.get(b"private"))
        self.arquivos = []                   # [(partes do caminho dentro da pasta do torrent, tamanho)]
        if b"files" in info:
            self.multi = True
            for f in info[b"files"]:
                partes = f.get(b"path.utf-8") or f.get(b"path") or []
                limpas = [nome_seguro(_txt(p), padrao="_") for p in partes if _txt(p) not in ("", ".", "..")]
                if not limpas:
                    continue
                if f.get(b"attr", b"") and b"p" in f.get(b"attr", b""):
                    limpas = None            # BEP 47: arquivo de preenchimento (padding): conta no tamanho, não vai ao disco
                self.arquivos.append((limpas, int(f[b"length"])))
        else:
            self.multi = False
            self.arquivos.append(([self.nome], int(info[b"length"])))
        self.total = sum(t for _, t in self.arquivos)
        if self.total <= 0:
            raise ErroTransferencia("O torrent não tem conteúdo.", True)
        esperadas = (self.total + self.tam_peca - 1) // self.tam_peca
        if esperadas != len(self.hashes):
            raise ErroTransferencia("O torrent é inválido (número de peças não confere com o tamanho).", True)
        self.rastreadores = [r for r in rastreadores if r]
        self.web_seeds = list(web_seeds)
        self.comentario, self.criado_por, self.criado_em = "", "", 0

    @property
    def n_pecas(self) -> int:
        return len(self.hashes)

    def tamanho_peca(self, i: int) -> int:
        if i == self.n_pecas - 1:
            return self.total - self.tam_peca * (self.n_pecas - 1)
        return self.tam_peca

    @classmethod
    def de_arquivo(cls, dados: bytes) -> "MetaTorrent":
        try:
            raiz, info_cru = bdecode(dados, guardar_info=True)
        except ErroBencode:
            raise ErroTransferencia("O arquivo .torrent está corrompido ou não é um torrent.", True)
        if not isinstance(raiz, dict) or info_cru is None:
            raise ErroTransferencia("O arquivo .torrent não tem o dicionário 'info'.", True)
        rast = []
        if isinstance(raiz.get(b"announce-list"), list):
            for nivel in raiz[b"announce-list"]:
                if isinstance(nivel, list):
                    rast.extend(_txt(u) for u in nivel if isinstance(u, bytes))
        if isinstance(raiz.get(b"announce"), bytes):
            rast.insert(0, _txt(raiz[b"announce"]))
        ws = raiz.get(b"url-list")
        ws = [ws] if isinstance(ws, bytes) else (ws if isinstance(ws, list) else [])
        vistos, unicos = set(), []
        for r in rast:
            if r not in vistos:
                vistos.add(r)
                unicos.append(r)
        m = cls(info_cru, unicos, [_txt(w) for w in ws if isinstance(w, bytes)])
        m.comentario = _txt(raiz.get(b"comment.utf-8") or raiz.get(b"comment") or b"")[:2000]
        m.criado_por = _txt(raiz.get(b"created by") or b"")[:200]
        m.criado_em = int(raiz.get(b"creation date") or 0) if isinstance(raiz.get(b"creation date"), int) else 0
        return m


# ---------- escolha de arquivos e prioridades (Beta 3.8) ----------
# Prioridade de cada arquivo do torrent: 0 = não baixar, 1 = baixa, 2 = normal, 3 = alta. Só as peças que tocam algum
# arquivo escolhido são pedidas, na ordem: prioridade mais alta primeiro, depois a peça mais rara.
PRIORIDADES = {0: "Não baixar", 1: "Baixa", 2: "Normal", 3: "Alta"}
PASTA_PARTES = ".ypele-partes"            # pedaços de arquivos NÃO escolhidos que caem em peças compartilhadas


def prioridades_do_item(meta: "MetaTorrent", item: dict) -> list:
    """A prioridade de cada entrada de meta.arquivos (preenchimento = 0). Sem escolha guardada: tudo normal."""
    salvo = item.get("prioridades")
    out = []
    for k, (partes, _t) in enumerate(meta.arquivos):
        if partes is None:
            out.append(0)
            continue
        v = 2
        if isinstance(salvo, list) and k < len(salvo):
            try:
                v = max(0, min(3, int(salvo[k])))
            except (TypeError, ValueError):
                v = 2
        out.append(v)
    return out


def arquivos_do_torrent(meta: "MetaTorrent") -> list:
    """[{'indice', 'caminho' (com /), 'partes', 'tamanho'}] na ordem do torrent, sem os arquivos de preenchimento."""
    return [{"indice": k, "caminho": "/".join(partes), "partes": list(partes), "tamanho": t}
            for k, (partes, t) in enumerate(meta.arquivos) if partes is not None]


def resumo_torrent(meta: "MetaTorrent") -> dict:
    """O que a janela de adicionar torrent mostra antes de baixar."""
    return {"nome": meta.nome, "total": meta.total, "info_hash": meta.info_hash.hex(), "n_pecas": meta.n_pecas,
            "tam_peca": meta.tam_peca, "privado": meta.privado, "multi": meta.multi, "comentario": meta.comentario,
            "criado_por": meta.criado_por, "criado_em": meta.criado_em, "rastreadores": list(meta.rastreadores),
            "web_seeds": list(meta.web_seeds), "arquivos": arquivos_do_torrent(meta)}


def ler_torrent(entrada: str) -> "MetaTorrent":
    """Lê um .torrent (arquivo ou link): MetaTorrent ou ErroTransferencia com o motivo (corrompido, v2, grande...)."""
    return MetaTorrent.de_arquivo(_ler_torrent_da_entrada(entrada))


def _url_scrape(url: str) -> str:
    """BEP 48: o 'scrape' de um rastreador HTTP fica no mesmo endereço, com 'announce' trocado por 'scrape'."""
    p = urllib.parse.urlsplit(url)
    pasta, _, ultimo = p.path.rpartition("/")
    if not ultimo.startswith("announce"):
        return ""
    return urllib.parse.urlunsplit((p.scheme, p.netloc, pasta + "/" + "scrape" + ultimo[len("announce"):], p.query,
                                    ""))


def scrape_http(url: str, info_hash: bytes, timeout: float = 10.0) -> dict:
    alvo = _url_scrape(url)
    if not alvo:
        raise ErroTransferencia("o rastreador não informa números (sem scrape)")
    sep = "&" if "?" in alvo else "?"
    try:
        with _abrir(alvo + sep + "info_hash=" + urllib.parse.quote(info_hash, safe=""), timeout=timeout) as r:
            d = bdecode(r.read(1_000_000))
    except urllib.error.HTTPError as e:
        raise ErroTransferencia("respondeu %d" % e.code)
    except (urllib.error.URLError, OSError, ErroBencode, ValueError) as e:
        raise ErroTransferencia("indisponível (%s)" % getattr(e, "reason", e))
    f = (d.get(b"files") or {}).get(info_hash) if isinstance(d, dict) and isinstance(d.get(b"files"), dict) else None
    if not isinstance(f, dict):
        if isinstance(d, dict) and b"failure reason" in d:
            raise ErroTransferencia("recusou: %s" % _txt(d[b"failure reason"])[:100])
        raise ErroTransferencia("não conhece este torrent")
    return {"seeds": int(f.get(b"complete") or 0), "peers": int(f.get(b"incomplete") or 0),
            "concluidos": int(f.get(b"downloaded") or 0)}


async def scrape_udp(url: str, info_hash: bytes) -> dict:
    p = urllib.parse.urlsplit(url)
    if not p.hostname or not p.port:
        raise ErroTransferencia("rastreador UDP sem porta")
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(p.hostname, p.port, type=socket.SOCK_DGRAM)
    except OSError as e:
        raise ErroTransferencia("não encontrado (%s)" % e)
    familia, _, _, _, ender = infos[0]
    transp, proto = await loop.create_datagram_endpoint(_ProtoUDP, family=familia)
    try:
        async def pedir(pacote: bytes, trans: int):
            for tentativa in range(2):
                transp.sendto(pacote, ender)
                try:
                    while True:
                        dados, _ = await asyncio.wait_for(proto.fila.get(), timeout=3 * (tentativa + 1))
                        if len(dados) >= 8 and struct.unpack(">I", dados[4:8])[0] == trans:
                            return dados
                except asyncio.TimeoutError:
                    continue
            raise ErroTransferencia("não respondeu")
        t = random.getrandbits(32)
        r = await pedir(struct.pack(">QII", 0x41727101980, 0, t), t)
        if struct.unpack(">I", r[:4])[0] != 0 or len(r) < 16:
            raise ErroTransferencia("recusou a conexão")
        t = random.getrandbits(32)
        r = await pedir(r[8:16] + struct.pack(">II", 2, t) + info_hash, t)
        if struct.unpack(">I", r[:4])[0] != 2 or len(r) < 20:
            raise ErroTransferencia("resposta inválida")
        seeds, concl, leech = struct.unpack(">III", r[8:20])
        return {"seeds": seeds, "peers": leech, "concluidos": concl}
    finally:
        transp.close()


def consultar_rastreadores(rastreadores, info_hash: bytes, limite: int = 10, deve_parar=None) -> list:
    """Disponibilidade informada por cada rastreador (scrape: só números, sem se anunciar como peer). Uma lista de
    {'url', 'ok', 'seeds', 'peers', 'concluidos', 'erro'}. Rode fora da interface."""
    out = []
    for url in list(dict.fromkeys(rastreadores or []))[:limite]:
        if deve_parar is not None and deve_parar():
            break
        r = {"url": url, "ok": False, "seeds": None, "peers": None, "concluidos": None, "erro": ""}
        try:
            if url.startswith(("http://", "https://")):
                r.update(scrape_http(url, info_hash), ok=True)
            elif url.startswith("udp://"):
                r.update(asyncio.run(asyncio.wait_for(scrape_udp(url, info_hash), 12)), ok=True)
            else:
                r["erro"] = "protocolo não suportado"
        except ErroTransferencia as e:
            r["erro"] = str(e)
        except (OSError, asyncio.TimeoutError, ValueError) as e:
            r["erro"] = "não respondeu" if isinstance(e, asyncio.TimeoutError) else str(e)[:80]
        out.append(r)
    return out


def ler_magnet(link: str) -> dict:
    """magnet:?xt=urn:btih:<hash hex ou base32>&dn=nome&tr=rastreador... -> {'info_hash': bytes, 'nome', 'rastreadores'}"""
    p = urllib.parse.urlsplit(str(link or "").strip())
    if p.scheme.lower() != "magnet":
        raise ErroTransferencia("Não é um magnet link.", True)
    q = urllib.parse.parse_qs(p.query)
    ih = None
    for xt in q.get("xt", []):
        m = re.fullmatch(r"urn:btih:([0-9A-Fa-f]{40}|[A-Za-z2-7]{32})", xt.strip())
        if m:
            v = m.group(1)
            ih = bytes.fromhex(v) if len(v) == 40 else base64.b32decode(v.upper())
            break
        if xt.startswith("urn:btmh:"):
            continue
    if ih is None:
        if any(x.startswith("urn:btmh:") for x in q.get("xt", [])):
            raise ErroTransferencia("Este magnet é só da versão 2 do BitTorrent, que o motor do app ainda não baixa.", True)
        raise ErroTransferencia("O magnet link não tem um código (info hash) válido.", True)
    return {"info_hash": ih, "nome": nome_seguro(q.get("dn", [""])[0], padrao="") if q.get("dn") else "",
            "rastreadores": [t for t in q.get("tr", []) if t], "web_seeds": q.get("ws", [])}


# ======================================================================================================================
# Entrada inteligente: o que é cada linha colada
# ======================================================================================================================
_URL_RE = re.compile(r"(magnet:\?[^\s<>\"']+|https?://[^\s<>\"']+)", re.I)


def classificar_linha(linha: str) -> dict:
    """{'tipo': 'magnet'|'torrent_url'|'torrent_arquivo'|'http'|'invalida', 'texto', 'provedor', 'motivo'}"""
    t = str(linha or "").strip().strip("<>\"'")
    if not t:
        return {"tipo": "vazia", "texto": "", "provedor": "", "motivo": ""}
    if t.lower().startswith("magnet:"):
        try:
            m = ler_magnet(t)
            return {"tipo": "magnet", "texto": t, "provedor": "magnet", "motivo": "", "nome": m["nome"],
                    "info_hash": m["info_hash"].hex()}
        except ErroTransferencia as e:
            return {"tipo": "invalida", "texto": t, "provedor": "", "motivo": str(e)}
    caminho = Path(t)
    if t.lower().endswith(".torrent") and not re.match(r"^[a-z]+://", t, re.I):
        if caminho.is_file():
            return {"tipo": "torrent_arquivo", "texto": str(caminho), "provedor": "torrent", "motivo": ""}
        return {"tipo": "invalida", "texto": t, "provedor": "", "motivo": "arquivo .torrent não encontrado"}
    m = _URL_RE.search(t)
    if not m:
        return {"tipo": "invalida", "texto": t, "provedor": "", "motivo": "não é um link HTTP/HTTPS, magnet ou .torrent"}
    url = m.group(1).rstrip(").,;")
    p = urllib.parse.urlsplit(url)
    if not p.netloc:
        return {"tipo": "invalida", "texto": t, "provedor": "", "motivo": "link sem endereço"}
    prov = provedor_para(url)
    if p.path.lower().endswith(".torrent"):
        return {"tipo": "torrent_url", "texto": url, "provedor": "torrent", "motivo": ""}
    if prov.e_pasta(url):
        return {"tipo": "pasta", "texto": url, "provedor": prov.chave, "motivo": ""}
    return {"tipo": "http", "texto": url, "provedor": prov.chave, "motivo": ""}


def classificar_texto(texto: str) -> list:
    """Várias linhas (uma por link). Linhas repetidas entram uma vez só."""
    saida, vistos = [], set()
    for ln in str(texto or "").splitlines():
        c = classificar_linha(ln)
        if c["tipo"] == "vazia":
            continue
        chave = c.get("info_hash") or c["texto"]
        if chave in vistos:
            continue
        vistos.add(chave)
        saida.append(c)
    return saida


# ======================================================================================================================
# HTTP: abrir, nomes pelos cabeçalhos, página HTML com link de download
# ======================================================================================================================
def _abrir(url: str, cabecalhos: dict = None, timeout: float = 30.0, metodo: str = None, dados: bytes = None):
    cab = {"User-Agent": UA, "Accept": "*/*", "Accept-Encoding": "identity"}
    cab.update(cabecalhos or {})
    req = urllib.request.Request(url, headers=cab, method=metodo, data=dados)
    return urllib.request.urlopen(req, timeout=timeout)


def nome_de_content_disposition(valor: str) -> str:
    if not valor:
        return ""
    m = re.search(r"filename\*\s*=\s*([^']*)'[^']*'([^;]+)", valor, re.I)
    if m:
        try:
            return urllib.parse.unquote(m.group(2).strip().strip('"'), encoding=m.group(1) or "utf-8")
        except LookupError:
            return urllib.parse.unquote(m.group(2).strip().strip('"'))
    m = re.search(r'filename\s*=\s*"((?:[^"\\]|\\.)*)"', valor, re.I) or re.search(r"filename\s*=\s*([^;]+)", valor, re.I)
    if m:
        bruto = m.group(1).strip()
        try:                                        # muitos servidores mandam UTF-8 cru no cabeçalho (lido como latin-1)
            bruto = bruto.encode("latin-1").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
        return bruto.replace('\\"', '"')
    return ""


_EXT_MIME = {"application/zip": ".zip", "application/x-rar-compressed": ".rar", "application/vnd.rar": ".rar",
             "application/x-7z-compressed": ".7z", "application/pdf": ".pdf", "video/mp4": ".mp4",
             "video/x-matroska": ".mkv", "audio/mpeg": ".mp3", "audio/flac": ".flac", "audio/wav": ".wav",
             "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "application/x-bittorrent": ".torrent",
             "application/x-iso9660-image": ".iso", "application/x-msdownload": ".exe",
             "application/x-msi": ".msi", "text/plain": ".txt", "application/json": ".json"}


def nome_da_resposta(resp, url_final: str) -> str:
    nome = nome_de_content_disposition(resp.headers.get("Content-Disposition", ""))
    if not nome:
        caminho = urllib.parse.urlsplit(url_final).path
        nome = urllib.parse.unquote(caminho.rsplit("/", 1)[-1])
    nome = nome_seguro(nome, padrao="")
    if not nome:
        nome = "download"
    if not os.path.splitext(nome)[1]:
        tipo = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        nome += _EXT_MIME.get(tipo, "")
    return nome


class _Links(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.refresh, self.titulo, self._no_titulo = [], "", "", False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a" and a.get("href"):
            self.links.append((a["href"], "download" in a, (a.get("id") or "") + " " + (a.get("class") or "")))
        elif tag == "meta" and (a.get("http-equiv") or "").lower() == "refresh":
            m = re.search(r"url\s*=\s*['\"]?([^'\";]+)", a.get("content") or "", re.I)
            if m:
                self.refresh = m.group(1).strip()
        elif tag == "title":
            self._no_titulo = True

    def handle_endtag(self, tag):
        if tag == "title":
            self._no_titulo = False

    def handle_data(self, data):
        if self._no_titulo:
            self.titulo += data


_EXT_DOWNLOAD = set().union(*TIPOS_ARQUIVO.values()) - {"txt", "csv", "svg", "html", "htm"}


def link_de_download_na_pagina(html_txt: str, base: str) -> str:
    """O endereço do arquivo numa página HTML, quando ela tem UM candidato claro (atributo download, link para um
    arquivo com extensão conhecida ou meta refresh). Mais de um candidato diferente = '' (o app não adivinha)."""
    p = _Links()
    try:
        p.feed(html_txt[:3_000_000])
    except Exception:
        return ""
    if p.refresh:
        return urllib.parse.urljoin(base, p.refresh)
    fortes, fracos = [], []
    for href, tem_download, _cls in p.links:
        alvo = urllib.parse.urljoin(base, href)
        if not alvo.lower().startswith(("http://", "https://")):
            continue
        ext = os.path.splitext(urllib.parse.urlsplit(alvo).path)[1].lower().lstrip(".")
        if tem_download:
            fortes.append(alvo)
        elif ext in _EXT_DOWNLOAD:
            fracos.append(alvo)
    for lista in (fortes, fracos):
        unicos = list(dict.fromkeys(lista))
        if len(unicos) == 1:
            return unicos[0]
        if unicos:
            return ""
    return ""


# ======================================================================================================================
# Provedores (serviços de hospedagem): interface comum
# ======================================================================================================================
class Recurso:
    """O que um provedor devolve: um endereço que dá para baixar por HTTP (e o que mais se souber do arquivo).
    `decifrar`: função opcional (bloco, posição) -> bloco, para serviços que entregam o arquivo cifrado (MEGA).
    `conferir`: função opcional (caminho) -> None que confere a integridade no fim (levanta ErroTransferencia)."""

    def __init__(self, url, nome="", tamanho=None, sha256="", md5="", cabecalhos=None, decifrar=None, conferir=None,
                 origem=""):
        self.url, self.nome, self.tamanho, self.sha256, self.md5 = url, nome, tamanho, sha256, md5
        self.cabecalhos, self.decifrar, self.conferir, self.origem = dict(cabecalhos or {}), decifrar, conferir, origem


class Provedor:
    """Para adicionar um serviço: subclasse com `chave`, `nome`, `dominios` e `resolver(url, sessao) -> Recurso`
    (ou levantar ErroTransferencia com o motivo). Registre em PROVEDORES. Nada na interface precisa mudar."""
    chave, nome, dominios = "http", "Link direto", ()
    precisa_navegador = False          # serviços com CAPTCHA/contagem regressiva: o app explica e não tenta

    def reconhece(self, url: str) -> bool:
        host = (urllib.parse.urlsplit(url).hostname or "").lower()
        return any(host == d or host.endswith("." + d) for d in self.dominios)

    def resolver(self, url: str) -> Recurso:
        return Recurso(url, origem=self.nome)

    # ---- pastas (Beta 3.7.1): um serviço que lista pastas implementa estes dois métodos
    def e_pasta(self, url: str) -> bool:
        return False

    def listar(self, url: str, deve_parar=None) -> dict:
        """{'nome': nome da pasta, 'provedor', 'arquivos': [{'nome', 'tamanho', 'sha256', 'url', 'subpasta',
        'acessivel', 'motivo'}], 'avisos': [...]}. Só arquivos que o serviço lista como públicos são baixáveis."""
        raise ErroTransferencia("Este serviço não lista pastas.", True)


def _subpasta_segura(partes) -> str:
    """Caminho relativo de subpastas, componente por componente com nome_seguro (nada de '..', raiz ou unidade)."""
    limpas = []
    for p in partes:
        n = nome_seguro(p, limite=80, padrao="")
        if n and n not in (".", ".."):
            limpas.append(n)
    return "/".join(limpas)


class ProvedorPixeldrain(Provedor):
    """Pixeldrain: API pública documentada (https://pixeldrain.com/api): /api/file/<id>/info e /api/file/<id>?download.
    Listas (/l/<id>) viram um item por arquivo na revisão."""
    chave, nome, dominios = "pixeldrain", "Pixeldrain", ("pixeldrain.com", "pixeldra.in")
    base_api = "https://pixeldrain.com/api"

    def resolver(self, url: str) -> Recurso:
        partes = [p for p in urllib.parse.urlsplit(url).path.split("/") if p]
        if len(partes) >= 2 and partes[0] in ("u", "api") and partes[-1] not in ("info",):
            fid = partes[-1] if partes[0] == "u" else partes[2] if len(partes) > 2 else partes[-1]
        elif len(partes) >= 2 and partes[0] == "l":
            raise ErroTransferencia("Este link é de uma lista do Pixeldrain: ela abre na janela de escolha dos "
                                    "arquivos.", True)
        else:
            raise ErroTransferencia("Link do Pixeldrain não reconhecido (esperado pixeldrain.com/u/<código>).", True)
        try:
            with _abrir("%s/file/%s/info" % (self.base_api, urllib.parse.quote(fid)), timeout=20) as r:
                info = json.loads(r.read(1_000_000).decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise ErroTransferencia("O arquivo não existe mais no Pixeldrain (removido ou expirado).", True)
            raise ErroTransferencia("O Pixeldrain respondeu %d ao pedir as informações do arquivo." % e.code,
                                    e.code in (401, 403))
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise ErroTransferencia("Não consegui falar com o Pixeldrain (%s)." % e)
        if info.get("success") is False:
            raise ErroTransferencia("O Pixeldrain recusou: %s" % (info.get("message") or info.get("value") or "?"), True)
        return Recurso("%s/file/%s?download" % (self.base_api, urllib.parse.quote(fid)),
                       nome=str(info.get("name") or ""), tamanho=int(info.get("size") or 0) or None,
                       sha256=str(info.get("hash_sha256") or "").lower(), origem=self.nome)

    def e_pasta(self, url: str) -> bool:
        partes = [p for p in urllib.parse.urlsplit(url).path.split("/") if p]
        return len(partes) >= 2 and partes[0] == "l"

    def listar(self, url: str, deve_parar=None) -> dict:
        """Lista pública do Pixeldrain: GET /api/list/<id> (API documentada) -> título e arquivos."""
        partes = [p for p in urllib.parse.urlsplit(url).path.split("/") if p]
        lid = partes[1] if len(partes) >= 2 else ""
        if not re.fullmatch(r"[A-Za-z0-9_-]{4,40}", lid):
            raise ErroTransferencia("Link de lista do Pixeldrain não reconhecido (esperado pixeldrain.com/l/<código>).",
                                    True)
        try:
            with _abrir("%s/list/%s" % (self.base_api, lid), timeout=25) as r:
                d = json.loads(r.read(8_000_000).decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise ErroTransferencia("A lista não existe mais no Pixeldrain (removida ou expirada).", True)
            raise ErroTransferencia("O Pixeldrain respondeu %d ao listar a lista." % e.code, e.code in (401, 403))
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise ErroTransferencia("Não consegui falar com o Pixeldrain (%s)." % e)
        if d.get("success") is False:
            raise ErroTransferencia("O Pixeldrain recusou: %s" % (d.get("message") or d.get("value") or "?"), True)
        arqs = []
        for f in d.get("files") or []:
            if not isinstance(f, dict) or not f.get("id"):
                continue
            arqs.append({"nome": nome_visivel(f.get("name") or f["id"]), "tamanho": int(f.get("size") or 0) or None,
                         "sha256": str(f.get("hash_sha256") or "").lower(), "subpasta": "",
                         "url": "https://pixeldrain.com/u/%s" % f["id"], "acessivel": True, "motivo": ""})
        return {"nome": nome_visivel(d.get("title") or "Lista %s" % lid), "provedor": self.nome, "arquivos": arqs,
                "avisos": []}


class ProvedorMediaFire(Provedor):
    """MediaFire: a página pública do arquivo tem o botão 'Download' com o endereço direto (é o que o navegador usa)."""
    chave, nome, dominios = "mediafire", "MediaFire", ("mediafire.com",)

    base_api = "https://www.mediafire.com/api/1.4"

    def resolver(self, url: str) -> Recurso:
        if self.e_pasta(url):
            raise ErroTransferencia("Este link é de uma pasta do MediaFire: ela abre na janela de escolha dos "
                                    "arquivos.", True)
        try:
            with _abrir(url, {"Accept": "text/html"}, timeout=25) as r:
                pagina = r.read(4_000_000).decode("utf-8", "replace")
                final = r.geturl()
        except urllib.error.HTTPError as e:
            raise ErroTransferencia("O MediaFire respondeu %d (arquivo removido ou privado?)." % e.code, e.code in (404, 410))
        except (urllib.error.URLError, OSError) as e:
            raise ErroTransferencia("Não consegui abrir a página do MediaFire (%s)." % e)
        alvo = self._endereco_do_botao(pagina)
        if not alvo:
            if re.search(r"(?i)captcha|recaptcha", pagina):
                raise ErroTransferencia("O MediaFire pediu um CAPTCHA para este arquivo. Abra o link no navegador; o "
                                        "app não contorna CAPTCHA.", True)
            raise ErroTransferencia("Não achei o botão de download na página do MediaFire (arquivo removido, privado "
                                    "ou a página mudou).", True)
        nome = ""
        mn = re.search(r'<div class="filename"[^>]*>([^<]+)<', pagina) or re.search(r'class="dl-btn-label"[^>]*title="([^"]+)"',
                                                                                     pagina)
        if mn:
            nome = html.unescape(mn.group(1)).strip()
        return Recurso(urllib.parse.urljoin(final, alvo), nome=nome_visivel(nome), cabecalhos={"Referer": final},
                       origem=self.nome)

    @staticmethod
    def _endereco_do_botao(pagina: str) -> str:
        """O endereço do botão Download. Desde 2024 a página traz href="javascript:void(0)" e o endereço real em
        data-scrambled-url (base64), que o navegador decodifica: o app faz o mesmo (Beta 3.7.1; antes o download ficava
        parado em 0 KB). Também aceita o href direto das páginas antigas."""
        for tag in re.findall(r"<a\b[^>]*\bid=[\"']downloadButton[\"'][^>]*>", pagina, re.I):
            m = re.search(r"data-scrambled-url=[\"']([A-Za-z0-9+/=_-]+)[\"']", tag)
            if m:
                try:
                    url = base64.b64decode(m.group(1) + "=" * (-len(m.group(1)) % 4)).decode("utf-8", "replace")
                except (binascii.Error, ValueError):
                    url = ""
                if re.match(r"^https?://", url):
                    return url
            m = re.search(r"\bhref=[\"']([^\"']+)[\"']", tag)
            if m and re.match(r"^(https?:)?//", html.unescape(m.group(1))):
                return html.unescape(m.group(1))
        m = re.search(r'href="(https?://download[0-9]*\.mediafire\.com/[^"]+)"', pagina)
        return html.unescape(m.group(1)) if m else ""

    @staticmethod
    def _chave_pasta(url: str) -> str:
        p = urllib.parse.urlsplit(url)
        m = re.search(r"/folder/([A-Za-z0-9]{6,32})", p.path)
        if m:
            return m.group(1)
        if (p.hostname or "").lower() == "app.mediafire.com":
            seg = p.path.strip("/").split("/")[0]
            if re.fullmatch(r"[A-Za-z0-9]{10,20}", seg or ""):
                return seg
        return ""

    def e_pasta(self, url: str) -> bool:
        return bool(self._chave_pasta(url))

    def _api(self, acao: str, chave: str, conteudo: str, bloco: int = 1) -> dict:
        url = ("%s/folder/%s.php?r=utga&content_type=%s&filter=all&order_by=name&order_direction=asc&chunk=%d"
               "&version=1.5&folder_key=%s&response_format=json" % (self.base_api, acao, conteudo, bloco,
                                                                     urllib.parse.quote(chave)))
        try:
            with _abrir(url, {"Accept": "application/json"}, timeout=25) as r:
                d = json.loads(r.read(8_000_000).decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            try:
                d = json.loads(e.read(200_000).decode("utf-8", "replace"))
            except Exception:
                raise ErroTransferencia("O MediaFire respondeu %d ao listar a pasta." % e.code, e.code in (403, 404))
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise ErroTransferencia("Não consegui falar com o MediaFire (%s)." % e)
        resp = d.get("response") if isinstance(d, dict) else None
        if not isinstance(resp, dict):
            raise ErroTransferencia("O MediaFire mandou uma resposta inesperada ao listar a pasta.")
        if str(resp.get("result")).lower() != "success":
            msg = resp.get("message") or "erro"
            if str(resp.get("error")) in ("112", "110"):
                raise ErroTransferencia("A pasta do MediaFire não existe ou não é pública (%s)." % msg, True)
            raise ErroTransferencia("O MediaFire recusou a listagem: %s" % msg, True)
        return resp

    def listar(self, url: str, deve_parar=None, limite: int = 2000, profundidade: int = 6) -> dict:
        """Pasta pública do MediaFire pela API pública (folder/get_info e folder/get_content), com as subpastas
        (até `profundidade` níveis e `limite` arquivos). O 'hash' que o MediaFire informa é o SHA-256 do arquivo:
        ele é conferido no fim de cada download."""
        chave = self._chave_pasta(url)
        if not chave:
            raise ErroTransferencia("Link de pasta do MediaFire não reconhecido.", True)
        info = self._api("get_info", chave, "folder").get("folder_info") or {}
        nome = nome_visivel(info.get("name") or chave)
        arqs, avisos = [], []

        def percorrer(k: str, caminho: list, nivel: int) -> None:
            if deve_parar and deve_parar():
                raise Parado("cancelar")
            n_bloco, mais = 1, True
            while mais and len(arqs) < limite:
                cont = self._api("get_content", k, "files", n_bloco).get("folder_content") or {}
                for f in cont.get("files") or []:
                    if not isinstance(f, dict):
                        continue
                    links = f.get("links") if isinstance(f.get("links"), dict) else {}
                    link = links.get("normal_download") or ("https://www.mediafire.com/file/%s" % f["quickkey"]
                                                            if f.get("quickkey") else "")
                    privado = str(f.get("privacy") or "public").lower() != "public"
                    senha = str(f.get("password_protected") or "no").lower() == "yes"
                    motivo = "protegido por senha" if senha else ("privado" if privado else ("" if link else
                                                                                           "sem link de download"))
                    try:
                        tam = int(f.get("size") or 0) or None
                    except (TypeError, ValueError):
                        tam = None
                    h = str(f.get("hash") or "").lower()
                    arqs.append({"nome": nome_visivel(f.get("filename") or f.get("quickkey") or "arquivo"),
                                 "tamanho": tam, "sha256": h if re.fullmatch(r"[0-9a-f]{64}", h) else "",
                                 "url": link, "subpasta": _subpasta_segura(caminho), "acessivel": not motivo,
                                 "motivo": motivo})
                mais = str(cont.get("more_chunks") or "no").lower() == "yes"
                n_bloco += 1
            if len(arqs) >= limite:
                avisos.append("A pasta tem mais de %d arquivos: só os primeiros %d aparecem." % (limite, limite))
                return
            if nivel >= profundidade:
                avisos.append("Subpastas com mais de %d níveis não foram abertas." % profundidade)
                return
            subpastas, n_bloco, mais = [], 1, True
            while mais and n_bloco <= 50:
                subs = self._api("get_content", k, "folders", n_bloco).get("folder_content") or {}
                subpastas += [s for s in subs.get("folders") or [] if isinstance(s, dict) and s.get("folderkey")]
                mais = str(subs.get("more_chunks") or "no").lower() == "yes"
                n_bloco += 1
            for sub in subpastas:
                if len(arqs) >= limite:
                    break
                percorrer(sub["folderkey"], caminho + [nome_visivel(sub.get("name") or sub["folderkey"])], nivel + 1)
        percorrer(chave, [], 0)
        return {"nome": nome, "provedor": self.nome, "arquivos": arqs, "avisos": list(dict.fromkeys(avisos))}


class ProvedorDropbox(Provedor):
    """Dropbox: links compartilhados baixam direto com dl=1 (documentado pelo Dropbox)."""
    chave, nome, dominios = "dropbox", "Dropbox", ("dropbox.com",)

    def resolver(self, url: str) -> Recurso:
        p = urllib.parse.urlsplit(url)
        q = [(k, v) for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True) if k != "dl"] + [("dl", "1")]
        return Recurso(urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, urllib.parse.urlencode(q), "")),
                       origem=self.nome)


def _b64url(s: str) -> bytes:
    s = s.replace("-", "+").replace("_", "/").replace(",", "")
    return base64.b64decode(s + "=" * (-len(s) % 4))


def _aes():
    """Funções AES por um pacote de verdade (nada de AES escrito em Python): pycryptodomex (vem com o yt-dlp[default] do
    app) ou cryptography. Devolve {'ctr': f(chave, nonce8, bloco_inicial) -> decifrador, 'cbc_enc': f(chave, iv, dados),
    'cbc_dec': f(chave, iv, dados)} ou None se nenhum dos dois existir."""
    try:
        from Cryptodome.Cipher import AES
        from Cryptodome.Util import Counter

        def ctr(k, nonce, ini):
            c = AES.new(k, AES.MODE_CTR, counter=Counter.new(64, prefix=nonce, initial_value=ini))
            return c.decrypt

        return {"ctr": ctr, "cbc_enc": lambda k, iv, d: AES.new(k, AES.MODE_CBC, iv=iv).encrypt(d),
                "cbc_dec": lambda k, iv, d: AES.new(k, AES.MODE_CBC, iv=iv).decrypt(d)}
    except ImportError:
        pass
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        def ctr(k, nonce, ini):
            return Cipher(algorithms.AES(k), modes.CTR(nonce + ini.to_bytes(8, "big"))).decryptor().update

        def cbc(k, iv, d, cifrar):
            o = Cipher(algorithms.AES(k), modes.CBC(iv))
            o = o.encryptor() if cifrar else o.decryptor()
            return o.update(d) + o.finalize()
        return {"ctr": ctr, "cbc_enc": lambda k, iv, d: cbc(k, iv, d, True),
                "cbc_dec": lambda k, iv, d: cbc(k, iv, d, False)}
    except ImportError:
        return None


class _DecifradorMega:
    """AES-128-CTR do MEGA a partir de qualquer posição (a retomada continua no meio do arquivo) e a conferência do
    MAC do arquivo no fim: CBC-MAC de cada pedaço (128 KiB, 256 KiB... até 1 MiB) e CBC-MAC desses MACs, condensado em
    8 bytes, comparado com os 8 bytes que vêm na chave do link."""

    def __init__(self, chave: bytes, nonce: bytes, meta_mac: bytes):
        self.k, self.nonce, self.meta_mac = chave, nonce, meta_mac
        self.aes = _aes()

    def __call__(self, bloco: bytes, pos: int) -> bytes:
        ini, desloc = divmod(pos, 16)
        dec = self.aes["ctr"](self.k, self.nonce, ini)
        if desloc:
            dec(b"\0" * desloc)
        return dec(bloco)

    @staticmethod
    def pedacos(tamanho: int):
        pos, n = 0, 1
        while pos < tamanho:
            t = min(0x20000 * min(n, 8), tamanho - pos)
            yield pos, t
            pos += t
            n += 1

    def mac(self, caminho: Path) -> bytes:
        cbc = self.aes["cbc_enc"]
        iv = self.nonce + self.nonce
        macs = []
        tam = Path(caminho).stat().st_size
        with open(caminho, "rb") as f:
            for _pos, t in self.pedacos(tam):
                dados = f.read(t)
                if len(dados) % 16:
                    dados += b"\0" * (16 - len(dados) % 16)
                macs.append(cbc(self.k, iv, dados)[-16:])
        m = cbc(self.k, b"\0" * 16, b"".join(macs))[-16:] if macs else b"\0" * 16
        w = struct.unpack(">4I", m)
        return struct.pack(">II", w[0] ^ w[1], w[2] ^ w[3])

    def conferir(self, caminho: Path) -> None:
        if self.mac(caminho) != self.meta_mac:
            raise ErroTransferencia("O arquivo do MEGA não passou na conferência de integridade (MAC). Ele não foi "
                                    "marcado como concluído; tente baixar de novo.")


class ProvedorMega(Provedor):
    """MEGA (mega.nz/file/<código>#<chave>): API pública do MEGA ('g' = endereço de download) e a decifração AES-CTR
    com a chave que vem no próprio link, como o site faz no navegador. Confere o MAC no fim. Pastas: um arquivo por vez.
    Respeita a cota de transferência do MEGA (o app avisa quando ela acaba)."""
    chave, nome, dominios = "mega", "MEGA", ("mega.nz", "mega.co.nz", "mega.io")
    api = "https://g.api.mega.co.nz/cs"

    def resolver(self, url: str) -> Recurso:
        m = re.search(r"/file/([A-Za-z0-9_-]{8})#([A-Za-z0-9_,-]{43})", url) or \
            re.search(r"#!([A-Za-z0-9_-]{8})!([A-Za-z0-9_,-]{43})", url)
        if not m:
            if "/folder/" in url or "#F!" in url:
                raise ErroTransferencia("Pastas do MEGA ainda não são baixadas pelo app: abra a pasta e copie o link de "
                                        "cada arquivo (mega.nz/file/...#chave).", True)
            raise ErroTransferencia("Link do MEGA sem a chave (a parte depois do #). Copie o link completo.", True)
        if _aes() is None:
            raise ErroTransferencia("O MEGA precisa do pacote pycryptodomex (vem com o yt-dlp completo). Atualize o "
                                    "yt-dlp em Configurações ou reinstale o app.", True)
        handle, chave_b = m.group(1), _b64url(m.group(2))
        if len(chave_b) != 32:
            raise ErroTransferencia("A chave do link do MEGA é inválida.", True)
        a = struct.unpack(">8I", chave_b)
        k = struct.pack(">4I", a[0] ^ a[4], a[1] ^ a[5], a[2] ^ a[6], a[3] ^ a[7])
        nonce, meta_mac = struct.pack(">2I", a[4], a[5]), struct.pack(">2I", a[6], a[7])
        corpo = json.dumps([{"a": "g", "g": 1, "p": handle}]).encode()
        try:
            with _abrir("%s?id=%d" % (self.api, random.randint(0, 2 ** 31)), {"Content-Type": "application/json"},
                        timeout=25, metodo="POST", dados=corpo) as r:
                resp = json.loads(r.read(1_000_000).decode("utf-8", "replace"))
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise ErroTransferencia("Não consegui falar com o MEGA (%s)." % e)
        if isinstance(resp, int):
            resp = [resp]
        res = resp[0] if isinstance(resp, list) and resp else resp
        if isinstance(res, int):
            raise ErroTransferencia(self._erro(res), res in (-2, -9, -11, -16))
        if not isinstance(res, dict) or not res.get("g"):
            if isinstance(res, dict) and res.get("e"):
                raise ErroTransferencia(self._erro(int(res["e"])), True)
            raise ErroTransferencia("O MEGA não devolveu o endereço do arquivo (removido ou indisponível).", True)
        nome = ""
        try:
            attr = _aes()["cbc_dec"](k, b"\0" * 16, _b64url(res.get("at", "")))
            if attr.startswith(b"MEGA"):
                nome = json.loads(attr[4:].rstrip(b"\0").decode("utf-8")).get("n", "")
        except Exception:
            nome = ""
        if not nome:
            raise ErroTransferencia("A chave do link não abre este arquivo do MEGA (link errado ou incompleto).", True)
        dec = _DecifradorMega(k, nonce, meta_mac)
        return Recurso(res["g"], nome=nome, tamanho=int(res.get("s") or 0) or None, decifrar=dec,
                       conferir=dec.conferir, origem=self.nome)

    @staticmethod
    def _erro(cod: int) -> str:
        return {-2: "O MEGA recusou o pedido (link inválido).", -9: "O arquivo não existe mais no MEGA.",
                -11: "Acesso negado pelo MEGA.", -16: "O arquivo foi bloqueado pelo MEGA (denúncia/termos).",
                -17: "A cota de transferência do MEGA acabou. Espere algumas horas e tente de novo.",
                -18: "O MEGA está temporariamente indisponível. Tente de novo daqui a pouco.",
                -3: "O MEGA pediu para tentar de novo mais tarde."}.get(cod, "O MEGA respondeu o erro %d." % cod)


class ProvedorNavegador(Provedor):
    """Serviços cujo download só sai depois de CAPTCHA, contagem regressiva, anúncio ou conta (DropGalaxy e afins):
    o app não contorna nada disso e diz como fazer."""
    chave, nome = "navegador", "Exige navegador"
    dominios = ("dropgalaxy.com", "dropgalaxy.co", "dgdrive.xyz", "1fichier.com", "rapidgator.net", "uploaded.net",
                "nitroflare.com", "turbobit.net", "katfile.com", "ddownload.com", "uptobox.com", "filefactory.com")
    precisa_navegador = True

    def resolver(self, url: str) -> Recurso:
        host = urllib.parse.urlsplit(url).hostname or url
        raise ErroTransferencia("%s só libera o download depois de CAPTCHA, contagem regressiva ou login no navegador. "
                                "O app não contorna essas etapas: abra o link no navegador e, quando o download começar, "
                                "copie o endereço DIRETO do arquivo e cole aqui." % host, True)


PROVEDORES = [ProvedorPixeldrain(), ProvedorMediaFire(), ProvedorDropbox(), ProvedorMega(), ProvedorNavegador()]
_GENERICO = Provedor()


def provedor_para(url: str) -> Provedor:
    for p in PROVEDORES:
        if p.reconhece(url):
            return p
    return _GENERICO


def nome_provedor(chave: str) -> str:
    for p in PROVEDORES + [_GENERICO]:
        if p.chave == chave:
            return p.nome
    return {"torrent": "Torrent", "magnet": "Magnet"}.get(chave, chave or "Link")


# ======================================================================================================================
# Controle de uma transferência (pausar/cancelar/limite de velocidade), comum a HTTP e torrent
# ======================================================================================================================
class Controle:
    def __init__(self, limite_bps=None):
        self.pedido = None                  # None | 'pausar' | 'cancelar'
        self.evento = threading.Event()
        self.limite_bps = limite_bps or (lambda: 0)
        self._janela = collections.deque()

    def parar(self, motivo: str) -> None:
        self.pedido = motivo
        self.evento.set()
        resp, self.aberta = getattr(self, "aberta", None), None
        if resp is not None:                         # destrava uma leitura parada esperando o servidor
            try:
                resp.close()
            except Exception:
                pass

    def conferir(self) -> None:
        if self.pedido:
            raise Parado(self.pedido)

    def dormir(self, seg: float) -> None:
        if self.evento.wait(seg):
            self.conferir()

    def limitar(self, n: int) -> None:
        """Limite de velocidade (bytes/s; 0 = sem limite): segura o ritmo para a média do último segundo caber."""
        lim = self.limite_bps() or 0
        if lim <= 0:
            return
        agora = time.monotonic()
        self._janela.append((agora, n))
        while self._janela and agora - self._janela[0][0] > 1.0:
            self._janela.popleft()
        total = sum(b for _, b in self._janela)
        if total > lim:
            self.dormir(min(1.0, (total - lim) / lim))


class Medidor:
    """Velocidade (média móvel de ~3 s) e tempo restante."""

    def __init__(self):
        self.amostras = collections.deque()

    def somar(self, feito: int) -> None:
        agora = time.monotonic()
        self.amostras.append((agora, feito))
        while len(self.amostras) > 2 and agora - self.amostras[0][0] > 3.0:
            self.amostras.popleft()

    def velocidade(self) -> float:
        if len(self.amostras) < 2:
            return 0.0
        (t0, b0), (t1, b1) = self.amostras[0], self.amostras[-1]
        return max(0.0, (b1 - b0) / (t1 - t0)) if t1 > t0 else 0.0

    def eta(self, feito: int, total) -> "float | None":
        v = self.velocidade()
        if not total or v <= 0:
            return None
        return max(0.0, (total - feito) / v)


# ======================================================================================================================
# Motor HTTP/HTTPS
# ======================================================================================================================
def _erro_http(e: urllib.error.HTTPError) -> ErroTransferencia:
    c = e.code
    if c in (404, 410):
        return ErroTransferencia("O arquivo não existe mais nesse endereço (%d): link expirado ou removido." % c, True)
    if c in (401, 403):
        return ErroTransferencia("Acesso negado pelo servidor (%d): o link exige login, expirou ou é privado." % c, True)
    if c == 416:
        return ErroTransferencia("O servidor recusou continuar de onde parou (416).", False)
    if c == 429:
        return ErroTransferencia("O servidor pediu para esperar (429: muitos pedidos).", False)
    if c >= 500:
        return ErroTransferencia("O servidor está com problemas (%d). Vou tentar de novo." % c, False)
    return ErroTransferencia("O servidor respondeu %d." % c, c < 500 and c not in (408, 425))


def _erro_disco(e: OSError) -> ErroTransferencia:
    import errno
    if e.errno in (errno.ENOSPC, getattr(errno, "EDQUOT", -1)):
        return ErroTransferencia("Sem espaço no disco para continuar o download. Libere espaço e retome: o que já foi "
                                 "baixado fica guardado.", True)
    if e.errno in (errno.EACCES, errno.EPERM, errno.EROFS):
        return ErroTransferencia("Sem permissão para gravar na pasta de destino (%s). Escolha outra pasta." %
                                 (e.filename or ""), True)
    return ErroTransferencia("Erro ao gravar o arquivo: %s" % (e.strerror or e), True)


def baixar_http(item: dict, ctl: Controle, ao_progresso, tentativas: int = TENTATIVAS_PADRAO, log=None) -> Path:
    """Baixa um item HTTP. `item` (dict persistido na fila) guarda o estado da retomada: 'parcial', 'final', 'etag',
    'modificado', 'url_direta', 'tamanho'. Devolve o caminho final (já conferido). Levanta Parado/ErroTransferencia."""
    log = log or (lambda *a: None)
    prov = provedor_para(item["entrada"])
    recurso = None
    erros = 0
    while True:
        ctl.conferir()
        try:
            if recurso is None:
                recurso = prov.resolver(item["entrada"]) if prov is not _GENERICO else Recurso(item["entrada"])
                if recurso.nome and not item.get("nome_servidor"):
                    item["nome_servidor"] = recurso.nome
                if recurso.tamanho and not item.get("tamanho"):
                    item["tamanho"] = recurso.tamanho
            return _baixar_recurso(item, recurso, ctl, ao_progresso, log)
        except Parado:
            raise
        except ErroTransferencia as e:
            if e.definitivo:
                raise
            erros += 1
            if erros > tentativas:
                raise ErroTransferencia("%s Parei depois de %d tentativas." % (e, tentativas), True)
            espera = min(60, 2 ** erros)
            log("warn", "%s Tentando de novo em %d s (%d/%d)." % (e, espera, erros, tentativas))
            item["msg"] = "%s Nova tentativa em %d s." % (e, espera)
            ao_progresso(None)
            ctl.dormir(espera)
            if "expir" in str(e).lower():
                recurso = None


def _baixar_recurso(item: dict, rec: Recurso, ctl: Controle, ao_progresso, log) -> Path:
    pasta = Path(item["pasta"])
    try:
        pasta.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise _erro_disco(e)
    parcial = Path(item["parcial"]) if item.get("parcial") else None
    inicio = parcial.stat().st_size if (parcial and parcial.exists()) else 0
    cab = dict(rec.cabecalhos)
    if inicio:
        cab["Range"] = "bytes=%d-" % inicio
        if item.get("etag"):
            cab["If-Range"] = item["etag"]
        elif item.get("modificado"):
            cab["If-Range"] = item["modificado"]
    try:
        resp = _abrir(rec.url, cab, timeout=30)
    except urllib.error.HTTPError as e:
        if e.code == 416 and parcial and inicio and item.get("tamanho") and inicio >= int(item["tamanho"]):
            return _concluir_http(item, rec, parcial)
        raise _erro_http(e)
    except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError) as e:
        motivo = getattr(e, "reason", e)
        raise ErroTransferencia("Falha de rede (%s)." % motivo)
    ctl.aberta = resp
    with resp:
        url_final = resp.geturl()
        tipo = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if tipo in ("text/html", "application/xhtml+xml") and not inicio:
            if item.get("_html_seguido"):
                raise ErroTransferencia("O link leva a uma página da web, não a um arquivo.", True)
            pagina = resp.read(3_000_000).decode("utf-8", "replace")
            alvo = link_de_download_na_pagina(pagina, url_final)
            if not alvo:
                raise ErroTransferencia("O link leva a uma página da web, não a um arquivo, e não achei nela um link de "
                                        "download único. Abra a página no navegador e copie o link direto do arquivo.",
                                        True)
            log("info", "Página da web: seguindo o link de download que ela traz (%s)." % alvo[:90])
            item["_html_seguido"] = True
            rec.url = alvo
            return _baixar_recurso(item, rec, ctl, ao_progresso, log)
        status = getattr(resp, "status", 200)
        retomando = bool(inicio) and status == 206
        if inicio and not retomando:
            log("warn", "O servidor não continua de onde parou (ou o arquivo mudou): recomeçando do zero.")
            inicio = 0
        total = None
        if retomando:
            m = re.search(r"/(\d+)\s*$", resp.headers.get("Content-Range", ""))
            total = int(m.group(1)) if m else None
        else:
            cl = resp.headers.get("Content-Length")
            total = int(cl) if cl and cl.isdigit() else None
        total = total or rec.tamanho or None
        if rec.tamanho and total and rec.tamanho != total and not rec.decifrar:
            log("warn", "O tamanho informado pelo serviço (%d) difere do servidor (%d)." % (rec.tamanho, total))
        if not item.get("final"):
            # arquivo de uma pasta (Beta 3.7.1): o nome é o que a listagem da pasta mostrou
            nome = nome_seguro(item.get("nome_lista") or rec.nome or item.get("nome_servidor") or
                               nome_da_resposta(resp, url_final))
            final = nome_livre(pasta, nome)
            item["final"] = str(final)
            item["nome"] = final.name
            parcial = Path(str(final) + SUFIXO_PARCIAL)
            item["parcial"] = str(parcial)
        if parcial is None:
            parcial = Path(item["final"] + SUFIXO_PARCIAL)
            item["parcial"] = str(parcial)
        item["etag"] = resp.headers.get("ETag", "") if not resp.headers.get("ETag", "").startswith("W/") else ""
        item["modificado"] = resp.headers.get("Last-Modified", "")
        item["url_final"] = url_final
        item["tamanho"] = total
        item["retomavel"] = (resp.headers.get("Accept-Ranges", "").lower() == "bytes") or retomando
        feito = inicio
        med = Medidor()
        med.somar(feito)
        ultimo = 0.0
        try:
            with open(parcial, "r+b" if (retomando and parcial.exists()) else "wb") as f:
                f.seek(inicio)
                f.truncate()
                while True:
                    ctl.conferir()
                    try:
                        bloco = resp.read1(BLOCO_HTTP)        # o que chegou (até 256 KiB): pausar/cancelar respondem logo
                    except Exception as e:
                        f.flush()
                        ctl.conferir()                        # a pessoa pausou/cancelou e a conexão foi fechada
                        raise ErroTransferencia("A conexão caiu no meio do download (%s)." % e)
                    if not bloco:
                        break
                    if rec.decifrar is not None:
                        bloco = rec.decifrar(bloco, feito)
                    f.write(bloco)
                    feito += len(bloco)
                    if total and feito > total:
                        raise ErroTransferencia("O servidor mandou mais dados que o tamanho anunciado.", True)
                    med.somar(feito)
                    ctl.limitar(len(bloco))
                    agora = time.monotonic()
                    if agora - ultimo > 0.25:
                        ultimo = agora
                        item.update(feito=feito, velocidade=med.velocidade(), eta=med.eta(feito, total))
                        ao_progresso(item)
        except OSError as e:
            if isinstance(e, (ConnectionError, socket.timeout)):
                raise ErroTransferencia("A conexão caiu (%s)." % e)
            raise _erro_disco(e)
        item.update(feito=feito, velocidade=0.0, eta=None)
        ao_progresso(item)
        if total and feito < total:
            raise ErroTransferencia("O download parou antes do fim (%d de %d bytes)." % (feito, total))
    return _concluir_http(item, rec, parcial)


def _concluir_http(item: dict, rec: Recurso, parcial: Path) -> Path:
    """Só marca como concluído depois de conferir tamanho e (quando há) hash/MAC. O nome final nunca sobrescreve nada."""
    tam = parcial.stat().st_size
    if item.get("tamanho") and tam != int(item["tamanho"]):
        raise ErroTransferencia("O arquivo baixado tem %d bytes, mas o servidor anunciou %d." % (tam, item["tamanho"]))
    if tam == 0:
        raise ErroTransferencia("O servidor mandou um arquivo vazio.", True)
    esperado_sha = (item.get("sha256") or rec.sha256 or "").lower()
    if esperado_sha or rec.md5:
        h = hashlib.sha256() if esperado_sha else hashlib.md5()
        with open(parcial, "rb") as f:
            for b in iter(lambda: f.read(1 << 20), b""):
                h.update(b)
        if h.hexdigest() != (esperado_sha or rec.md5.lower()):
            parcial.unlink(missing_ok=True)
            item["parcial"] = ""
            raise ErroTransferencia("O arquivo baixado não confere com o hash informado (%s). Ele foi apagado; tente de "
                                    "novo." % ("SHA-256" if esperado_sha else "MD5"), True)
        item["conferido"] = "SHA-256" if esperado_sha else "MD5"
    if rec.conferir is not None:
        rec.conferir(parcial)
        item["conferido"] = item.get("conferido") or "MAC do serviço"
    final = Path(item["final"])
    if final.exists():
        final = nome_livre(final.parent, final.name)
    os.replace(parcial, final)
    item["final"], item["nome"], item["parcial"] = str(final), final.name, ""
    return final


def _hash_do_fragmento(url: str) -> str:
    """'https://x/arq.iso#sha256=<hex>' -> o hash esperado (a pessoa pode colar o link com o hash publicado)."""
    m = re.search(r"#(?:.*&)?sha256=([0-9a-fA-F]{64})", url)
    return m.group(1).lower() if m else ""


# ======================================================================================================================
# BitTorrent: armazenamento (as peças atravessam os arquivos do torrent)
# ======================================================================================================================
class Armazenamento:
    """Lê e grava peças nos arquivos do torrent, na estrutura original. `raiz`: a pasta onde fica o conteúdo (torrent de
    vários arquivos: os arquivos ficam em raiz/<caminho do torrent>; de um arquivo só: raiz/<nome>).
    Beta 3.8: `pular` = índices dos arquivos que a pessoa NÃO escolheu. Eles nunca são criados; quando uma peça
    necessária também tem um pedaço deles (peças atravessam arquivos), a peça inteira fica guardada em
    raiz/.ypele-partes/p<N>.bin (para conferir o SHA-1 e para quem pede essa peça) e a pasta sai no fim."""

    def __init__(self, meta: MetaTorrent, raiz: Path, pular=()):
        self.meta, self.raiz = meta, Path(raiz)
        self.pular = set(pular or ())
        self.partes = []                      # (caminho ou None para preenchimento, início global, tamanho)
        self._puladas = []                    # (início global, tamanho) dos arquivos não escolhidos
        pos = 0
        for k, (partes, tam) in enumerate(meta.arquivos):
            cam = None if partes is None else self.raiz.joinpath(*partes)
            if cam is not None and not cam.resolve().is_relative_to(self.raiz.resolve()):
                raise ErroTransferencia("O torrent tem um caminho que sairia da pasta de destino: recusado.", True)
            if cam is not None and k in self.pular:
                self._puladas.append((pos, tam))
                cam = None
            self.partes.append((cam, pos, tam))
            pos += tam
        self._abertos: dict = {}
        self._trava = threading.Lock()

    @property
    def pasta_partes(self) -> Path:
        return self.raiz / PASTA_PARTES

    def _toca_pulada(self, inicio: int, n: int) -> bool:
        return any(a < inicio + n and inicio < a + t for a, t in self._puladas)

    def _arquivo(self, cam: Path, gravar: bool):
        f = self._abertos.get(cam)
        if f is not None and (not gravar or f.mode != "rb"):
            return f
        if f is not None:
            f.close()
        if gravar:
            cam.parent.mkdir(parents=True, exist_ok=True)
            f = open(cam, "r+b" if cam.exists() else "w+b")
        else:
            f = open(cam, "rb")
        self._abertos[cam] = f
        return f

    def _trechos(self, inicio: int, n: int):
        fim = inicio + n
        for cam, ini, tam in self.partes:
            a, b = max(inicio, ini), min(fim, ini + tam)
            if a < b:
                yield cam, a - ini, a - inicio, b - a

    def gravar(self, inicio: int, dados: bytes) -> None:
        with self._trava:
            if self._puladas and self._toca_pulada(inicio, len(dados)):
                i = inicio // self.meta.tam_peca
                self.pasta_partes.mkdir(parents=True, exist_ok=True)
                with open(self.pasta_partes / ("p%d.bin" % i), "r+b" if (self.pasta_partes / ("p%d.bin" % i)).exists()
                          else "w+b") as f:
                    f.seek(inicio - i * self.meta.tam_peca)
                    f.write(dados)
            for cam, desloc, rel, n in self._trechos(inicio, len(dados)):
                if cam is None:
                    continue
                f = self._arquivo(cam, True)
                f.seek(desloc)
                f.write(dados[rel:rel + n])

    def ler(self, inicio: int, n: int) -> bytes:
        buf = bytearray(n)
        with self._trava:
            for cam, desloc, rel, m in self._trechos(inicio, n):
                if cam is None:
                    continue
                if not cam.exists():
                    continue
                f = self._arquivo(cam, False) if cam not in self._abertos else self._abertos[cam]
                f.seek(desloc)
                pedaco = f.read(m)
                buf[rel:rel + len(pedaco)] = pedaco
            if self._puladas and self._toca_pulada(inicio, n):
                i = inicio // self.meta.tam_peca
                lado = self.pasta_partes / ("p%d.bin" % i)
                if lado.is_file():
                    with open(lado, "rb") as f:
                        f.seek(inicio - i * self.meta.tam_peca)
                        pedaco = f.read(n)
                    for a, t in self._puladas:                     # só os trechos dos arquivos não escolhidos
                        x, y = max(inicio, a), min(inicio + n, a + t)
                        if x < y:
                            buf[x - inicio:y - inicio] = pedaco[x - inicio:y - inicio].ljust(y - x, b"\0")
        return bytes(buf)

    def ler_peca(self, i: int) -> bytes:
        return self.ler(i * self.meta.tam_peca, self.meta.tamanho_peca(i))

    def peca_confere(self, i: int) -> bool:
        return hashlib.sha1(self.ler_peca(i)).digest() == self.meta.hashes[i]

    def existe_algo(self) -> bool:
        return any(c is not None and c.exists() for c, _, _ in self.partes) or self.pasta_partes.is_dir()

    def assinatura(self) -> list:
        """Tamanho e data de cada arquivo: se não mudaram desde a última vez, as peças conferidas continuam valendo."""
        out = []
        for cam, _, _ in self.partes:
            if cam is None:
                continue
            try:
                st = cam.stat()
                out.append([str(cam), st.st_size, int(st.st_mtime)])
            except OSError:
                out.append([str(cam), -1, 0])
        return out

    def ajustar_tamanhos(self) -> None:
        """No fim, cada arquivo (escolhido) fica exatamente do tamanho do torrent."""
        with self._trava:
            for f in self._abertos.values():
                f.close()
            self._abertos.clear()
            for cam, _, tam in self.partes:
                if cam is not None:
                    cam.parent.mkdir(parents=True, exist_ok=True)
                    with open(cam, "r+b" if cam.exists() else "w+b") as f:
                        f.truncate(tam)

    def apagar_partes(self) -> None:
        """Tira a pasta dos pedaços de arquivos não escolhidos (só os p<N>.bin que o app gravou; nada mais)."""
        d = self.pasta_partes
        if not d.is_dir() or d.is_symlink():
            return
        for f in d.iterdir():
            if re.fullmatch(r"p\d+\.bin", f.name) and f.is_file():
                try:
                    f.unlink()
                except OSError:
                    pass
        try:
            d.rmdir()
        except OSError:
            pass

    def fechar(self) -> None:
        with self._trava:
            for f in self._abertos.values():
                try:
                    f.close()
                except OSError:
                    pass
            self._abertos.clear()


def bits_para_bytes(tem, n: int) -> bytes:
    b = bytearray((n + 7) // 8)
    for i in range(n):
        if tem[i]:
            b[i >> 3] |= 0x80 >> (i & 7)
    return bytes(b)


def bytes_para_bits(b: bytes, n: int) -> list:
    return [bool(b[i >> 3] & (0x80 >> (i & 7))) if (i >> 3) < len(b) else False for i in range(n)]


def _peers_compactos(b: bytes, v6: bool = False) -> list:
    t = 18 if v6 else 6
    out = []
    for i in range(0, len(b) - t + 1, t):
        ipb, porta = b[i:i + t - 2], struct.unpack(">H", b[i + t - 2:i + t])[0]
        if porta:
            out.append((socket.inet_ntop(socket.AF_INET6 if v6 else socket.AF_INET, ipb), porta))
    return out


# ======================================================================================================================
# BitTorrent: rastreadores (HTTP e UDP) e DHT
# ======================================================================================================================
def anunciar_http(url: str, info_hash: bytes, peer_id: bytes, porta: int, baixado: int, enviado: int, falta: int,
                  evento: str = "", timeout: float = 15.0) -> dict:
    q = {"info_hash": info_hash, "peer_id": peer_id, "port": str(porta), "uploaded": str(enviado),
         "downloaded": str(baixado), "left": str(falta), "compact": "1", "numwant": "80"}
    if evento:
        q["event"] = evento
    sep = "&" if "?" in url else "?"
    alvo = url + sep + "&".join("%s=%s" % (k, urllib.parse.quote(v if isinstance(v, bytes) else v.encode(), safe=""))
                                for k, v in q.items())
    try:
        with _abrir(alvo, timeout=timeout) as r:
            d = bdecode(r.read(2_000_000))
    except urllib.error.HTTPError as e:
        raise ErroTransferencia("rastreador respondeu %d" % e.code)
    except (urllib.error.URLError, OSError, ErroBencode, ValueError) as e:
        raise ErroTransferencia("rastreador indisponível (%s)" % getattr(e, "reason", e))
    if not isinstance(d, dict):
        raise ErroTransferencia("resposta inválida do rastreador")
    if b"failure reason" in d:
        raise ErroTransferencia("rastreador recusou: %s" % _txt(d[b"failure reason"])[:120])
    peers = []
    p = d.get(b"peers")
    if isinstance(p, bytes):
        peers += _peers_compactos(p)
    elif isinstance(p, list):
        for x in p:
            if isinstance(x, dict) and x.get(b"ip") and x.get(b"port"):
                peers.append((_txt(x[b"ip"]), int(x[b"port"])))
    if isinstance(d.get(b"peers6"), bytes):
        peers += _peers_compactos(d[b"peers6"], True)
    return {"peers": peers, "intervalo": int(d.get(b"interval") or 1800), "seeds": d.get(b"complete"),
            "leechers": d.get(b"incomplete")}


class _ProtoUDP(asyncio.DatagramProtocol):
    def __init__(self):
        self.fila: asyncio.Queue = asyncio.Queue()

    def datagram_received(self, dados, ender):
        self.fila.put_nowait((dados, ender))

    def error_received(self, exc):
        pass


async def anunciar_udp(url: str, info_hash: bytes, peer_id: bytes, porta: int, baixado: int, enviado: int, falta: int,
                       evento: int = 0) -> dict:
    """BEP 15: connect + announce, com as esperas crescentes do protocolo (encurtadas: 3 tentativas)."""
    p = urllib.parse.urlsplit(url)
    if not p.hostname or not p.port:
        raise ErroTransferencia("rastreador UDP sem porta")
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(p.hostname, p.port, type=socket.SOCK_DGRAM)
    except OSError as e:
        raise ErroTransferencia("rastreador UDP não encontrado (%s)" % e)
    familia, _, _, _, ender = infos[0]
    transp, proto = await loop.create_datagram_endpoint(_ProtoUDP, family=familia)
    try:
        async def pedir(pacote: bytes, trans: int):
            for tentativa in range(3):
                transp.sendto(pacote, ender)
                try:
                    while True:
                        dados, _ = await asyncio.wait_for(proto.fila.get(), timeout=3 * (tentativa + 1))
                        if len(dados) >= 8 and struct.unpack(">I", dados[4:8])[0] == trans:
                            return dados
                except asyncio.TimeoutError:
                    continue
            raise ErroTransferencia("rastreador UDP não respondeu")
        t = random.getrandbits(32)
        r = await pedir(struct.pack(">QII", 0x41727101980, 0, t), t)
        if struct.unpack(">I", r[:4])[0] != 0 or len(r) < 16:
            raise ErroTransferencia("rastreador UDP recusou a conexão")
        cid = r[8:16]
        t = random.getrandbits(32)
        pacote = cid + struct.pack(">II", 1, t) + info_hash + peer_id + struct.pack(
            ">QQQIIIiH", baixado, falta, enviado, evento, 0, random.getrandbits(32), 80, porta)
        r = await pedir(pacote, t)
        acao = struct.unpack(">I", r[:4])[0]
        if acao == 3:
            raise ErroTransferencia("rastreador recusou: %s" % r[8:].decode("utf-8", "replace")[:120])
        if acao != 1 or len(r) < 20:
            raise ErroTransferencia("resposta inválida do rastreador UDP")
        intervalo, leech, seeds = struct.unpack(">III", r[8:20])
        return {"peers": _peers_compactos(r[20:], familia == socket.AF_INET6), "intervalo": intervalo,
                "seeds": seeds, "leechers": leech}
    finally:
        transp.close()


DHT_INICIAIS = [("router.bittorrent.com", 6881), ("dht.transmissionbt.com", 6881), ("router.utorrent.com", 6881),
                ("dht.libtorrent.org", 25401)]


class DHT:
    """Cliente DHT mínimo (BEP 5), só para ACHAR peers: get_peers iterativo a partir dos nós iniciais públicos. Marca
    as consultas como 'somente leitura' (BEP 43), então ninguém conta com este nó para guardar dados."""

    def __init__(self, iniciais=None):
        self.id = os.urandom(20)
        self.iniciais = list(iniciais if iniciais is not None else DHT_INICIAIS)
        self.transp = None
        self.esperando: dict = {}

    async def abrir(self):
        if self.transp is not None:
            return
        loop = asyncio.get_running_loop()
        dht = self

        class P(asyncio.DatagramProtocol):
            def datagram_received(self, dados, ender):
                dht._chegou(dados, ender)

            def error_received(self, exc):
                pass
        self.transp, _ = await loop.create_datagram_endpoint(P, local_addr=("0.0.0.0", 0), family=socket.AF_INET)

    def fechar(self):
        if self.transp is not None:
            self.transp.close()
            self.transp = None

    def _chegou(self, dados, ender):
        try:
            m = bdecode(dados)
        except ErroBencode:
            return
        if not isinstance(m, dict):
            return
        t = m.get(b"t")
        if m.get(b"y") == b"q":                     # responde só 'ping' (o resto: somente leitura)
            if m.get(b"q") == b"ping" and isinstance(t, bytes):
                try:
                    self.transp.sendto(bencode({"t": t, "y": "r", "r": {"id": self.id}}), ender)
                except OSError:
                    pass
            return
        fut = self.esperando.pop(t, None) if isinstance(t, bytes) else None
        if fut is not None and not fut.done():
            fut.set_result(m)

    async def _consultar(self, ender, q: str, args: dict, timeout: float = 2.5):
        t = os.urandom(2)
        fut = asyncio.get_running_loop().create_future()
        self.esperando[t] = fut
        try:
            self.transp.sendto(bencode({"t": t, "y": "q", "q": q, "a": dict(args, id=self.id), "ro": 1}), ender)
            return await asyncio.wait_for(fut, timeout)
        except (asyncio.TimeoutError, OSError):
            return None
        finally:
            self.esperando.pop(t, None)

    async def buscar_peers(self, info_hash: bytes, rodadas: int = 8, cancelado=None) -> list:
        await self.abrir()
        loop = asyncio.get_running_loop()
        candidatos = {}
        for host, porta in self.iniciais:
            try:
                for inf in await loop.getaddrinfo(host, porta, family=socket.AF_INET, type=socket.SOCK_DGRAM):
                    candidatos[inf[4][:2]] = b"\xff" * 20
            except OSError:
                continue
        consultados, peers = set(), set()

        def dist(nid: bytes) -> int:
            return int.from_bytes(bytes(a ^ b for a, b in zip(nid, info_hash)), "big")
        for _ in range(rodadas):
            if cancelado and cancelado():
                break
            fila = sorted((e for e in candidatos if e not in consultados), key=lambda e: dist(candidatos[e]))[:8]
            if not fila:
                break
            consultados.update(fila)
            respostas = await asyncio.gather(*(self._consultar(e, "get_peers", {"info_hash": info_hash}) for e in fila))
            for m in respostas:
                r = m.get(b"r") if isinstance(m, dict) else None
                if not isinstance(r, dict):
                    continue
                for v in r.get(b"values") or []:
                    if isinstance(v, bytes) and len(v) == 6:
                        peers.update(_peers_compactos(v))
                nos = r.get(b"nodes")
                if isinstance(nos, bytes):
                    for i in range(0, len(nos) - 25, 26):
                        nid, ip, porta = nos[i:i + 20], socket.inet_ntoa(nos[i + 20:i + 24]), \
                            struct.unpack(">H", nos[i + 24:i + 26])[0]
                        if porta and (ip, porta) not in candidatos:
                            candidatos[(ip, porta)] = nid
            if len(peers) >= 60:
                break
        return list(peers)


# ======================================================================================================================
# BitTorrent: protocolo dos peers (BEP 3, extensões BEP 10, metadados BEP 9, PEX)
# ======================================================================================================================
BLOCO = 16 * 1024
PEDIDOS_POR_PEER = 24
MAX_PEERS = 40
EXT_METADADOS, EXT_PEX = 1, 2


class PecaEmAndamento:
    def __init__(self, indice: int, tamanho: int):
        self.indice, self.tamanho = indice, tamanho
        self.n_blocos = (tamanho + BLOCO - 1) // BLOCO
        self.recebidos: dict = {}
        self.pedidos: dict = {}               # bloco -> conjunto de peers que receberam o pedido
        self.peers: set = set()

    def blocos_faltando(self):
        return [b for b in range(self.n_blocos) if b not in self.recebidos]

    def completa(self) -> bool:
        return len(self.recebidos) == self.n_blocos

    def dados(self) -> bytes:
        return b"".join(self.recebidos[b] for b in range(self.n_blocos))

    def tam_bloco(self, b: int) -> int:
        return min(BLOCO, self.tamanho - b * BLOCO)


class Peer:
    def __init__(self, tarefa, ender, leitor, escritor, entrada: bool = False):
        self.t, self.ender, self.r, self.w, self.entrada = tarefa, ender, leitor, escritor, entrada
        self.tem = None                       # lista de bool (quando há metadados) ou bytes crus do bitfield
        self.tem_bruto = b""
        self.haves: set = set()
        self.nos_estrangula, self.interessado_nele = True, False
        self.ele_interessado, self.estrangulado_por_nos = False, True
        self.pedidos: set = set()             # (peça, bloco) pedidos a ele
        self.ext: dict = {}
        self.meta_tam = 0
        self.recebido = 0
        self.enviado = 0
        self.ruins = 0
        self.ultimo = time.monotonic()
        self.fechado = False
        self.id_remoto = b""

    def possui(self, i: int) -> bool:
        if isinstance(self.tem, list):
            return 0 <= i < len(self.tem) and self.tem[i]
        return i in self.haves

    def completo(self) -> bool:
        return isinstance(self.tem, list) and bool(self.tem) and all(self.tem)

    async def enviar(self, tipo: int, corpo: bytes = b"") -> None:
        if self.fechado:
            return
        self.w.write(struct.pack(">IB", len(corpo) + 1, tipo) + corpo)
        await self.w.drain()

    async def enviar_ext(self, ext_id: int, dic: dict, extra: bytes = b"") -> None:
        await self.enviar(20, bytes([ext_id]) + bencode(dic) + extra)

    def fechar(self) -> None:
        if not self.fechado:
            self.fechado = True
            try:
                self.w.close()
            except Exception:
                pass


class TarefaTorrent:
    """Um torrent sendo baixado (no laço asyncio do motor). Estado e progresso vão para `item` (o dict da fila) e para
    `ao_progresso(item)`. Termina quando todas as peças conferem (ou quando é pausado/cancelado)."""

    def __init__(self, motor, item: dict, ao_progresso, log, limite_bps):
        self.motor, self.item, self.ao_progresso, self.log, self.limite_bps = motor, item, ao_progresso, log, limite_bps
        self.peer_id = motor.peer_id
        self.meta: "MetaTorrent | None" = None
        self.arm: "Armazenamento | None" = None
        self.tem: list = []
        self.andamento: dict = {}
        self.disponibilidade: list = []
        self.peers: dict = {}                 # ender -> Peer
        self.conhecidos: dict = {}            # ender -> momento em que pode tentar de novo
        self.banidos: set = set()
        self.meta_pedacos: dict = {}
        self.meta_tamanho = 0
        self.parar_motivo = None
        self.fim = asyncio.Event()
        self.mudou = asyncio.Event()
        self.baixado, self.enviado = 0, 0
        self.med = Medidor()
        self.rastreadores: list = []
        self.info_hash = b""
        self.erro = None
        self._janela_vel = collections.deque()
        self.estado = "metadados"
        self.prio_pecas: list = []            # (3.8) prioridade de cada peça (0 = nenhum arquivo escolhido nela)
        self.util: list = []                  # bytes de arquivos escolhidos em cada peça

    # ---------------------------------------------------------------- início
    def _preparar_meta(self, meta: MetaTorrent) -> None:
        self.meta = meta
        item = self.item
        nome_dest = nome_seguro(item.get("nome_destino") or "", padrao="") or meta.nome
        item["nome"] = item.get("nome") or nome_dest
        item["tamanho_total"] = meta.total
        item["n_arquivos"] = len([a for a in meta.arquivos if a[0] is not None])
        if not item.get("torrent_b64"):
            item["torrent_b64"] = base64.b64encode(meta.info_cru).decode("ascii")      # metadados guardados (retomada)
        for r in meta.rastreadores:
            if r not in self.rastreadores:
                self.rastreadores.append(r)
        if not item.get("final"):
            base = Path(item["pasta_base"])
            if meta.multi:
                raiz_conteudo = nome_livre(base, nome_dest, e_pasta=True)
                item["pasta"], item["final"] = str(raiz_conteudo.parent), str(raiz_conteudo)
                item["raiz"] = str(raiz_conteudo)
            else:
                if item.get("pasta_individual", True):
                    pasta = nome_livre(base, os.path.splitext(nome_dest)[0] or nome_dest, e_pasta=True)
                else:
                    pasta = base
                final = pasta / nome_dest
                if final.exists() and not item.get("raiz"):
                    final = nome_livre(pasta, nome_dest)
                item["pasta"], item["final"], item["raiz"] = str(pasta), str(final), str(pasta)
            item["nome"] = Path(item["final"]).name
        raiz = Path(item["raiz"])
        if not meta.multi and Path(item["final"]).name != meta.nome:     # nome com número (colisão): só esse arquivo
            meta.arquivos = [([Path(item["final"]).name], meta.total)]
        prios = prioridades_do_item(meta, item) if meta.multi else [2]
        self.arm = Armazenamento(meta, raiz, pular={k for k, v in enumerate(prios)
                                                    if v == 0 and meta.arquivos[k][0] is not None})
        self._calcular_pecas(prios)
        item["tamanho"] = sum(self.util)
        self.tem = [False] * meta.n_pecas
        self.disponibilidade = [0] * meta.n_pecas
        for p in self.peers.values():
            if isinstance(p.tem_bruto, bytes) and p.tem_bruto:
                p.tem = bytes_para_bits(p.tem_bruto, meta.n_pecas)
            elif p.haves:
                p.tem = [i in p.haves for i in range(meta.n_pecas)]
            if isinstance(p.tem, list):
                for i, x in enumerate(p.tem):
                    if x:
                        self.disponibilidade[i] += 1

    def _calcular_pecas(self, prios: list) -> None:
        """Prioridade e bytes úteis de cada peça a partir das prioridades dos arquivos (peças atravessam arquivos)."""
        meta = self.meta
        n, tp = meta.n_pecas, meta.tam_peca
        self.prio_pecas, self.util = [0] * n, [0] * n
        pos = 0
        for k, (partes, tam) in enumerate(meta.arquivos):
            pr = prios[k] if k < len(prios) else 2
            if partes is not None and pr > 0 and tam > 0:
                a, b = pos, pos + tam
                for i in range(a // tp, (b - 1) // tp + 1):
                    ini = i * tp
                    self.util[i] += min(b, ini + meta.tamanho_peca(i)) - max(a, ini)
                    self.prio_pecas[i] = max(self.prio_pecas[i], pr)
            pos += tam

    def _completo(self) -> bool:
        return bool(self.tem) and all(t or not p for t, p in zip(self.tem, self.prio_pecas))

    async def _verificar_existente(self) -> None:
        """Retomada: as peças registradas valem se os arquivos não mudaram; senão confere peça por peça (com progresso)."""
        meta, item = self.meta, self.item
        salvo = item.get("pecas")
        if salvo and item.get("assinatura") == self.arm.assinatura():
            try:
                self.tem = bytes_para_bits(base64.b64decode(salvo), meta.n_pecas)
                return
            except (binascii.Error, ValueError):
                pass
        if not self.arm.existe_algo():
            return
        self.estado = item["estado"] = "verificando"
        loop = asyncio.get_running_loop()
        for i in range(meta.n_pecas):
            if self.parar_motivo:
                raise Parado(self.parar_motivo)
            if not self.prio_pecas[i]:
                continue                                    # peça só de arquivos não escolhidos: nem confere
            self.tem[i] = await loop.run_in_executor(None, self.arm.peca_confere, i)
            if i % 16 == 0 or i == meta.n_pecas - 1:
                item["verificado"] = (i + 1) / meta.n_pecas
                item["feito"] = self._feito()
                self.ao_progresso(item)
        item.pop("verificado", None)

    def _feito(self) -> int:
        if not self.meta:
            return 0
        return sum(self.util[i] for i, x in enumerate(self.tem) if x)

    def _salvar_retomada(self) -> None:
        if self.meta and self.arm:
            self.item["pecas"] = base64.b64encode(bits_para_bytes(self.tem, self.meta.n_pecas)).decode("ascii")
            self.item["assinatura"] = self.arm.assinatura()

    # ---------------------------------------------------------------- laço principal
    async def rodar(self) -> None:
        item = self.item
        try:
            if item.get("torrent_b64"):
                info_cru = base64.b64decode(item["torrent_b64"])
                self._preparar_meta(MetaTorrent(info_cru, item.get("rastreadores") or [], []))
                self.info_hash = self.meta.info_hash
            elif item["tipo"] == "torrent":
                dados = await asyncio.get_running_loop().run_in_executor(None, _ler_torrent_da_entrada, item["entrada"])
                meta = MetaTorrent.de_arquivo(dados)
                item["rastreadores"] = meta.rastreadores
                self._preparar_meta(meta)
                self.info_hash = meta.info_hash
            else:
                mg = ler_magnet(item["entrada"])
                self.info_hash = mg["info_hash"]
                self.rastreadores = list(mg["rastreadores"])
                item["nome"] = item.get("nome") or mg["nome"] or ("magnet " + self.info_hash.hex()[:10])
            item["info_hash"] = self.info_hash.hex()
            self.rastreadores = list(dict.fromkeys(self.rastreadores + list(item.get("rastreadores") or [])))
            self.motor.registrar(self)
            if self.meta is not None:
                await self._verificar_existente()
                if self._completo():
                    await self._concluir()
                    return
            self.estado = item["estado"] = "baixando" if self.meta else "metadados"
            item["msg"] = "" if self.meta else "Procurando peers para ler os metadados do magnet…"
            self.ao_progresso(item)
            tarefas = [asyncio.ensure_future(self._rastreadores()), asyncio.ensure_future(self._conectar_peers()),
                       asyncio.ensure_future(self._relogio())]
            privado = self.meta is not None and self.meta.privado
            if not privado and self.motor.usar_dht:
                tarefas.append(asyncio.ensure_future(self._dht()))
            try:
                await self.fim.wait()
            finally:
                for t in tarefas:
                    t.cancel()
                await asyncio.gather(*tarefas, return_exceptions=True)
            if self.parar_motivo:
                raise Parado(self.parar_motivo)
            if self.erro:
                raise self.erro
            await self._concluir()
        finally:
            for p in list(self.peers.values()):
                p.fechar()
            self.peers.clear()
            self._salvar_retomada()
            if self.arm:
                self.arm.fechar()
            self.motor.desregistrar(self)

    async def _concluir(self) -> None:
        self.arm.ajustar_tamanhos()
        ruins = [i for i in range(self.meta.n_pecas) if self.prio_pecas[i] and not await
                 asyncio.get_running_loop().run_in_executor(None, self.arm.peca_confere, i)] \
            if self.item.get("_conferir_fim", True) else []
        if ruins:
            for i in ruins:
                self.tem[i] = False
            raise ErroTransferencia("%d peça(s) não conferiram na verificação final. Retome para baixar de novo só "
                                    "essas peças." % len(ruins))
        self._salvar_retomada()
        self.arm.apagar_partes()
        parcial = any(not p for p in self.prio_pecas) or len(self.arm.pular) > 0
        self.item.update(feito=sum(self.util), velocidade=0.0, eta=None,
                         conferido="SHA-1 de todas as peças" + (" dos arquivos escolhidos" if parcial else ""))
        self.motor.anuncio_final = asyncio.ensure_future(self._anunciar_todos("completed"))

    def parar(self, motivo: str) -> None:
        self.parar_motivo = motivo
        self.fim.set()

    # ---------------------------------------------------------------- descoberta de peers
    def _novos_peers(self, lista) -> None:
        for ender in lista:
            ender = (str(ender[0]), int(ender[1]))
            if ender in self.banidos or ender in self.peers:
                continue
            try:
                if ipaddress.ip_address(ender[0]).is_unspecified:
                    continue
            except ValueError:
                continue
            self.conhecidos.setdefault(ender, 0.0)
        self.mudou.set()

    async def _anunciar(self, url: str, evento: str = "") -> dict:
        falta = (sum(self.util) - self._feito()) if self.meta else 1 << 30
        porta = self.motor.porta or 6881
        if url.startswith(("http://", "https://")):
            return await asyncio.get_running_loop().run_in_executor(
                None, anunciar_http, url, self.info_hash, self.peer_id, porta, self.baixado, self.enviado, falta, evento)
        if url.startswith("udp://"):
            ev = {"": 0, "completed": 1, "started": 2, "stopped": 3}.get(evento, 0)
            return await anunciar_udp(url, self.info_hash, self.peer_id, porta, self.baixado, self.enviado, falta, ev)
        raise ErroTransferencia("rastreador com protocolo desconhecido")

    async def _anunciar_todos(self, evento: str) -> None:
        for url in self.rastreadores[:12]:
            try:
                await asyncio.wait_for(self._anunciar(url, evento), 10)
            except Exception:
                pass

    async def _rastreadores(self) -> None:
        proximo = {u: 0.0 for u in self.rastreadores}
        primeira = set(self.rastreadores)
        avisou = False
        while True:
            agora = time.monotonic()
            for url in list(proximo):
                if proximo[url] > agora:
                    continue
                try:
                    r = await asyncio.wait_for(self._anunciar(url, "started" if url in primeira else ""), 25)
                    primeira.discard(url)
                    self._novos_peers(r["peers"])
                    if r.get("seeds") is not None:
                        self.item["seeds_rastreador"] = int(r["seeds"])
                        self.item["peers_rastreador"] = int(r.get("leechers") or 0)
                    proximo[url] = agora + max(60, min(int(r.get("intervalo") or 1800), 3600))
                except Exception as e:
                    proximo[url] = agora + 120
                    if not avisou:
                        avisou = True
                        self.log("warn", "Rastreador %s: %s" % (urllib.parse.urlsplit(url).netloc or url[:40], e))
            await asyncio.sleep(5)

    async def _dht(self) -> None:
        while True:
            if len(self.peers) < 15:
                try:
                    achados = await self.motor.dht.buscar_peers(self.info_hash, cancelado=lambda: self.fim.is_set())
                    self._novos_peers(achados)
                except Exception:
                    pass
            await asyncio.sleep(120 if self.peers else 30)

    async def _conectar_peers(self) -> None:
        while True:
            agora = time.monotonic()
            livres = MAX_PEERS - len(self.peers)
            cands = [e for e, quando in self.conhecidos.items() if quando <= agora and e not in self.peers]
            random.shuffle(cands)
            for ender in cands[:max(0, min(livres, 12))]:
                self.conhecidos[ender] = agora + 90
                asyncio.ensure_future(self._peer_saida(ender))
            self.mudou.clear()
            try:
                await asyncio.wait_for(self.mudou.wait(), 3)
            except asyncio.TimeoutError:
                pass

    async def _peer_saida(self, ender) -> None:
        try:
            r, w = await asyncio.wait_for(asyncio.open_connection(ender[0], ender[1]), 8)
        except (OSError, asyncio.TimeoutError):
            return
        try:
            w.write(self.motor.aperto(self.info_hash))
            await w.drain()
            resp = await asyncio.wait_for(r.readexactly(68), 10)
        except (OSError, asyncio.TimeoutError, asyncio.IncompleteReadError):
            w.close()
            return
        if resp[:20] != b"\x13BitTorrent protocol" or resp[28:48] != self.info_hash:
            w.close()
            return
        if resp[48:68] == self.peer_id:
            self.banidos.add(ender)
            w.close()
            return
        p = Peer(self, ender, r, w)
        p.id_remoto = resp[48:68]
        await self.sessao_peer(p, bool(resp[25] & 0x10))

    # ---------------------------------------------------------------- uma conexão
    async def sessao_peer(self, p: Peer, ext: bool) -> None:
        if p.ender in self.peers or len(self.peers) >= MAX_PEERS + 10:
            p.fechar()
            return
        self.peers[p.ender] = p
        try:
            if ext:
                hs = {"m": {"ut_metadata": EXT_METADADOS, "ut_pex": EXT_PEX}, "v": "yPeleTools " + VERSAO_MOTOR,
                      "reqq": 250}
                if self.meta:
                    hs["metadata_size"] = len(self.meta.info_cru)
                if self.motor.porta:
                    hs["p"] = self.motor.porta
                await p.enviar_ext(0, hs)
            if self.meta and any(self.tem):
                await p.enviar(5, bits_para_bytes(self.tem, self.meta.n_pecas))
            await self._ler_mensagens(p)
        except (OSError, asyncio.IncompleteReadError, asyncio.TimeoutError, ErroBencode, ValueError, struct.error):
            pass
        finally:
            self._remover_peer(p)

    def _remover_peer(self, p: Peer) -> None:
        p.fechar()
        if self.peers.get(p.ender) is p:
            del self.peers[p.ender]
        if isinstance(p.tem, list) and self.disponibilidade:
            for i, x in enumerate(p.tem):
                if x and i < len(self.disponibilidade):
                    self.disponibilidade[i] -= 1
        for (pc, bl) in list(p.pedidos):
            pe = self.andamento.get(pc)
            if pe and bl in pe.pedidos:
                pe.pedidos[bl].discard(p)
                if not pe.pedidos[bl]:
                    del pe.pedidos[bl]
        p.pedidos.clear()
        self.mudou.set()

    async def _ler_mensagens(self, p: Peer) -> None:
        limite = 2 * BLOCO + 1024 if not self.meta else max(2 * BLOCO, (self.meta.n_pecas + 7) // 8) + 1024
        while not self.fim.is_set():
            cab = await asyncio.wait_for(p.r.readexactly(4), 150)
            n = struct.unpack(">I", cab)[0]
            p.ultimo = time.monotonic()
            if n == 0:
                continue
            if n > max(limite, 1 << 20) + 13:
                raise ValueError("mensagem grande demais")
            corpo = await asyncio.wait_for(p.r.readexactly(n), 60)
            await self._mensagem(p, corpo[0], corpo[1:])

    async def _mensagem(self, p: Peer, tipo: int, c: bytes) -> None:
        if tipo == 0:                                       # choke
            p.estrangulado_por_nos = True
            self._devolver_pedidos(p)
        elif tipo == 1:                                     # unchoke
            p.estrangulado_por_nos = False
            await self._pedir(p)
        elif tipo == 2:
            p.ele_interessado = True
            await self._estrangular()
        elif tipo == 3:
            p.ele_interessado = False
        elif tipo == 4:                                     # have
            i = struct.unpack(">I", c[:4])[0]
            if self.meta:
                if 0 <= i < self.meta.n_pecas:
                    if not isinstance(p.tem, list):
                        p.tem = [False] * self.meta.n_pecas
                    if not p.tem[i]:
                        p.tem[i] = True
                        self.disponibilidade[i] += 1
                    await self._interesse(p)
                    await self._pedir(p)
            else:
                p.haves.add(i)
        elif tipo == 5:                                     # bitfield
            if self.meta:
                p.tem = bytes_para_bits(c, self.meta.n_pecas)
                for i, x in enumerate(p.tem):
                    if x:
                        self.disponibilidade[i] += 1
                await self._interesse(p)
            else:
                p.tem_bruto = bytes(c)
        elif tipo == 6:                                     # request: ele quer um bloco nosso
            await self._atender(p, c)
        elif tipo == 7:                                     # piece
            await self._bloco(p, c)
        elif tipo == 20:
            await self._extensao(p, c)

    # ---------------------------------------------------------------- extensões: metadados e PEX
    async def _extensao(self, p: Peer, c: bytes) -> None:
        ext_id, resto = c[0], c[1:]
        if ext_id == 0:
            d = bdecode(resto)
            if isinstance(d, dict):
                m = d.get(b"m") if isinstance(d.get(b"m"), dict) else {}
                p.ext = {k.decode("latin-1"): v for k, v in m.items() if isinstance(v, int)}
                p.meta_tam = int(d.get(b"metadata_size") or 0)
                if self.meta is None and p.ext.get("ut_metadata") and 0 < p.meta_tam < 16 * 1024 * 1024:
                    self.meta_tamanho = self.meta_tamanho or p.meta_tam
                    await self._pedir_metadados(p)
                elif self.meta is not None:
                    await self._interesse(p)
            return
        if ext_id == EXT_METADADOS:
            await self._msg_metadados(p, resto)
        elif ext_id == EXT_PEX:
            try:
                d = bdecode(resto)
            except ErroBencode:
                return
            if isinstance(d, dict) and not (self.meta and self.meta.privado):
                if isinstance(d.get(b"added"), bytes):
                    self._novos_peers(_peers_compactos(d[b"added"]))

    async def _pedir_metadados(self, p: Peer) -> None:
        n = (self.meta_tamanho + BLOCO - 1) // BLOCO
        for i in range(n):
            if i not in self.meta_pedacos:
                await p.enviar_ext(p.ext["ut_metadata"], {"msg_type": 0, "piece": i})

    async def _msg_metadados(self, p: Peer, resto: bytes) -> None:
        # a mensagem é um dicionário bencode seguido (em 'data') dos bytes do pedaço
        d, fim = _bdecode_prefixo(resto)
        if not isinstance(d, dict):
            return
        tipo, pedaco = d.get(b"msg_type"), d.get(b"piece")
        if tipo == 0 and self.meta is not None and isinstance(pedaco, int) and p.ext.get("ut_metadata"):
            dados = self.meta.info_cru[pedaco * BLOCO:(pedaco + 1) * BLOCO]
            if dados:
                await p.enviar_ext(p.ext["ut_metadata"], {"msg_type": 1, "piece": pedaco,
                                                          "total_size": len(self.meta.info_cru)}, dados)
            else:
                await p.enviar_ext(p.ext["ut_metadata"], {"msg_type": 2, "piece": pedaco})
        elif tipo == 1 and self.meta is None and isinstance(pedaco, int):
            self.meta_pedacos[pedaco] = resto[fim:]
            n = (self.meta_tamanho + BLOCO - 1) // BLOCO
            if n and len(self.meta_pedacos) >= n:
                info_cru = b"".join(self.meta_pedacos.get(i, b"") for i in range(n))[:self.meta_tamanho]
                if hashlib.sha1(info_cru).digest() != self.info_hash:
                    self.meta_pedacos.clear()               # algum peer mandou lixo: pede de novo a outros
                    p.ruins += 1
                    return
                meta = MetaTorrent(info_cru, self.rastreadores, [])
                self.item["torrent_b64"] = base64.b64encode(info_cru).decode("ascii")
                self.item["rastreadores"] = self.rastreadores
                self.log("info", "Magnet: metadados recebidos (%s, %d peça(s))." % (meta.nome, meta.n_pecas))
                if self.item.get("escolher_ao_receber") and meta.multi and not self.item.get("prioridades"):
                    # (3.8) a pessoa pediu para escolher os arquivos: para aqui, antes de criar qualquer arquivo
                    self.item["nome"] = self.item.get("nome") or meta.nome
                    self.item["tamanho"] = meta.total
                    self.parar("escolher")
                    return
                self._preparar_meta(meta)
                await self._verificar_existente()
                self.estado = self.item["estado"] = "baixando"
                self.item["msg"] = ""
                self.ao_progresso(self.item)
                if self._completo():
                    self.fim.set()
                    return
                for q in list(self.peers.values()):
                    await self._interesse(q)
                    await self._pedir(q)

    # ---------------------------------------------------------------- download de blocos
    async def _interesse(self, p: Peer) -> None:
        if not self.meta or not isinstance(p.tem, list):
            return
        quer = any(x and not self.tem[i] and self.prio_pecas[i] for i, x in enumerate(p.tem))
        if quer and not p.interessado_nele:
            p.interessado_nele = True
            await p.enviar(2)
        elif not quer and p.interessado_nele:
            p.interessado_nele = False
            await p.enviar(3)

    def _devolver_pedidos(self, p: Peer) -> None:
        for (pc, bl) in list(p.pedidos):
            pe = self.andamento.get(pc)
            if pe and bl in pe.pedidos:
                pe.pedidos[bl].discard(p)
                if not pe.pedidos[bl]:
                    del pe.pedidos[bl]
        p.pedidos.clear()

    def _escolher_blocos(self, p: Peer, quantos: int) -> list:
        escolha = []
        fim_de_jogo = self._fim_de_jogo()
        for pe in sorted(self.andamento.values(), key=lambda x: len(x.recebidos), reverse=True):
            if not p.possui(pe.indice):
                continue
            for b in pe.blocos_faltando():
                ja = pe.pedidos.get(b)
                if (not ja or (fim_de_jogo and p not in ja and len(ja) < 3)) and (pe.indice, b) not in p.pedidos:
                    escolha.append((pe.indice, b))
                    if len(escolha) >= quantos:
                        return escolha
        if len(self.andamento) < 48:
            cands = [i for i in range(self.meta.n_pecas) if not self.tem[i] and self.prio_pecas[i]
                     and i not in self.andamento and p.possui(i)]
            random.shuffle(cands)
            # (3.8) prioridade do arquivo primeiro; no empate, a peça mais rara
            cands.sort(key=lambda i: (-self.prio_pecas[i], self.disponibilidade[i]))
            for i in cands[:4]:
                pe = self.andamento[i] = PecaEmAndamento(i, self.meta.tamanho_peca(i))
                for b in range(pe.n_blocos):
                    escolha.append((i, b))
                    if len(escolha) >= quantos:
                        return escolha
        return escolha

    def _fim_de_jogo(self) -> bool:
        faltam = sum(1 for x, pr in zip(self.tem, self.prio_pecas) if not x and pr)
        if faltam > len(self.andamento) or faltam > 8:
            return False
        return all(len(pe.pedidos) + len(pe.recebidos) >= pe.n_blocos for pe in self.andamento.values())

    async def _pedir(self, p: Peer) -> None:
        if not self.meta or p.estrangulado_por_nos or p.fechado or self.fim.is_set():
            return
        vaga = PEDIDOS_POR_PEER - len(p.pedidos)
        if vaga <= 0:
            return
        for pc, bl in self._escolher_blocos(p, vaga):
            pe = self.andamento[pc]
            pe.pedidos.setdefault(bl, set()).add(p)
            p.pedidos.add((pc, bl))
            await p.enviar(6, struct.pack(">III", pc, bl * BLOCO, pe.tam_bloco(bl)))

    async def _bloco(self, p: Peer, c: bytes) -> None:
        if not self.meta or len(c) < 8:
            return
        pc, ini = struct.unpack(">II", c[:8])
        dados = c[8:]
        bl = ini // BLOCO
        p.pedidos.discard((pc, bl))
        pe = self.andamento.get(pc)
        if pe is None or ini % BLOCO or bl >= pe.n_blocos or len(dados) != pe.tam_bloco(bl) or bl in pe.recebidos:
            await self._pedir(p)
            return
        pe.recebidos[bl] = dados
        pe.peers.add(p.ender)
        outros = pe.pedidos.pop(bl, set())
        for q in outros:                                    # fim de jogo: cancela o mesmo bloco nos outros peers
            if q is not p and (pc, bl) in q.pedidos:
                q.pedidos.discard((pc, bl))
                try:
                    await q.enviar(8, struct.pack(">III", pc, ini, len(dados)))
                except OSError:
                    pass
        p.recebido += len(dados)
        self.baixado += len(dados)
        await self._limitar(len(dados))
        if pe.completa():
            del self.andamento[pc]
            peca = pe.dados()
            if hashlib.sha1(peca).digest() == self.meta.hashes[pc]:
                await asyncio.get_running_loop().run_in_executor(None, self.arm.gravar, pc * self.meta.tam_peca, peca)
                self.tem[pc] = True
                for q in list(self.peers.values()):
                    try:
                        await q.enviar(4, struct.pack(">I", pc))
                    except OSError:
                        pass
                if self._completo():
                    self.fim.set()
                    return
                if sum(self.tem) % 8 == 0:
                    self._salvar_retomada()
            else:
                self.log("warn", "Peça %d veio corrompida (SHA-1 não confere); baixando de novo." % pc)
                for ender in pe.peers:
                    q = self.peers.get(ender)
                    if q is not None:
                        q.ruins += 1
                        if q.ruins >= 3:
                            self.banidos.add(ender)
                            q.fechar()
        await self._pedir(p)

    async def _limitar(self, n: int) -> None:
        lim = self.limite_bps() or 0
        if lim <= 0:
            return
        agora = time.monotonic()
        self._janela_vel.append((agora, n))
        while self._janela_vel and agora - self._janela_vel[0][0] > 1.0:
            self._janela_vel.popleft()
        total = sum(b for _, b in self._janela_vel)
        if total > lim:
            await asyncio.sleep(min(1.0, (total - lim) / lim))

    # ---------------------------------------------------------------- envio (os outros baixam de nós)
    async def _estrangular(self) -> None:
        interessados = [q for q in self.peers.values() if q.ele_interessado]
        interessados.sort(key=lambda q: q.recebido, reverse=True)     # quem mais nos manda dados é atendido primeiro
        for k, q in enumerate(interessados):
            liberar = k < 4
            if liberar and q.nos_estrangula:
                q.nos_estrangula = False
                await q.enviar(1)
            elif not liberar and not q.nos_estrangula:
                q.nos_estrangula = True
                await q.enviar(0)

    async def _atender(self, p: Peer, c: bytes) -> None:
        if p.nos_estrangula or not self.meta or len(c) < 12:
            return
        pc, ini, n = struct.unpack(">III", c[:12])
        if not (0 <= pc < self.meta.n_pecas) or not self.tem[pc] or n > 2 * BLOCO or ini + n > self.meta.tamanho_peca(pc):
            return
        dados = await asyncio.get_running_loop().run_in_executor(None, self.arm.ler, pc * self.meta.tam_peca + ini, n)
        await p.enviar(7, struct.pack(">II", pc, ini) + dados)
        p.enviado += n
        self.enviado += n

    # ---------------------------------------------------------------- relógio: progresso e conexões paradas
    async def _relogio(self) -> None:
        ultimo_salvo = time.monotonic()
        while True:
            await asyncio.sleep(0.5)
            item = self.item
            feito = self._feito()
            self.med.somar(self.baixado)
            vel = self.med.velocidade()
            total = sum(self.util) if self.meta else None
            eta = (total - feito) / vel if (total and vel > 0) else None
            seeds = sum(1 for q in self.peers.values() if q.completo())
            item.update(feito=feito, velocidade=vel, eta=eta, peers=len(self.peers), seeds=seeds,
                        enviado=self.enviado)
            if self.meta is None:
                item["msg"] = ("Lendo os metadados do magnet com %d peer(s)…" % len(self.peers)) if self.peers else \
                    "Procurando peers para ler os metadados do magnet…"
            elif not self.peers:
                item["msg"] = "Procurando peers…"
            else:
                item["msg"] = ""
            self.ao_progresso(item)
            agora = time.monotonic()
            for q in list(self.peers.values()):
                if q.pedidos and agora - q.ultimo > 45:      # parado com pedidos pendentes: devolve os pedidos
                    self._devolver_pedidos(q)
                    q.fechar()
            if self.meta:
                for q in list(self.peers.values()):
                    if not q.estrangulado_por_nos and len(q.pedidos) < PEDIDOS_POR_PEER // 2:
                        await self._pedir(q)
            if agora - ultimo_salvo > 15:
                ultimo_salvo = agora
                self._salvar_retomada()


def _bdecode_prefixo(dados: bytes):
    """Decodifica o primeiro valor bencode de `dados` e devolve (valor, posição do fim)."""
    for fim in range(2, min(len(dados), 4096) + 1):
        if dados[fim - 1:fim] != b"e":
            continue
        try:
            return bdecode(dados[:fim]), fim
        except ErroBencode:
            continue
    return None, 0


def _ler_torrent_da_entrada(entrada: str) -> bytes:
    if re.match(r"^https?://", entrada, re.I):
        try:
            with _abrir(entrada, timeout=25) as r:
                dados = r.read(20 * 1024 * 1024 + 1)
        except urllib.error.HTTPError as e:
            raise _erro_http(e)
        except (urllib.error.URLError, OSError) as e:
            raise ErroTransferencia("Não consegui baixar o arquivo .torrent (%s)." % getattr(e, "reason", e))
    else:
        try:
            dados = Path(entrada).read_bytes()
        except OSError as e:
            raise ErroTransferencia("Não consegui ler o arquivo .torrent (%s)." % (e.strerror or e), True)
    if len(dados) > 20 * 1024 * 1024:
        raise ErroTransferencia("O arquivo .torrent é grande demais.", True)
    return dados


class MotorTorrent:
    """O laço asyncio de todos os torrents (uma thread), a porta de entrada para os peers que se conectam a nós e o DHT."""

    def __init__(self, porta_preferida: int = 0, usar_dht: bool = True, dht_iniciais=None):
        self.peer_id = b"-YP0370-" + os.urandom(12)
        self.porta = 0
        self.porta_preferida = porta_preferida
        self.usar_dht = usar_dht
        self.dht = DHT(dht_iniciais)
        self.loop = None
        self._thread = None
        self._pronto = threading.Event()
        self.tarefas: dict = {}               # info_hash -> TarefaTorrent
        self.servidor = None

    def aperto(self, info_hash: bytes) -> bytes:
        reservado = bytearray(8)
        reservado[5] |= 0x10                    # extensões (BEP 10)
        return b"\x13BitTorrent protocol" + bytes(reservado) + info_hash + self.peer_id

    def iniciar(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._rodar, daemon=True, name="ytorrents-motor")
        self._thread.start()
        self._pronto.wait(10)

    def _rodar(self) -> None:
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._abrir_porta())
        self._pronto.set()
        self.loop.run_forever()

    async def _abrir_porta(self) -> None:
        portas = [self.porta_preferida] if self.porta_preferida else []
        portas += list(range(6881, 6890)) + [0]
        for pt in portas:
            try:
                self.servidor = await asyncio.start_server(self._entrada, "0.0.0.0", pt)
                self.porta = self.servidor.sockets[0].getsockname()[1]
                return
            except OSError:
                continue

    async def _entrada(self, r, w) -> None:
        try:
            ap = await asyncio.wait_for(r.readexactly(68), 10)
        except (OSError, asyncio.TimeoutError, asyncio.IncompleteReadError):
            w.close()
            return
        t = self.tarefas.get(ap[28:48])
        if ap[:20] != b"\x13BitTorrent protocol" or t is None:
            w.close()
            return
        try:
            w.write(self.aperto(t.info_hash))
            await w.drain()
        except OSError:
            w.close()
            return
        ender = w.get_extra_info("peername")[:2]
        p = Peer(t, ender, r, w, entrada=True)
        await t.sessao_peer(p, bool(ap[25] & 0x10))

    def registrar(self, t: TarefaTorrent) -> None:
        self.tarefas[t.info_hash] = t

    def desregistrar(self, t: TarefaTorrent) -> None:
        if self.tarefas.get(t.info_hash) is t:
            del self.tarefas[t.info_hash]

    def baixar(self, item: dict, ao_progresso, log, limite_bps, ctl: Controle) -> None:
        """Roda o torrent até o fim (bloqueia a thread que chamou, não o laço). Levanta Parado/ErroTransferencia."""
        self.iniciar()
        tarefa_ref = {}

        async def principal():
            t = TarefaTorrent(self, item, ao_progresso, log, limite_bps)
            tarefa_ref["t"] = t
            if ctl.pedido:
                t.parar(ctl.pedido)
            await t.rodar()
        fut = asyncio.run_coroutine_threadsafe(principal(), self.loop)
        while True:
            try:
                fut.result(timeout=0.3)
                return
            except concurrent.futures.TimeoutError:
                pass
            if ctl.pedido and "t" in tarefa_ref:
                self.loop.call_soon_threadsafe(tarefa_ref["t"].parar, ctl.pedido)

    def encerrar(self) -> None:
        if self.loop is None:
            return
        for t in list(self.tarefas.values()):
            self.loop.call_soon_threadsafe(t.parar, "pausar")
        time.sleep(0.3)
        self.loop.call_soon_threadsafe(self.dht.fechar)
        if self.servidor is not None:
            self.loop.call_soon_threadsafe(self.servidor.close)
        self.loop.call_soon_threadsafe(self.loop.stop)


# ======================================================================================================================
# Gerenciador da fila (o que a aba yTorrents usa)
# ======================================================================================================================
ESTADOS_ATIVOS = ("resolvendo", "baixando", "verificando", "metadados")
ESTADOS_FIM = ("concluido", "erro", "cancelado")


def _fmt_tam(n) -> str:
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return ("%.0f %s" if u in ("B", "KB") else "%.1f %s") % (n, u)
        n /= 1024
    return "%d B" % n


def _agora_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class Gerenciador:
    """Fila persistente de transferências (HTTP e torrent), com até N ao mesmo tempo (N de `opcoes()['simultaneos']`).
    Cada item é um dict simples (vai para o JSON da fila). Eventos para a interface por ao_evento(tipo, *dados):
      ('lista',)              itens entraram, saíram ou mudaram de estado
      ('prog', id)            progresso de um item (valores do momento no próprio dict)
      ('log', nivel, texto)   mensagem para o painel de logs
    `pasta_base()`: pasta onde as transferências novas são guardadas (ex.: Downloads/yPeléTools/yTorrents)."""

    def __init__(self, arquivo, pasta_base, ao_evento, opcoes=None, motor_torrent=None):
        self.arquivo = Path(arquivo) if arquivo else None
        self.pasta_base = pasta_base
        self.ao_evento = ao_evento
        self.opcoes = opcoes or (lambda: {})
        self.itens: list = []
        self.trava = threading.RLock()
        self.controles: dict = {}
        self.rodando = False
        self.fechando = False
        self._acordar = threading.Event()
        self._gerente = None
        self.torrent = motor_torrent
        self._ultimo_salvar = 0.0
        # Beta 3.7.1: registro dos arquivos e pastas que o PRÓPRIO yTorrents criou (caminho, tamanho e data exatos).
        # É a única lista usada por "excluir arquivos baixados": nada fora dela é apagado.
        self.gerenciados: list = []

    # ---------------------------------------------------------------- opções
    def _op(self, chave, padrao):
        try:
            v = self.opcoes().get(chave, padrao)
        except Exception:
            v = padrao
        return padrao if v is None else v

    def limite(self) -> int:
        try:
            return max(1, min(10, int(self._op("simultaneos", 3))))
        except (TypeError, ValueError):
            return 3

    def _log(self, nivel: str, texto: str) -> None:
        self.ao_evento("log", nivel, texto)

    # ---------------------------------------------------------------- entrada
    def novo_item(self, c: dict, pasta_base=None, sha256: str = "") -> dict:
        tipo = {"magnet": "magnet", "torrent_url": "torrent", "torrent_arquivo": "torrent"}.get(c["tipo"], "http")
        base = Path(pasta_base or self.pasta_base())
        it = {"id": uuid.uuid4().hex[:12], "entrada": c["texto"], "tipo": tipo, "provedor": c.get("provedor") or tipo,
              "nome": c.get("nome") or "", "tamanho": c.get("tamanho"), "feito": 0, "velocidade": 0.0, "eta": None,
              "estado": "fila", "msg": "", "pasta_base": str(base), "pasta": "", "final": "", "parcial": "",
              "pasta_individual": bool(self._op("pasta_individual", True)), "peers": None, "seeds": None,
              "criado_em": _agora_iso(), "concluido_em": "", "sha256": (sha256 or _hash_do_fragmento(c["texto"])),
              "origem": nome_provedor(c.get("provedor") or tipo), "base_ytorrents": str(base)}
        for k in ("prioridades", "nome_destino", "torrent_b64", "rastreadores", "escolher_ao_receber", "info_hash"):
            if c.get(k) not in (None, "", []):                       # (3.8) escolha feita na janela do torrent
                it[k] = c[k]
        return it

    def adicionar_torrent(self, meta: "MetaTorrent", entrada: str, pasta_base=None, prioridades=None,
                          nome_destino: str = "", iniciar: bool = False, agora: bool = True) -> "dict | None":
        """(Beta 3.8) Um torrent já lido, com a escolha da janela: pasta, nome, arquivos e prioridades. `agora`
        False = entra na fila pausado ("Adicionar sem iniciar")."""
        ih = meta.info_hash.hex()
        with self.trava:
            if any((i.get("info_hash") == ih) and i["estado"] not in ESTADOS_FIM for i in self.itens):
                self._log("warn", "Este torrent já está na fila: %s" % meta.nome)
                return None
            c = {"tipo": "torrent_arquivo", "texto": entrada, "provedor": "torrent", "nome": "",
                 "tamanho": meta.total, "torrent_b64": base64.b64encode(meta.info_cru).decode("ascii"),
                 "rastreadores": list(meta.rastreadores), "info_hash": ih}
            if prioridades is not None and meta.multi:
                c["prioridades"] = [max(0, min(3, int(v))) for v in prioridades]
            if nome_destino and nome_seguro(nome_destino, padrao="") != meta.nome:
                c["nome_destino"] = nome_seguro(nome_destino, limite=150, padrao="")
            it = self.novo_item(c, pasta_base)
            if not agora:
                it["estado"], it["msg"] = "pausado", "Adicionado sem iniciar."
            self.itens.append(it)
        self.salvar()
        self.ao_evento("lista")
        if iniciar and agora:
            self.iniciar()
        else:
            self._acordar.set()
        return it

    def definir_arquivos(self, iid: str, prioridades, pasta_base=None, nome_destino: str = "",
                         iniciar: bool = True) -> bool:
        """(Beta 3.8) A escolha de arquivos de um magnet cujos metadados chegaram (estado 'escolher'), ou de um torrent
        que ainda não começou a gravar nada. Nada é apagado: só vale para o que vai ser baixado daqui em diante."""
        it = self.achar(iid)
        if it is None or iid in self.controles or not it.get("torrent_b64"):
            return False
        if it["estado"] not in ("escolher", "fila", "pausado", "erro", "cancelado"):
            return False
        it["prioridades"] = [max(0, min(3, int(v))) for v in prioridades] if prioridades is not None else None
        if it["prioridades"] is None:
            it.pop("prioridades")
        it.pop("escolher_ao_receber", None)
        if not it.get("pecas"):                       # nada gravado ainda: pasta e nome ainda podem mudar
            if pasta_base:
                it["pasta_base"] = str(pasta_base)
            if nome_destino:
                it["nome_destino"] = nome_seguro(nome_destino, limite=150, padrao="")
            for k in ("pasta", "final", "raiz"):
                it[k] = ""
            it["nome"] = ""
        it.pop("assinatura", None)
        it["estado"], it["msg"] = ("fila", "") if iniciar else ("pausado", "Arquivos escolhidos; retome para baixar.")
        self.salvar()
        self.ao_evento("lista")
        if iniciar:
            self.iniciar()
        return True

    def adicionar(self, classificados: list, iniciar: bool = False, pasta_base=None) -> list:
        """Põe na fila (depois da revisão). Link já na fila (mesma entrada ou mesmo info hash) não entra de novo."""
        novos = []
        with self.trava:
            vivos = {(i.get("info_hash") or i["entrada"]) for i in self.itens if i["estado"] not in ESTADOS_FIM}
            for c in classificados:
                if c.get("tipo") in ("invalida", "vazia"):
                    continue
                chave = c.get("info_hash") or c["texto"]
                if chave in vivos:
                    self._log("warn", "Já está na fila: %s" % c["texto"][:90])
                    continue
                vivos.add(chave)
                it = self.novo_item(c, pasta_base)
                if c.get("info_hash"):
                    it["info_hash"] = c["info_hash"]
                self.itens.append(it)
                novos.append(it)
        if novos:
            self.salvar()
            self.ao_evento("lista")
            if iniciar:
                self.iniciar()
            else:
                self._acordar.set()
        return novos

    def analisar(self, classificados: list) -> list:
        """Para a revisão antes de entrar na fila: nome, tamanho, tipo e origem de cada link (pode usar a rede; chame
        fora da interface). Nada é baixado além do necessário para ler os metadados."""
        saida = []
        for c in classificados:
            r = dict(c)
            r.update(nome=c.get("nome") or "", tamanho=None, erro="", origem=nome_provedor(c.get("provedor")))
            try:
                if c["tipo"] == "invalida":
                    r["erro"] = c.get("motivo") or "inválido"
                elif c["tipo"] == "pasta":
                    r.update(origem="%s (pasta)" % nome_provedor(c.get("provedor")), pasta=True,
                             nome=c.get("nome") or "Pasta: os arquivos aparecem na janela de escolha")
                elif c["tipo"] in ("torrent_arquivo", "torrent_url"):
                    meta = MetaTorrent.de_arquivo(_ler_torrent_da_entrada(c["texto"]))
                    r.update(nome=meta.nome, tamanho=meta.total, n_arquivos=len(meta.arquivos),
                             info_hash=meta.info_hash.hex(), origem="Torrent")
                elif c["tipo"] == "magnet":
                    r["origem"] = "Magnet"
                    r["nome"] = r["nome"] or "(o nome chega com os metadados)"
                else:
                    prov = provedor_para(c["texto"])
                    rec = prov.resolver(c["texto"]) if prov is not _GENERICO else Recurso(c["texto"])
                    nome, tam = rec.nome, rec.tamanho
                    if not nome or not tam:
                        try:
                            with _abrir(rec.url, dict(rec.cabecalhos, Range="bytes=0-0"), timeout=15) as resp:
                                tipo_ct = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
                                if not nome:
                                    nome = nome_da_resposta(resp, resp.geturl())
                                m = re.search(r"/(\d+)\s*$", resp.headers.get("Content-Range", ""))
                                if m:
                                    tam = tam or int(m.group(1))
                                elif resp.headers.get("Content-Length", "").isdigit() and getattr(resp, "status", 200) == 200:
                                    tam = tam or int(resp.headers["Content-Length"])
                                if tipo_ct == "text/html":
                                    r["aviso"] = "O link abre uma página: o app procura nela um link de download único."
                        except urllib.error.HTTPError as e:
                            raise _erro_http(e)
                        except (urllib.error.URLError, OSError) as e:
                            r["aviso"] = "Não consegui ler o tamanho agora (%s); o download tenta mesmo assim." % (
                                getattr(e, "reason", e))
                    r.update(nome=nome or "", tamanho=tam, origem=rec.origem or r["origem"])
            except ErroTransferencia as e:
                r["erro"] = str(e)
            except Exception as e:                           # nada derruba a revisão
                r["erro"] = "Não consegui ler este link (%s)." % e
            r["tipo_arquivo"] = "pasta" if c["tipo"] == "pasta" else \
                tipo_arquivo(r.get("nome"), c["tipo"] in ("magnet", "torrent_arquivo", "torrent_url"))
            saida.append(r)
        return saida

    # ---------------------------------------------------------------- pastas (Beta 3.7.1)
    def listar_pasta(self, c: dict, deve_parar=None) -> dict:
        """Lê a pasta (rede: chame fora da interface). Cada arquivo ganha 'pos' e 'tipo_arquivo'."""
        prov = provedor_para(c["texto"])
        lista = prov.listar(c["texto"], deve_parar=deve_parar)
        for k, a in enumerate(lista["arquivos"]):
            a["pos"] = k
            a["tipo_arquivo"] = tipo_arquivo(a["nome"])
        lista["entrada"] = c["texto"]
        lista["provedor_chave"] = prov.chave
        return lista

    def adicionar_pasta(self, lista: dict, posicoes, pasta_base=None, iniciar: bool = False) -> list:
        """Põe na fila os arquivos escolhidos de uma pasta: um item por arquivo (cada um com estado, progresso e
        retomada próprios, respeitando o limite de downloads ao mesmo tempo), dentro de uma pasta com o nome da pasta
        de origem e as mesmas subpastas. Se já existir uma pasta com esse nome, entra um número (nada é misturado nem
        sobrescrito)."""
        base = Path(pasta_base or self.pasta_base())
        escolhidos = [a for a in lista["arquivos"] if a["pos"] in set(posicoes) and a.get("acessivel") and a.get("url")]
        if not escolhidos:
            return []
        with self.trava:
            ocupadas = [i.get("grupo", {}).get("raiz") for i in self.itens if i.get("grupo")]
            raiz = nome_livre(base, nome_seguro(lista["nome"], limite=100, padrao="pasta"), e_pasta=True,
                              ocupados=[o for o in ocupadas if o])
            grupo = {"id": uuid.uuid4().hex[:10], "nome": lista["nome"], "raiz": str(raiz),
                     "provedor": lista.get("provedor") or ""}
            vivos = {i["entrada"] for i in self.itens if i["estado"] not in ESTADOS_FIM}
            novos = []
            for a in escolhidos:
                if a["url"] in vivos:
                    self._log("warn", "Já está na fila: %s" % a["nome"][:90])
                    continue
                vivos.add(a["url"])
                destino = raiz.joinpath(*[p for p in a.get("subpasta", "").split("/") if p])
                c = {"tipo": "http", "texto": a["url"], "provedor": lista.get("provedor_chave") or "",
                     "nome": a["nome"], "tamanho": a.get("tamanho")}
                it = self.novo_item(c, destino, sha256=a.get("sha256") or "")
                it["base_ytorrents"] = str(base)
                it.update(pasta_individual=False, grupo=grupo, subpasta=a.get("subpasta", ""), nome_lista=a["nome"],
                          origem="%s · pasta %s" % (lista.get("provedor") or "", lista["nome"]))
                self.itens.append(it)
                novos.append(it)
        if novos:
            self._log("info", "yTorrents: %d arquivo(s) da pasta “%s” na fila (em %s)." % (len(novos), lista["nome"],
                                                                                           raiz))
            self.salvar()
            self.ao_evento("lista")
            if iniciar:
                self.iniciar()
            else:
                self._acordar.set()
        return novos

    def remover_cancelados(self) -> int:
        """Tira da LISTA os itens cancelados. Não apaga arquivo nenhum (nem os parciais guardados) e não mexe em quem
        está baixando, na fila, pausado ou com erro."""
        with self.trava:
            antes = len(self.itens)
            self.itens = [i for i in self.itens if not (i["estado"] == "cancelado" and i["id"] not in self.controles)]
            n = antes - len(self.itens)
        if n:
            self.salvar()
            self.ao_evento("lista")
        return n

    # ---------------------------------------------------------------- arquivos gerenciados (Beta 3.7.1)
    def _registrar(self, it: dict) -> None:
        """Anota os arquivos que este item terminou de baixar (caminho, tamanho e data exatos) e as pastas que o
        yTorrents criou para ele. Só o que está aqui pode ser apagado por excluir_baixados()."""
        base = it.get("base_ytorrents") or it.get("pasta_base") or ""
        arquivos = []
        if it["tipo"] == "http" and it.get("final"):
            arquivos = [Path(it["final"])]
        elif it.get("torrent_b64") and it.get("raiz"):
            try:
                meta = MetaTorrent(base64.b64decode(it["torrent_b64"]))
                if not meta.multi:
                    arquivos = [Path(it["final"])]
                else:                                     # (3.8) só os arquivos escolhidos
                    prios = prioridades_do_item(meta, it)
                    arquivos = [c for c, _, _ in Armazenamento(meta, Path(it["raiz"]), pular={
                        k for k, v in enumerate(prios) if v == 0}).partes if c is not None]
            except (ErroTransferencia, binascii.Error, ValueError):
                arquivos = []
        entrada = {"item": it["id"], "nome": it.get("nome") or "", "base": base, "arquivos": [], "pastas": [],
                   "em": _agora_iso()}
        for a in arquivos:
            try:
                st = a.stat()
            except OSError:
                continue
            entrada["arquivos"].append({"caminho": str(a), "tamanho": st.st_size, "mtime_ns": st.st_mtime_ns})
        pastas = list(it.get("pastas_criadas") or [])
        if it["tipo"] != "http" and it.get("raiz"):
            raiz = Path(it["final"]) if Path(it["final"]).is_dir() else Path(it["raiz"])
            if it.get("pasta_individual", True) or Path(it["final"]).is_dir():
                pastas.append(str(raiz))
                pastas += [str(p) for a in arquivos for p in a.parents if p != raiz and p.is_relative_to(raiz)]
        entrada["pastas"] = sorted(set(pastas), key=len, reverse=True)
        if entrada["arquivos"]:
            with self.trava:
                self.gerenciados = [g for g in self.gerenciados if g.get("item") != it["id"]] + [entrada]

    @staticmethod
    def _base_segura(base: str) -> bool:
        """A pasta-base de um registro precisa ser uma pasta de verdade, e não a raiz do disco nem a pasta do usuário
        (um registro adulterado não pode levar o app a apagar fora dos downloads)."""
        try:
            b = Path(base).resolve()
        except (OSError, RuntimeError, ValueError):
            return False
        if not base or b == Path(b.anchor) or len(b.parts) < 3:
            return False
        try:
            if b == Path.home().resolve():
                return False
        except (OSError, RuntimeError):
            pass
        return True

    def _caminhos_em_uso(self) -> list:
        with self.trava:
            em_uso = []
            for i in self.itens:
                if i["estado"] in ESTADOS_ATIVOS + ("fila", "pausado", "escolher") or i["id"] in self.controles:
                    for k in ("final", "parcial", "raiz", "pasta"):
                        if i.get(k):
                            em_uso.append(Path(i[k]))
            return em_uso

    def _avaliar(self, reg: dict, arq: dict, em_uso: list) -> str:
        """'' se o arquivo pode ser apagado; senão, o motivo para deixar."""
        base = reg.get("base") or ""
        if not self._base_segura(base):
            return "pasta-base inválida no registro"
        p = Path(arq.get("caminho") or "")
        try:
            if p.is_symlink():
                return "é um atalho (link simbólico)"
            real = p.resolve()
            if not real.is_relative_to(Path(base).resolve()) or real == Path(base).resolve():
                return "fora da pasta do yTorrents"
            if os.path.normcase(str(real)) != os.path.normcase(os.path.abspath(p)):   # (no Windows, maiúsculas não contam)
                return "caminho com atalho no meio"
            if not real.is_file():
                return "não existe mais"
            st = real.stat()
        except (OSError, RuntimeError, ValueError) as e:
            return "não deu para conferir (%s)" % e
        if st.st_size != arq.get("tamanho") or st.st_mtime_ns != arq.get("mtime_ns"):
            return "mudou depois do download (tamanho ou data diferentes)"
        for u in em_uso:
            try:
                if real == u.resolve() or real.is_relative_to(u.resolve()):
                    return "em uso por um download em andamento"
            except (OSError, RuntimeError, ValueError):
                continue
        return ""

    def arquivos_gerenciados(self) -> dict:
        """Prévia para a confirmação: o que seria apagado (só arquivos do registro, intactos e fora de downloads em
        andamento) e o que fica, com o motivo."""
        em_uso = self._caminhos_em_uso()
        apagar, ficam, bases = [], [], set()
        with self.trava:
            regs = [dict(r) for r in self.gerenciados]
        for reg in regs:
            for a in reg.get("arquivos") or []:
                motivo = self._avaliar(reg, a, em_uso)
                if motivo:
                    if motivo != "não existe mais":
                        ficam.append((a["caminho"], motivo))
                else:
                    apagar.append(a["caminho"])
                    bases.add(reg["base"])
        return {"apagar": apagar, "ficam": ficam, "bases": sorted(bases),
                "bytes": sum(a.get("tamanho") or 0 for r in regs for a in r.get("arquivos") or []
                             if a["caminho"] in set(apagar))}

    def excluir_baixados(self) -> dict:
        """Apaga do disco SÓ os arquivos do registro que estão intactos (mesmo caminho, tamanho e data do fim do
        download), dentro da pasta do yTorrents, e que nenhum download em andamento usa. Depois tira as pastas que o
        próprio yTorrents criou, se ficaram vazias (rmdir: nunca apaga pasta com conteúdo). Sem rm recursivo.
        Devolve {'apagados', 'bytes', 'pastas', 'ficaram': [(caminho, motivo)], 'falhas': [(caminho, erro)]}."""
        em_uso = self._caminhos_em_uso()
        res = {"apagados": 0, "bytes": 0, "pastas": 0, "ficaram": [], "falhas": []}
        with self.trava:
            regs = self.gerenciados
            novos, pastas = [], []
            for reg in regs:
                resto = []
                for a in reg.get("arquivos") or []:
                    motivo = self._avaliar(reg, a, em_uso)
                    if motivo == "não existe mais":
                        continue
                    if motivo:
                        res["ficaram"].append((a["caminho"], motivo))
                        resto.append(a)
                        continue
                    try:
                        Path(a["caminho"]).unlink()
                        res["apagados"] += 1
                        res["bytes"] += a.get("tamanho") or 0
                    except OSError as e:
                        res["falhas"].append((a["caminho"], getattr(e, "strerror", None) or str(e)))
                        resto.append(a)
                if self._base_segura(reg.get("base") or ""):
                    pastas += [(d, reg["base"]) for d in reg.get("pastas") or []]
                if resto:
                    novos.append(dict(reg, arquivos=resto))
            # as pastas que o yTorrents criou saem por último (de todos os registros juntos: uma pasta de origem com
            # vários arquivos é de vários itens), da mais funda para a mais rasa, e só se ficaram vazias
            for d, base in sorted(set(pastas), key=lambda x: len(x[0]), reverse=True):
                try:
                    dp = Path(d)
                    if not dp.is_symlink() and dp.resolve().is_relative_to(Path(base).resolve()) \
                            and dp.resolve() != Path(base).resolve() and dp.is_dir() and not any(dp.iterdir()):
                        dp.rmdir()
                        res["pastas"] += 1
                except (OSError, RuntimeError, ValueError):
                    pass
            self.gerenciados = novos
            apagados_ids = {r["item"] for r in regs} - {r["item"] for r in novos}
            for i in self.itens:
                if i["id"] in apagados_ids and i["estado"] == "concluido":
                    i["msg"] = "Os arquivos deste download foram excluídos pelo yTorrents."
        self.salvar()
        self.ao_evento("lista")
        self._log("info" if not res["falhas"] else "warn",
                  "yTorrents: %d arquivo(s) excluído(s) (%s)%s%s." % (
                      res["apagados"], _fmt_tam(res["bytes"]),
                      "; %d ficaram (alterados, em uso ou fora da pasta)" % len(res["ficaram"]) if res["ficaram"] else "",
                      "; %d não puderam ser apagados" % len(res["falhas"]) if res["falhas"] else ""))
        return res

    def _migrar_gerenciados(self) -> None:
        """Downloads concluídos antes da 3.7.1 (sem registro): entram no registro só os arquivos que continuam
        exatamente onde o yTorrents os gravou e com o tamanho que ele anotou."""
        com_reg = {g.get("item") for g in self.gerenciados}
        for it in self.itens:
            if it["estado"] != "concluido" or it["id"] in com_reg or not it.get("final"):
                continue
            f = Path(it["final"])
            if it["tipo"] == "http":
                try:
                    if f.is_file() and it.get("tamanho") and f.stat().st_size == int(it["tamanho"]):
                        self._registrar(it)
                except (OSError, ValueError, TypeError):
                    pass
            elif it.get("torrent_b64"):
                try:
                    meta = MetaTorrent(base64.b64decode(it["torrent_b64"]))
                    arm = Armazenamento(meta, Path(it["raiz"])) if meta.multi else None
                    partes = [(c, t) for c, _, t in arm.partes if c is not None] if arm else [(f, meta.total)]
                    if partes and all(c.is_file() and c.stat().st_size == t for c, t in partes):
                        self._registrar(it)
                except (OSError, ErroTransferencia, binascii.Error, ValueError, KeyError):
                    pass

    # ---------------------------------------------------------------- comandos
    def achar(self, iid: str):
        with self.trava:
            return next((i for i in self.itens if i["id"] == iid), None)

    def iniciar(self) -> None:
        with self.trava:
            if self.fechando:
                return
            for i in self.itens:
                if i["estado"] == "pausado" and i.get("_pausa_geral"):
                    i["estado"] = "fila"
                    i.pop("_pausa_geral", None)
            self.rodando = True
            if self._gerente is None or not self._gerente.is_alive():
                self._gerente = threading.Thread(target=self._laco, daemon=True, name="ytorrents-fila")
                self._gerente.start()
        self._acordar.set()
        self.ao_evento("lista")

    def pausar(self, iid: str) -> None:
        it = self.achar(iid)
        if it is None:
            return
        ctl = self.controles.get(iid)
        if ctl is not None:
            ctl.parar("pausar")
        elif it["estado"] == "fila":
            it["estado"] = "pausado"
        self.salvar()
        self.ao_evento("lista")

    def retomar(self, iid: str) -> None:
        it = self.achar(iid)
        if it is None or it["estado"] not in ("pausado", "erro", "cancelado"):
            return
        it["estado"], it["msg"] = "fila", ""
        it.pop("_pausa_geral", None)
        self.salvar()
        self.iniciar()

    def cancelar(self, iid: str, descartar: bool = False) -> None:
        """Cancela (só este item). Arquivos CONCLUÍDOS nunca são apagados. Com `descartar`, apaga o que ficou pela
        metade: o .ypele-parcial (HTTP) ou os arquivos que este torrent criou e que não terminaram."""
        it = self.achar(iid)
        if it is None or it["estado"] == "concluido":
            return
        ctl = self.controles.get(iid)
        if ctl is not None:
            it["_descartar"] = descartar
            ctl.parar("cancelar")
        else:
            it["estado"], it["msg"] = "cancelado", "Cancelado."
            if descartar:
                self._descartar_parciais(it)
        self.salvar()
        self.ao_evento("lista")

    def pausar_todos(self) -> None:
        with self.trava:
            alvo = list(self.itens)
        for it in alvo:
            if it["estado"] in ESTADOS_ATIVOS + ("fila",):
                it["_pausa_geral"] = True
                self.pausar(it["id"])
        self.rodando = False

    def retomar_todos(self) -> None:
        with self.trava:
            for it in self.itens:
                if it["estado"] == "pausado":
                    it["estado"], it["msg"] = "fila", ""
                    it.pop("_pausa_geral", None)
        self.iniciar()

    def cancelar_todos(self, descartar: bool = False) -> int:
        with self.trava:
            alvo = [i["id"] for i in self.itens if i["estado"] in ESTADOS_ATIVOS + ("fila", "pausado")]
        for iid in alvo:
            self.cancelar(iid, descartar)
        return len(alvo)

    def repetir_falhas(self) -> int:
        n = 0
        with self.trava:
            for it in self.itens:
                if it["estado"] == "erro":
                    it["estado"], it["msg"] = "fila", ""
                    n += 1
        if n:
            self.iniciar()
        return n

    def remover(self, iid: str) -> bool:
        """Tira da lista um item que não está em andamento. Os arquivos ficam no disco."""
        with self.trava:
            it = next((i for i in self.itens if i["id"] == iid), None)
            if it is None or it["estado"] in ESTADOS_ATIVOS or iid in self.controles:
                return False
            self.itens.remove(it)
        self.salvar()
        self.ao_evento("lista")
        return True

    def remover_concluidos(self) -> int:
        with self.trava:
            antes = len(self.itens)
            self.itens = [i for i in self.itens if i["estado"] != "concluido"]
            n = antes - len(self.itens)
        if n:
            self.salvar()
            self.ao_evento("lista")
        return n

    def mover(self, iid: str, delta: int) -> None:
        """Reordena a fila (vale para quem ainda não começou)."""
        with self.trava:
            idx = next((k for k, i in enumerate(self.itens) if i["id"] == iid), None)
            if idx is None:
                return
            novo = max(0, min(len(self.itens) - 1, idx + delta))
            it = self.itens.pop(idx)
            self.itens.insert(novo, it)
        self.salvar()
        self.ao_evento("lista")

    # ---------------------------------------------------------------- execução
    def _laco(self) -> None:
        while not self.fechando:
            iniciar = []
            with self.trava:
                ativos = len(self.controles)
                if self.rodando:
                    for it in self.itens:
                        if ativos >= self.limite():
                            break
                        if it["estado"] == "fila" and it["id"] not in self.controles:
                            ctl = Controle(lambda: int(self._op("limite_kbps", 0) or 0) * 1024)
                            self.controles[it["id"]] = ctl
                            it["estado"], it["msg"] = "resolvendo", ""
                            iniciar.append((it, ctl))
                            ativos += 1
                if not iniciar and not self.controles and not any(i["estado"] == "fila" for i in self.itens):
                    self.rodando = False
            for it, ctl in iniciar:
                threading.Thread(target=self._executar, args=(it, ctl), daemon=True,
                                 name="ytorrents-%s" % it["id"]).start()
            if iniciar:
                self.ao_evento("lista")
            self._acordar.wait(0.5)
            self._acordar.clear()

    def _progresso(self, item) -> None:
        if item is not None:
            self.ao_evento("prog", item["id"])
        agora = time.monotonic()
        if agora - self._ultimo_salvar > 10:
            self._ultimo_salvar = agora
            self.salvar()

    def _executar(self, it: dict, ctl: Controle) -> None:
        try:
            if it["tipo"] == "http":
                it["estado"] = "baixando"
                if not it.get("pasta"):
                    base = Path(it["pasta_base"])
                    if it.get("pasta_individual", True):
                        nome = nome_seguro(os.path.splitext(it.get("nome") or "")[0], padrao="") or \
                            nome_seguro(urllib.parse.unquote(urllib.parse.urlsplit(it["entrada"]).path.rsplit("/", 1)[-1])
                                        .rsplit(".", 1)[0], padrao="download")
                        ocupadas = [i.get("pasta") for i in self.itens if i is not it and i.get("pasta")]
                        it["pasta"] = str(nome_livre(base, nome, e_pasta=True, ocupados=ocupadas))
                    else:
                        it["pasta"] = str(base)
                if not it.get("pastas_criadas"):
                    topo = Path(it.get("base_ytorrents") or it["pasta_base"])
                    criar, p = [], Path(it["pasta"])
                    while p != topo and p.is_relative_to(topo) and not p.exists():
                        criar.append(str(p))
                        p = p.parent
                    it["pastas_criadas"] = criar
                self.ao_evento("lista")
                final = baixar_http(it, ctl, self._progresso, int(self._op("tentativas", TENTATIVAS_PADRAO)), self._log)
                it["final"] = str(final)
            else:
                if self.torrent is None:
                    self.torrent = MotorTorrent(usar_dht=bool(self._op("dht", True)))
                it["estado"] = "baixando"
                self.torrent.baixar(it, self._progresso, self._log,
                                    lambda: int(self._op("limite_kbps", 0) or 0) * 1024, ctl)
            it.update(estado="concluido", msg="", velocidade=0.0, eta=None, concluido_em=_agora_iso())
            self._registrar(it)
            self._log("ok", "yTorrents: concluído — %s%s" % (it.get("nome") or it["entrada"][:60],
                                                             " (conferido: %s)" % it["conferido"] if it.get("conferido") else ""))
        except Parado as p:
            if str(p) == "escolher":                         # (3.8) magnet: metadados chegaram, falta a escolha
                it.update(estado="escolher", msg="Metadados recebidos: escolha os arquivos para começar.",
                          velocidade=0.0, eta=None)
                self._log("info", "yTorrents: “%s” — escolha os arquivos para começar o download." % (
                    it.get("nome") or it["entrada"][:60]))
            elif str(p) == "cancelar":
                if it.pop("_descartar", False):
                    self._descartar_parciais(it)
                it.update(estado="cancelado", msg="Cancelado.", velocidade=0.0, eta=None)
            elif self.fechando:                              # o app fechou: volta para a fila e continua na próxima vez
                it.update(estado="fila", msg="Interrompido ao fechar o app; continua de onde parou.", velocidade=0.0,
                          eta=None)
            else:
                geral = it.get("_pausa_geral")
                it.update(estado="pausado", msg="Pausado. O que já foi baixado fica guardado.", velocidade=0.0, eta=None)
                if geral:
                    it["_pausa_geral"] = True
        except ErroTransferencia as e:
            it.update(estado="erro", msg=str(e), velocidade=0.0, eta=None)
            self._log("erro", "yTorrents: %s — %s" % (it.get("nome") or it["entrada"][:60], e))
        except Exception as e:                               # nunca derruba a fila
            it.update(estado="erro", msg="Erro inesperado: %s" % e, velocidade=0.0, eta=None)
            self._log("erro", "yTorrents: erro inesperado em %s: %s" % (it.get("nome") or it["entrada"][:60], e))
        finally:
            with self.trava:
                self.controles.pop(it["id"], None)
            self.salvar()
            self.ao_evento("lista")
            self._acordar.set()

    def _descartar_parciais(self, it: dict) -> None:
        apagados = 0
        if it["tipo"] == "http" and it.get("parcial"):
            try:
                Path(it["parcial"]).unlink()
                apagados += 1
            except OSError:
                pass
            it["parcial"] = ""
        elif it["tipo"] != "http" and it.get("torrent_b64") and it.get("raiz"):
            try:
                meta = MetaTorrent(base64.b64decode(it["torrent_b64"]))
                if not it.get("pasta_individual", True) and not meta.multi:
                    alvos = [Path(it["final"])]
                else:
                    arm = Armazenamento(meta, Path(it["raiz"]))
                    alvos = [c for c, _, _ in arm.partes if c is not None]
                    arm.apagar_partes()                                # (3.8) pedaços de arquivos não escolhidos
                for c in alvos:
                    if c.is_file():
                        c.unlink()
                        apagados += 1
                raiz = Path(it["final"]) if meta.multi else Path(it["raiz"])
                if it.get("pasta_individual", True) or meta.multi:      # só as pastas vazias que o torrent criou
                    for d in sorted({p for c in alvos for p in c.parents if p.is_relative_to(raiz)} | {raiz},
                                    key=lambda x: len(str(x)), reverse=True):
                        try:
                            d.rmdir()
                        except OSError:
                            pass
            except (OSError, ErroTransferencia, binascii.Error, ValueError):
                pass
            it["pecas"] = ""
        if apagados:
            self._log("info", "yTorrents: %d arquivo(s) parcial(is) apagado(s) de %s." % (apagados, it.get("nome") or "?"))

    # ---------------------------------------------------------------- persistência
    def salvar(self) -> None:
        if self.arquivo is None:
            return
        with self.trava:
            dados = {"versao": 1, "itens": [{k: v for k, v in i.items() if not k.startswith("_") or k == "_pausa_geral"}
                                            for i in self.itens],
                     "gerenciados": list(self.gerenciados)}
        try:
            self.arquivo.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.arquivo.with_name(self.arquivo.name + ".tmp")
            tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.arquivo)
        except OSError:
            pass

    def carregar(self) -> int:
        """Restaura a fila. O que estava em andamento ao fechar volta para a fila (continua de onde parou ao iniciar)."""
        if self.arquivo is None or not self.arquivo.exists():
            return 0
        try:
            dados = json.loads(self.arquivo.read_text(encoding="utf-8"))
            itens = [i for i in dados.get("itens") or [] if isinstance(i, dict) and i.get("id") and i.get("entrada")]
        except (OSError, ValueError, AttributeError):
            self._log("warn", "Não consegui ler a fila do yTorrents; começando vazia (o arquivo antigo ficou guardado).")
            try:
                os.replace(self.arquivo, self.arquivo.with_name(self.arquivo.name + ".ilegivel"))
            except OSError:
                pass
            return 0
        pend = 0
        for i in itens:
            i.setdefault("estado", "fila")
            if i["estado"] in ESTADOS_ATIVOS:
                i["estado"], i["msg"] = "fila", "Interrompido ao fechar o app; continua de onde parou."
            if i["estado"] in ("fila", "pausado"):
                pend += 1
            i.update(velocidade=0.0, eta=None)
            if i["estado"] == "concluido" and i.get("final") and not Path(i["final"]).exists():
                i["msg"] = "O arquivo não está mais na pasta (movido ou apagado)."
        with self.trava:
            self.itens = itens
            self.gerenciados = [g for g in dados.get("gerenciados") or [] if isinstance(g, dict) and
                                isinstance(g.get("arquivos"), list)]
            self._migrar_gerenciados()
        return pend

    def encerrar(self) -> None:
        self.fechando = True
        for ctl in list(self.controles.values()):
            ctl.parar("pausar")
        fim = time.time() + 4
        while self.controles and time.time() < fim:
            time.sleep(0.05)
        self.salvar()
        if self.torrent is not None:
            self.torrent.encerrar()
